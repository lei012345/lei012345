import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { useState, useRef } from "react";
import { useInView } from "motion/react";
import Lottie from "lottie-react";
import heroImage from 'figma:asset/c98cbdaadc4c4fad50958392d75d4142adbc2316.png';
import asanaIcon from 'figma:asset/7636f8ef351b25fe1f48a68cefb05a88e9548614.png';
import photoshopIcon from 'figma:asset/d8e04e5177d6693d7609e9e377a43d495fa82923.png';
import illustratorIcon from 'figma:asset/c27c51c1324bdc726b3a2b9fc98bf877e84c68d5.png';
import canvaIcon from 'figma:asset/b6461a9c4e4c5163c4acfaecd7be024fdfc40e17.png';
import figmaIcon from 'figma:asset/666083d95c4fd6612942b96e9a208ea981d10696.png';
import framerIcon from 'figma:asset/87e00d30ceac25437d99ebc2b85d97e026ebc6dc.png';
import procreateIcon from 'figma:asset/d3670a60773b382608d5f5aff4063b694ee81160.png';
import typescriptAnimation from "../../imports/typescript-logo.json";
import trainingAnimation from "../../imports/training-animation.json";
import videoCameraAnimation from "../../imports/video_camera.json";
import dashboardAnimation from "../../imports/dashboard.json";

export function Skills() {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [clickedSkill, setClickedSkill] = useState<string | null>(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const floatingIcons = [
    { src: asanaIcon, alt: 'Asana', size: 'w-12 h-12', top: '5%', left: '15%', delay: 0 },
    { src: photoshopIcon, alt: 'Photoshop', size: 'w-14 h-14', top: '15%', left: '75%', delay: 0.5 },
    { src: illustratorIcon, alt: 'Illustrator', size: 'w-12 h-12', top: '35%', left: '10%', delay: 1 },
    { src: canvaIcon, alt: 'Canva', size: 'w-16 h-16', top: '45%', left: '80%', delay: 1.5 },
    { src: figmaIcon, alt: 'Figma', size: 'w-14 h-14', top: '65%', left: '12%', delay: 2 },
    { src: framerIcon, alt: 'Framer', size: 'w-12 h-12', top: '75%', left: '72%', delay: 2.5 },
    { src: procreateIcon, alt: 'Procreate', size: 'w-14 h-14', top: '85%', left: '25%', delay: 3 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/java1.png', alt: 'JavaScript', size: 'w-16 h-16', top: '90%', left: '68%', delay: 3.5 },
  ];

  return (
    <section id="skills" ref={ref} className="py-16 px-4 md:px-8 lg:px-12">
      <div className="max-w-[1400px] mx-auto">
        {/* Hero Image */}
        <motion.div
          className="flex justify-center mb-12 relative"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
        >
          <div className="relative w-full max-w-2xl h-[400px] md:h-[500px] flex items-center justify-center">
            {/* Floating Icons */}
            {floatingIcons.map((icon, index) => (
              <motion.div
                key={index}
                className={`absolute ${icon.size}`}
                style={{ top: icon.top, left: icon.left }}
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? {
                  opacity: 0.15,
                  scale: 1,
                  y: [0, -15, 0],
                  x: [0, Math.random() > 0.5 ? 10 : -10, 0],
                } : { opacity: 0, scale: 0 }}
                transition={{
                  opacity: { duration: 0.6, delay: icon.delay * 0.2 },
                  scale: { duration: 0.6, delay: icon.delay * 0.2 },
                  y: {
                    duration: 3 + Math.random() * 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: icon.delay * 0.2,
                  },
                  x: {
                    duration: 4 + Math.random() * 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: icon.delay * 0.2,
                  },
                }}
              >
                <img 
                  src={icon.src} 
                  alt={icon.alt}
                  className="w-full h-full object-contain"
                />
              </motion.div>
            ))}

            {/* Main Hero Image */}
            <div className="w-64 md:w-80 z-10">
              <img 
                src={heroImage} 
                alt="Person working on laptop" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </motion.div>

        <motion.div 
          className="mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] tracking-wider uppercase" style={{ fontWeight: 900 }}>
            Skills & Expertise
          </h2>
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
            Tools and technologies I work with
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioData.skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.category}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
              className="bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-blue-50/50 rounded-3xl p-6 border border-gray-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12">
                  <Lottie 
                    animationData={category.category === "E-Learning Tools" ? trainingAnimation : category.category === "Video & Motion" ? videoCameraAnimation : category.category === "Design Tools" ? dashboardAnimation : typescriptAnimation}
                    loop={true}
                    className="w-full h-full"
                  />
                </div>
                <h3 className="text-xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 700 }}>
                  {category.category}
                </h3>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <motion.button
                    key={skill}
                    onClick={() => setClickedSkill(skill === clickedSkill ? null : skill)}
                    onMouseEnter={() => setHoveredSkill(skill)}
                    onMouseLeave={() => setHoveredSkill(null)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-4 py-2 rounded-full text-sm font-[outfit] tracking-wider transition-all ${
                      clickedSkill === skill
                        ? "bg-[#715c94] text-white shadow-md"
                        : hoveredSkill === skill
                        ? "bg-[#8b7ba8] text-white"
                        : "bg-white text-gray-700 border border-gray-200 hover:border-[#715c94]"
                    }`}
                  >
                    {skill}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}