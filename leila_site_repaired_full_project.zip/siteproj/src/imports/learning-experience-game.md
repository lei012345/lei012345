Game concept: Build a Better Learning Experience

A tiny interactive game where the visitor helps improve a learning experience by choosing the best design decisions.

The player “wins” by making supportive, learner-friendly choices. It feels smart, positive, and directly connected to your portfolio.

Core idea

The visitor sees a quick prompt like:

“A learner is overwhelmed and disengaged. Choose 3 improvements to create a better learning experience.”

They pick from a set of cards.

Good choices:

Clear objective

Chunked content

Interactive practice

Supportive feedback

Simple navigation

Not-so-good choices:

Long wall of text

Confusing directions

Too many clicks

But even the weaker picks should not feel punishing. The feedback can stay warm:

“That can happen in real projects.”

“A stronger choice would be chunked content.”

So the game still feels encouraging.

Why this works for your website

It shows:

instructional or learning experience thinking

creativity

UX thinking

front-end interaction skills

your personal brand

It also gives visitors a fast win, which is exactly what you want.

Simple gameplay flow
Screen 1: Intro

A small card or section on your homepage or portfolio page.

Text:
Mini Challenge: Build a Better Learning Experience
Can you help this learner succeed in under 30 seconds?

Button:
Start

Screen 2: Scenario

Show a very short setup:

Jordan is taking an online training, but feels overwhelmed, bored, and unsure what to do next. Choose 3 design improvements.

Then show 6 to 8 clickable option cards.

Example options:

Clear learning goal

Chunk content into steps

Add interactive scenario

Give supportive feedback

Use simpler navigation

Add 5 more paragraphs

Hide instructions in dropdowns

Put everything on one long page

The user selects 3.

Button:
See Result

Screen 3: Result

Show a positive result based on their choices.

Example good result:
Nice work. You created a clearer, more engaging experience.
Your choices help reduce cognitive overload and support learner confidence.

If they picked a weaker option:
Good instinct. You improved the experience.
Next time, replacing “long wall of text” with “chunked content” would support the learner even more.

Then show a small visual payoff:

progress bar fills up

learner avatar smiles

tiny badge appears

confetti or sparkles

“Experience improved: 92%”

Buttons:

Play Again

View My Portfolio

Best tone for the experience

Keep it:

warm

polished

clever

minimal

encouraging

Not:

childish

gamey

competitive

stressful

This should feel like a thoughtful portfolio interaction, not a real game app.

Visual structure

A clean card in the center of the page works best.

Layout

title at top

short scenario text

grid of option cards

selected count: “2 of 3 selected”

CTA button below

result state in same container

Style direction

Since your work leans creative and design-focused:

soft background

rounded cards

subtle hover animation

small icons for each option

gentle microinteractions

clean typography

Example content set
Scenario

A new hire opens a training module and feels lost. Help improve the experience. Choose 3 design decisions.

Option cards

Good:

Clear objective

Chunked content

Practice activity

Helpful feedback

Simple navigation

Weaker:

Long dense text

Too many tabs

Vague instructions

Result messages

Excellent choice.
You prioritized clarity, engagement, and support.

Great start.
You helped the learner, and a few adjustments could make it even stronger.

You improved the experience.
Good learning design is all about thoughtful choices.

Super simple scoring logic

You do not need a complex system.

Option 1: Hidden point values

strong choice = 2 points

okay choice = 1 point

weak choice = 0 points

Then:

5–6 points = excellent result

3–4 points = good result

0–2 points = supportive improvement result

This lets everyone “win,” just with slightly different feedback.