import { motion } from "motion/react";
import { useState, useEffect } from "react";
import { Menu, X, User, Briefcase, MessageCircle, Pencil, Download, Gamepad2, Sparkles } from "lucide-react";
import { Link, useLocation } from "react-router";

export function Navigation() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { href: "/", label: "Home", icon: User },
    { href: "/about", label: "About", icon: User },
    { href: "/process", label: "Process", icon: Sparkles },
    { href: "/projects", label: "Projects", icon: Briefcase },
    { href: "/game", label: "Try It!", icon: Gamepad2 },
    { href: "/skills", label: "Skills", icon: Pencil },
  ];

  const handleClick = () => {
    setIsOpen(false);
  };

  const isActive = (href: string) => {
    if (href === "/") {
      return location.pathname === "/";
    }
    return location.pathname === href;
  };

  return (
    <>
      {/* Desktop Navigation - Traditional full-width */}
      <motion.nav
        className={`hidden md:flex fixed top-0 left-0 right-0 z-50 transition-all duration-300 flex items-center justify-center ${
          scrolled ? 'bg-white shadow-md border-b border-gray-200' : ''
        }`}
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div className="px-6 py-4">
          <ul className="flex items-center justify-center gap-2">
            {navItems.map((item, index) => {
              return (
                <motion.li key={index} whileHover={{ y: -2 }} transition={{ duration: 0.2 }}>
                  <Link
                    to={item.href}
                    className={`px-4 py-2 text-gray-700 hover:text-[#6b5b95] hover:bg-[#f5f2f8] rounded transition-all font-[outfit] tracking-wide ${isActive(item.href) ? 'bg-[#f5f2f8] text-[#6b5b95]' : ''}`}
                    style={{ fontWeight: 600 }}
                  >
                    {item.label}
                  </Link>
                </motion.li>
              );
            })}
            {/* Contact Button */}
            <motion.li whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
              <Link
                to="/contact"
                className="ml-4 px-6 py-2 bg-[#7b9eb5] text-white hover:bg-[#6a8ea4] rounded shadow-sm hover:shadow-md transition-all font-[outfit] tracking-wide"
                style={{ fontWeight: 700 }}
              >
                Contact
              </Link>
            </motion.li>
            {/* Resume Button */}
            <motion.li whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
              
            </motion.li>
          </ul>
        </div>
      </motion.nav>

      {/* Mobile Navigation Button */}
      <motion.button
        className="fixed top-4 right-4 z-50 md:hidden w-12 h-12 bg-white border-2 border-[#d4c5e8] rounded-lg shadow-lg flex items-center justify-center"
        onClick={() => setIsOpen(!isOpen)}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isOpen ? <X className="w-5 h-5 text-[#6b5b95]" /> : <Menu className="w-5 h-5 text-[#6b5b95]" />}
      </motion.button>

      {/* Mobile Navigation Menu */}
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-40 md:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="absolute inset-0 bg-gray-900/20 backdrop-blur-md" onClick={() => setIsOpen(false)} />
          <motion.div
            className="absolute top-20 right-6 left-6 bg-white rounded-lg shadow-2xl overflow-hidden border-2 border-[#d4c5e8]"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <ul className="p-2">
              {navItems.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.li
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link
                      to={item.href}
                      onClick={handleClick}
                      className="flex items-center gap-3 px-5 py-3.5 rounded-md hover:bg-[#f5f2f8] transition-all group"
                    >
                      <Icon className="w-5 h-5 text-[#6b5b95] group-hover:scale-110 transition-transform" />
                      <span className="font-[outfit] tracking-wide text-gray-800" style={{ fontWeight: 600 }}>{item.label}</span>
                    </Link>
                  </motion.li>
                );
              })}
              {/* Contact Button - Mobile */}
              <motion.li
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: navItems.length * 0.05 }}
                className="mt-2 px-3"
              >
                <Link
                  to="/contact"
                  onClick={handleClick}
                  className="flex items-center justify-center gap-3 px-5 py-3.5 rounded-md bg-[#7b9eb5] text-white shadow-md hover:shadow-lg hover:bg-[#6a8ea4] transition-all"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="font-[outfit] tracking-wide" style={{ fontWeight: 700 }}>Contact</span>
                </Link>
              </motion.li>
              {/* Resume Button - Mobile */}
              <motion.li
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: navItems.length * 0.05 }}
                className="mt-2 px-3"
              >
                
              </motion.li>
            </ul>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}