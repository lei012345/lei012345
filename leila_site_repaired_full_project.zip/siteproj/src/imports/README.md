
  # Leila Designs (Copy)

  This is a code bundle for Leila Designs (Copy). The original project is available at https://www.figma.com/design/DAA3EgZNNj0uyLenf3Kkay/Leila-Designs--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  