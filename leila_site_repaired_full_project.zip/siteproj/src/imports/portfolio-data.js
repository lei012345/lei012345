// 🎨 ============================================
// ✨ YOUR PORTFOLIO CONTENT - EDIT HERE! ✨
// 🎨 ============================================
//
// 📝 HOW TO USE THIS FILE:
// This is the ONLY file you need to edit to update your entire website!
// Simply change the text between the quotes "" to update your content.
// 
// 💡 TIPS:
// - Text between quotes ("") is what shows on your website
// - Don't delete the commas (,) at the end of lines
// - To add more items to a list, copy an existing item and edit it
// - Save the file and refresh your browser to see changes
//
// 🚀 SECTIONS IN THIS FILE:
// 1. Personal Information (name, tagline, bio)
// 2. Social Links (email, GitHub, LinkedIn, etc.)
// 3. Projects (your portfolio work)
// 4. Skills (your expertise)
// 5. About Section (introduction and key points)
//
// ============================================

export const portfolioData = {
  // ============================================
  // 👤 SECTION 1: PERSONAL INFORMATION
  // ============================================
  name: "Leila Alswayan",
  tagline: "Graphic ",
  bio: "I craft delightful digital experiences that make people smile. When I'm not coding, you'll find me exploring new coffee shops or doodling in my sketchbook.",
  
  // 📄 RESUME URL - Link to your resume/CV (Google Drive, Dropbox, or direct PDF link)
  resumeUrl: "https://drive.google.com/file/d/YOUR_RESUME_ID/view",
  
  // 💼 PROFESSIONAL SUMMARY - For ID/LXD context
  professionalSummary: "Instructional Designer and Learning Experience Designer specializing in creating engaging, learner-centered educational solutions. I blend creative design with evidence-based learning principles to develop impactful training programs, e-learning courses, and educational websites.",
  
  // 🎓 CERTIFICATIONS & CREDENTIALS - Add your professional certifications
  certifications: [
    // Example: "Certified Professional in Learning and Performance (CPLP)",
    // Example: "ATD Master Instructional Designer",
    // Add your certifications here
  ],
  
  // 🎯 CORE COMPETENCIES - ID/LXD specific skills
  coreCompetencies: [
    "Instructional Design",
    "Learning Experience Design",
    "Curriculum Development",
    "E-Learning Development",
    "User Experience Design",
    "Visual Design & Branding"
  ],

  // ============================================
  // 🔗 SECTION 2: SOCIAL LINKS
  // ============================================
  social: {
    email: "hello@leiladesigns.com",
    phone: "571-510-0127",
    github: "https://github.com/alexrivera",
    linkedin: "https://linkedin.com/in/alexrivera",
    twitter: "https://twitter.com/alexrivera",
    portfolio: "https://alexrivera.com"
  },

  // ============================================
  // 💼 SECTION 3: PROJECTS
  // ============================================
  // Each project appears as a card on your portfolio.
  // To edit a project: change the text between quotes
  // To add a project: copy an entire project block and edit it
  // 
  // Project fields explained:
  // - id: Keep these numbers unique (1, 2, 3, etc.)
  // - title: Project name (shows on card and detail page)
  // - description: Short summary (shows on card)
  // - tags: Technologies used (shows as small badges)
  // - color: Gradient colors for the card (use existing patterns)
  // - cardImage: Image URL for the project card (paste your image URL here!)
  // - conceptPhotos: Images that cycle on card hover (from the Concept Photos section)
  // - detailedDescription: Full description (shows on detail page)
  // - features: List of key features (each item is a bullet point)
  // - technologies: Full tech stack (shows on detail page)
  // - images: Add image URLs here (shows on detail page)
  // - liveUrl: Link to live project
  // - githubUrl: Link to GitHub repository
  // 
  // 📚 INSTRUCTIONAL DESIGN FIELDS (optional - add to showcase your ID/LXD work):
  // - role: Your role in the project (e.g., "Lead Instructional Designer", "Learning Experience Designer")
  // - client: Client or organization name (e.g., "Corporate Training", "K-12 Education")
  // - audience: Target learners (e.g., "Healthcare professionals", "New employees", "Students ages 10-12")
  // - learningObjectives: Array of learning outcomes (what learners will be able to do)
  // - methodology: Design approach used (e.g., "ADDIE", "SAM", "Design Thinking", "Backwards Design")
  // - deliverables: What was delivered (e.g., "E-learning module", "Instructor guide", "Assessment tools")
  // - duration: Project timeline or course length (e.g., "3-month project", "45-minute module")
  // - impact: Results or metrics (e.g., "95% completion rate", "40% improvement in test scores")
  // - challenge: Problem you were solving
  // - solution: How you solved it
  // - projectType: Type of project (e.g., "E-Learning", "Blended Learning", "ILT", "Microlearning", "Performance Support")
  // ============================================
  projects: [
    // {
    //   id: 1,
    //   title: "Veterans Care",
    //   description: "A cheerful app to track your daily moods with beautiful visualizations and insights.",
    //   tags: ["React", "TypeScript", "Chart.js"],
    //   color: "from-blue-400 to-cyan-500",
    //   link: "#",
    //   logo: "https://leiladesigns.com/_assets/v11/4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04.png",
    //   
    //   // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
    //   cardImage: "https://lh3.googleusercontent.com/d/1x8_mT2Qvs-PQdh2UHiI3us4K6jr1k6EU",

    //   // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
    //   conceptPhotos: [
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-groceries.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-helping.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-groceries-box.png",
    //   ],
    //   
    //   // 📄 DETAILED PROJECT CONTENT (appears on individual project pages)
    //   detailedDescription: "Mood Tracker helps you understand your emotional patterns through daily check-ins and beautiful data visualizations. Built with React and TypeScript, it features an intuitive interface and insightful analytics.",
    //   
    //   // ✨ KEY FEATURES (appears as bullet points)
    //   features: [
    //     "Clean, modern design with intuitive and straightforward navigation",
    //     "Contact number prominently displayed in the navigation for quick and easy access",
    //     "About page clearly communicating the organization's mission and core values",
    //     "Services page providing comprehensive insight into all available services",
    //     "Contact page offering multiple contact methods, including emergency support",
    //     "Donate page featuring a convenient and user-friendly donation form",
    //   ],
    //   
    //   // 🛠️ TECHNOLOGIES USED
    //   technologies: ["React", "TypeScript", "Chart.js", "Local Storage", "Tailwind CSS"],
    //   
    //   // 🖼️ PROJECT IMAGES (add your screenshot URLs here)
    //   images: [
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/dd5.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Screenshot%20(152).png"
    //   ],
    //   
    //   // 🔗 PROJECT LINKS
    //   liveUrl: "https://veteranscare.figma.site",
    //   githubUrl: "https://github.com/yourusername/mood-tracker"
    // },
    {
      id: 7,
      title: "Kindred Paws",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/36fa19961c80c3544217481b4c6561bc5f35e9d8.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-1.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kindred-pin.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-hat.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content in portfolio-data.ts to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [
        "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM"
      ],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project"
    },
    {
      id: 8,
      title: "Fairfax Family Auto",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/244751b83e74424c6540c4510e6ee8609b269532.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/fa-sh.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/ff-2.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/ff-repair.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project"
    },
    {
      id: 9,
      title: "ID-Project-1",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/36fa19961c80c3544217481b4c6561bc5f35e9d8.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-1.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kindred-pin.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-hat.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content in portfolio-data.ts to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [
        "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM"
      ],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project",
      
      // 📚 ID/LXD EXAMPLE FIELDS - Edit these to showcase your instructional design work!
      // Uncomment and customize the fields below to display project details on your project page
      role: "Lead Instructional Designer",
      client: "Corporate HR Department",
      audience: "New managers and team leads",
      projectType: "E-Learning Module",
      methodology: "ADDIE Model with User-Centered Design principles",
      deliverables: "45-minute e-learning module, facilitator guide, and knowledge assessments",
      duration: "3-month project (20-minute learning experience)",
      impact: "92% completion rate, 85% positive feedback, 30% improvement in manager communication skills",
      challenge: "Managers struggled with difficult workplace conversations, leading to unresolved conflicts and decreased team morale. Traditional training was too lecture-heavy and didn't provide practical application.",
      solution: "Created an interactive scenario-based e-learning module featuring realistic workplace situations, branching scenarios, and immediate feedback. Included video demonstrations, practice exercises, and downloadable conversation frameworks.",
      learningObjectives: [
        "Identify triggers for difficult conversations and prepare effectively",
        "Apply the GROW model to structure challenging conversations",
        "Demonstrate active listening techniques in conflict situations",
        "Utilize de-escalation strategies when emotions run high"
      ]
    }
  ],

  // ============================================
  // 🛠️ SECTION 4: SKILLS
  // ============================================
  // Change skill names and categories
  // To add a skill: add it to the appropriate category array
  // To add a category: copy an entire category block and edit it
  // ============================================
  skillCategories: [
    {
      category: "E-Learning Tools",
      icon: "🎓",
      skills: ["Articulate Storyline", "Adobe Captivate", "Articulate Rise", "H5P", "Camtasia"]
    },
    {
      category: "Design Tools",
      icon: "🎨",
      skills: ["Figma", "Procreate", "Adobe Photoshop", "Adobe Illustrator", "Adobe InDesign", "Canva"]
    },
    {
      category: "Web Development",
      icon: "💻",
      skills: ["HTML", "CSS", "JavaScript", "React", "TypeScript", "Tailwind CSS"]
    },
    {
      category: "Video & Motion",
      icon: "🎬",
      skills: ["Adobe Premiere Pro", "Adobe After Effects", "DaVinci Resolve", "CapCut", "ToonSquid"]
    }
  ],

  // ============================================
  // 📋 SECTION 6: DESIGN PROCESS/METHODOLOGY
  // ============================================
  // Your instructional design process - shows your professional approach
  // ============================================
  designProcess: [
    {
      phase: "Analyze",
      icon: "🔍",
      description: "Identify learning needs, audience characteristics, and performance gaps through stakeholder interviews and needs analysis.",
      activities: ["Conduct needs assessment", "Define target audience", "Analyze existing materials"]
    },
    {
      phase: "Design",
      icon: "✏️",
      description: "Create learning objectives, assessment strategies, and instructional approach based on analysis findings.",
      activities: ["Write learning objectives", "Design assessments", "Create design document"]
    },
    {
      phase: "Develop",
      icon: "🛠️",
      description: "Build instructional materials, including e-learning modules, job aids, and instructor guides.",
      activities: ["Develop storyboards", "Create prototypes", "Build course materials"]
    },
    {
      phase: "Implement",
      icon: "🚀",
      description: "Deploy training materials and provide support for learners and facilitators.",
      activities: ["Pilot test course", "Train facilitators", "Launch to learners"]
    },
    {
      phase: "Evaluate",
      icon: "📊",
      description: "Measure effectiveness through assessment data, feedback, and performance metrics.",
      activities: ["Collect learner feedback", "Analyze completion rates", "Measure learning outcomes"]
    }
  ],

  // ============================================
  // 🎯 SECTION 5: ABOUT SECTION
  // ============================================
  about: {
    intro: "Hey there! 👋 I'm a developer who believes that code should be as delightful as the experiences it creates.",
    points: [
      "🎨 5+ years designing and building web applications",
      "💡 Passionate about accessibility and inclusive design",
      "🚀 Always learning and exploring new technologies",
      "🌟 Coffee enthusiast and weekend adventurer"
    ]
  }
};