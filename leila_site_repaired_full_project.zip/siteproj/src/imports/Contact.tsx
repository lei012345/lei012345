import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { useInView } from "motion/react";
import { useRef } from "react";
import { ContactForm } from "./ContactForm";

export function Contact() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30" ref={ref}>
      <div className="max-w-[900px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] tracking-wider uppercase" style={{ fontWeight: 900 }}>
            Get in Touch
          </h2>
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg mb-3">
            Fill out the form below and I'll get in touch as soon as possible. You can also directly email me. 
          </p>
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
            <a href="mailto:hello@leiladesigns.com" className="text-xl md:text-2xl font-semibold text-[#5a7a94] hover:text-[#7b9eb5] transition-all underline decoration-2 underline-offset-4 hover:underline-offset-8">
              hello@leiladesigns.com
            </a>
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="bg-white rounded-lg p-8 md:p-12 shadow-sm"
        >
          <ContactForm recipientEmail={portfolioData.social.email} />
        </motion.div>
      </div>
    </section>
  );
}