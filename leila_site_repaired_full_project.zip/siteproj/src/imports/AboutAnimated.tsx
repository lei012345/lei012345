import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { Mail, Lightbulb, Users, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";

export function AboutAnimated() {
  const [typedText, setTypedText] = useState("");
  const fullText = "DESIGNING ENGAGING";
  
  useEffect(() => {
    let index = 0;
    const typingInterval = setInterval(() => {
      if (index <= fullText.length) {
        setTypedText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(typingInterval);
      }
    }, 50);
    
    return () => clearInterval(typingInterval);
  }, []);
  
  const handleGetInTouch = () => {
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      const navHeight = 80;
      const elementPosition = contactSection.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="about" className="relative pt-0 pb-20 px-0 overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/60 via-purple-50/60 to-pink-50/60"></div>
      
      {/* Decorative elements */}
      <div className="absolute top-20 right-10 w-72 h-72 bg-yellow-200/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl"></div>
      
      <div className="max-w-[1400px] mx-auto relative z-10 px-4 md:px-8 lg:px-12 pt-20">
        {/* Hero Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Left Column - Animated SVG */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            {/* Main Heading */}
            <motion.h1
              className="font-[outfit] tracking-tight"
              style={{ fontWeight: 800 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-[#40464f] block font-normal text-[36px]">
                {typedText}
              </span>
              <span className="text-5xl md:text-6xl lg:text-7xl text-[#40464f] block">
                {"LEARNING EXPERIENCES".split("").map((char, index) => (
                  <motion.span className="text-[#1a1a2e]"
                    key={index}
                    initial={{ opacity: 0, filter: "blur(10px)" }}
                    whileInView={{ opacity: 1, filter: "blur(0px)" }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.06 }}
                  >
                    {char}
                  </motion.span>
                ))}
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              className="text-xl md:text-2xl text-[#40464f] leading-relaxed font-[outfit] tracking-wide"
              style={{ fontWeight: 500 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >Transforming complex information into engaging, interactive learning experiences that empower learners and drive measurable results.</motion.p>

            {/* Key Points */}
            <motion.div
              className="grid grid-cols-1 sm:grid-cols-3 gap-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#715c94]/20 to-[#715c94]/10 flex items-center justify-center flex-shrink-0">
                  <Lightbulb className="w-6 h-6 text-[#715c94]" />
                </div>
                <div>
                  <h3 className="font-[outfit] text-sm tracking-wider uppercase text-[#715c94] mb-1" style={{ fontWeight: 700 }}>Creative</h3>
                  <p className="text-sm text-[#40464f] font-[outfit]">Innovative design solutions</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#d97242]/20 to-[#d97242]/10 flex items-center justify-center flex-shrink-0">
                  <Users className="w-6 h-6 text-[#d97242]" />
                </div>
                <div>
                  <h3 className="font-[outfit] text-sm tracking-wider uppercase text-[#d97242] mb-1" style={{ fontWeight: 700 }}>Learner-Centered</h3>
                  <p className="text-sm text-[#40464f] font-[outfit]">Human-first approach</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-[#7b9eb5]/20 to-[#7b9eb5]/10 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-6 h-6 text-[#7b9eb5]" />
                </div>
                <div>
                  <h3 className="font-[outfit] text-sm tracking-wider uppercase text-[#7b9eb5] mb-1" style={{ fontWeight: 700 }}>Interactive</h3>
                  <p className="text-sm text-[#40464f] font-[outfit]">Engaging experiences</p>
                </div>
              </div>
            </motion.div>

            {/* CTA Button */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-wrap gap-4"
            >
              <button
                onClick={handleGetInTouch}
                className="bg-gradient-to-r from-[#d97242] to-[#c36538] py-4 px-8 rounded-md hover:shadow-xl hover:scale-105 transition-all inline-flex items-center justify-center gap-3 group text-white font-bold font-[outfit] tracking-wide text-lg"
                style={{ fontWeight: 800 }}
              >
                <Mail className="w-6 h-6 group-hover:scale-110 transition-transform" />
                LET'S CONNECT
              </button>
              
              <button
                onClick={() => {
                  const projectsSection = document.getElementById('projects');
                  if (projectsSection) {
                    const navHeight = 80;
                    const elementPosition = projectsSection.getBoundingClientRect().top + window.pageYOffset;
                    const offsetPosition = elementPosition - navHeight;
                    
                    window.scrollTo({
                      top: offsetPosition,
                      behavior: 'smooth'
                    });
                  }
                }}
                className="bg-white/80 backdrop-blur-sm py-4 px-8 rounded-md hover:shadow-lg hover:scale-105 transition-all inline-flex items-center justify-center gap-3 group border border-[#715c94] text-[#715c94] font-bold font-[outfit] tracking-wide text-lg"
                style={{ fontWeight: 800 }}
              >
                VIEW WORK
              </button>
            </motion.div>
          </motion.div>

          {/* Right Column - Profile Image Placeholder */}
          <motion.div
            className="relative flex items-center justify-center"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <motion.div 
              className="w-full max-w-md aspect-square bg-[#e0edff] rounded-full"
              animate={{ y: [0, -8, 0] }}
              transition={{ 
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            ></motion.div>
            <motion.img 
              src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/0-design.png" 
              alt="woman on laptop" 
              className="absolute inset-0 w-full h-full object-contain"
              animate={{ y: [0, -10, 0] }}
              transition={{ 
                duration: 5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.5
              }}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}