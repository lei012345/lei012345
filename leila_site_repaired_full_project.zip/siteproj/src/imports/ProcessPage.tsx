import { Navigation } from "../components/Navigation";
import { DesignProcess } from "../components/DesignProcess";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";
import { motion } from "motion/react";
import { useRef } from "react";
import { useInView } from "motion/react";

export function ProcessPage() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        {/* Design Process Section */}
        <section ref={ref} className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30">
          <div className="max-w-[1400px] mx-auto">
            <motion.div 
              className="mb-12 text-center"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.6 }}
            >
              <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] tracking-wider uppercase" style={{ fontWeight: 900 }}>
                My Design Process
              </h2>
              <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
                A systematic approach to creating meaningful design solutions
              </p>
            </motion.div>
            <DesignProcess />
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
