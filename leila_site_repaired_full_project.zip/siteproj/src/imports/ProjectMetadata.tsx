import { motion } from "motion/react";
import { Users, Target, Lightbulb, Package, Clock, TrendingUp, Briefcase, GraduationCap } from "lucide-react";

type ProjectMetadataProps = {
  role?: string;
  client?: string;
  audience?: string;
  learningObjectives?: string[];
  methodology?: string;
  deliverables?: string;
  duration?: string;
  impact?: string;
  challenge?: string;
  solution?: string;
  projectType?: string;
};

export function ProjectMetadata({
  role,
  client,
  audience,
  learningObjectives,
  methodology,
  deliverables,
  duration,
  impact,
  challenge,
  solution,
  projectType
}: ProjectMetadataProps) {
  // Only render if at least one ID/LXD field is present
  const hasIDData = role || client || audience || learningObjectives || methodology || deliverables || duration || impact || challenge || solution || projectType;
  
  if (!hasIDData) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.3 }}
      className="bg-white rounded-2xl p-8 shadow-sm max-w-4xl w-full"
    >
      <h2 className="text-3xl mb-6 text-center font-[outfit] tracking-wider uppercase" style={{ fontWeight: 900 }}>
        Project Details
      </h2>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Project Type */}
        {projectType && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-blue-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Project Type
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{projectType}</p>
            </div>
          </div>
        )}

        {/* Role */}
        {role && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-purple-50 rounded-lg flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-purple-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                My Role
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{role}</p>
            </div>
          </div>
        )}

        {/* Client */}
        {client && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-pink-50 rounded-lg flex items-center justify-center">
              <Briefcase className="w-5 h-5 text-pink-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Client/Organization
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{client}</p>
            </div>
          </div>
        )}

        {/* Target Audience */}
        {audience && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-green-50 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-green-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Target Audience
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{audience}</p>
            </div>
          </div>
        )}

        {/* Methodology */}
        {methodology && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-yellow-50 rounded-lg flex items-center justify-center">
              <Lightbulb className="w-5 h-5 text-yellow-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Methodology
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{methodology}</p>
            </div>
          </div>
        )}

        {/* Deliverables */}
        {deliverables && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-orange-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Deliverables
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{deliverables}</p>
            </div>
          </div>
        )}

        {/* Duration */}
        {duration && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-cyan-50 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-cyan-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Duration
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{duration}</p>
            </div>
          </div>
        )}

        {/* Impact */}
        {impact && (
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-emerald-50 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-emerald-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-1" style={{ fontWeight: 700 }}>
                Impact & Results
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide">{impact}</p>
            </div>
          </div>
        )}
      </div>

      {/* Learning Objectives - Full Width */}
      {learningObjectives && learningObjectives.length > 0 && (
        <div className="mt-6 pt-6 border-t border-gray-100">
          <div className="flex gap-3 items-start">
            <div className="flex-shrink-0 w-10 h-10 bg-indigo-50 rounded-lg flex items-center justify-center">
              <Target className="w-5 h-5 text-indigo-600" aria-hidden="true" />
            </div>
            <div className="flex-1">
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-3" style={{ fontWeight: 700 }}>
                Learning Objectives
              </h3>
              <ul className="space-y-2" role="list">
                {learningObjectives.map((objective, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span className="text-indigo-600 mt-1 flex-shrink-0" aria-hidden="true">•</span>
                    <span className="text-gray-900 font-[outfit] tracking-wide">{objective}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Challenge & Solution */}
      {(challenge || solution) && (
        <div className="mt-6 pt-6 border-t border-gray-100 space-y-4">
          {challenge && (
            <div>
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-2" style={{ fontWeight: 700 }}>
                The Challenge
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide leading-relaxed">{challenge}</p>
            </div>
          )}
          {solution && (
            <div>
              <h3 className="font-[outfit] tracking-wider uppercase text-sm text-gray-500 mb-2" style={{ fontWeight: 700 }}>
                The Solution
              </h3>
              <p className="text-gray-900 font-[outfit] tracking-wide leading-relaxed">{solution}</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
