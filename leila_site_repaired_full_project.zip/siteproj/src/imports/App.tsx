import { RouterProvider } from "react-router";
import { router } from "./routes";
import { useEffect } from "react";

function App() {
  useEffect(() => {
    // Update favicon
    const link = document.querySelector("link[rel*='icon']") as HTMLLinkElement || document.createElement('link');
    link.type = 'image/png';
    link.rel = 'icon';
    link.href = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/rf.png';
    if (!document.querySelector("link[rel*='icon']")) {
      document.head.appendChild(link);
    }
  }, []);

  return (
    <RouterProvider router={router} />
  );
}

export default App;