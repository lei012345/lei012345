import { portfolioData } from "../data/portfolio-data";
import { Mail, Linkedin, Github, Phone } from "lucide-react";
import { Link } from "react-router";

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30 border-t border-gray-200">
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 lg:px-12 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand Section */}
          <div>
            <h3 className="font-[outfit] tracking-wider uppercase text-gray-900 mb-4" style={{ fontWeight: 900 }}>
              {portfolioData.name}
            </h3>
            <p className="text-gray-600 font-[outfit] text-sm leading-relaxed mb-4">
              Instructional Designer & Learning Experience Designer specializing in creating engaging, learner-centered educational solutions.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-[outfit] tracking-wider uppercase text-gray-900 mb-4" style={{ fontWeight: 700 }}>
              Quick Links
            </h4>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/process" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Process
                </Link>
              </li>
              <li>
                <Link to="/projects" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Projects
                </Link>
              </li>
              <li>
                <Link to="/skills" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Skills
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-[outfit] tracking-wider uppercase text-gray-900 mb-4" style={{ fontWeight: 700 }}>
              Get In Touch
            </h4>
            <ul className="space-y-3">
              <li>
                <a 
                  href={`mailto:${portfolioData.social.email}`} 
                  className="text-gray-600 hover:text-[#d97242] transition-colors font-[outfit] text-sm inline-flex items-center gap-2"
                >
                  <Mail className="w-4 h-4" />
                  {portfolioData.social.email}
                </a>
              </li>
              <li>
                <a 
                  href={`tel:${portfolioData.social.phone}`} 
                  className="text-gray-600 hover:text-[#d97242] transition-colors font-[outfit] text-sm inline-flex items-center gap-2"
                >
                  <Phone className="w-4 h-4" />
                  {portfolioData.social.phone}
                </a>
              </li>
              <li className="flex gap-3 pt-2">
                <a 
                  href={portfolioData.social.linkedin} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-[#715c94] text-white flex items-center justify-center hover:bg-[#8b7ba8] transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a 
                  href={portfolioData.social.github} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-full bg-[#715c94] text-white flex items-center justify-center hover:bg-[#8b7ba8] transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="w-4 h-4" />
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-200">
          <p className="text-center text-sm text-gray-600 font-[outfit]">
            © {currentYear} {portfolioData.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}