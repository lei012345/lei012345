// StandaloneBonusGame.tsx
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, RefreshCw, ArrowRight, Volume2, VolumeX } from 'lucide-react';

interface Statement {
  text: string;
  correctAnswer: 'Assertive' | 'Passive' | 'Aggressive';
  audioUrl: string;
}

const statements: Statement[] = [
  { text: "I understand the deadline is tight. Let's discuss what's realistic and how we can prioritize.", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-deadline.mp3' },
  { text: "Whatever you say. I'll just do my best, I guess...", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-domybest.mp3' },
  { text: "You always give me impossible deadlines! This is ridiculous!", correctAnswer: 'Aggressive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-ridiculous.mp3' },
  { text: "I can see this is important. Can we look at the timeline together and find a solution?", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-timeline.mp3' },
  { text: "Okay... I'll try to make it work somehow.", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-okay.mp3' },
  { text: "You clearly don't understand how long design work takes!", correctAnswer: 'Aggressive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-designwork.mp3' },
  { text: "I respect your concern. Here's what I can deliver by then, and what would need more time.", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-respect.mp3' },
  { text: "I guess I can cancel my weekend plans again...", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-i%20guess.mp4' },
];

type GameState = 'intro' | 'instructions' | 'playing' | 'result';

export function StandaloneBonusGame() {
  const [gameState, setGameState] = useState<GameState>('intro');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [currentStatementAudio, setCurrentStatementAudio] = useState<HTMLAudioElement | null>(null);
  const [showQuickReference, setShowQuickReference] = useState(false);

  // Play success sound when game ends
  useEffect(() => {
    if (gameState === 'result' && !isMuted) {
      const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/success.mp3');
      audio.play().catch(err => console.error('Success sound failed:', err));
    }
  }, [gameState, isMuted]);

  // Play statement audio when statement changes
  useEffect(() => {
    if (gameState === 'playing' && !isMuted) {
      // Stop any currently playing audio first
      if (currentStatementAudio) {
        currentStatementAudio.pause();
        currentStatementAudio.currentTime = 0;
      }
      
      // For "cancel plans" statement, play immediately without setTimeout
      if (currentIndex === statements.length - 1) {
        const audio = new Audio(statements[currentIndex].audioUrl);
        console.log('Playing audio:', statements[currentIndex].audioUrl);
        audio.volume = 1.0; // Maximum volume allowed by browser
        setCurrentStatementAudio(audio);
        
        // Add event listeners for debugging
        audio.addEventListener('loadeddata', () => console.log('Audio loaded successfully'));
        audio.addEventListener('error', (e) => console.error('Audio error:', e));
        
        audio.play().catch(err => console.error('Statement audio failed:', err));
        
        return () => {
          audio.pause();
          audio.currentTime = 0;
        };
      } else {
        // For other statements, use 500ms delay
        const timer = setTimeout(() => {
          const audio = new Audio(statements[currentIndex].audioUrl);
          console.log('Playing audio:', statements[currentIndex].audioUrl);
          setCurrentStatementAudio(audio);
          
          // Add event listeners for debugging
          audio.addEventListener('loadeddata', () => console.log('Audio loaded successfully'));
          audio.addEventListener('error', (e) => console.error('Audio error:', e));
          
          audio.play().catch(err => console.error('Statement audio failed:', err));
        }, 500);
        
        return () => {
          clearTimeout(timer);
          if (currentStatementAudio) {
            currentStatementAudio.pause();
            currentStatementAudio.currentTime = 0;
          }
        };
      }
    }
    
    return () => {
      if (currentStatementAudio) {
        currentStatementAudio.pause();
        currentStatementAudio.currentTime = 0;
      }
    };
  }, [currentIndex, gameState, isMuted]);

  const playClickSound = () => {
    if (!isMuted) {
      const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/click.mp3');
      console.log('Playing click sound');
      audio.play().catch(err => console.error('Click sound failed:', err));
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (currentStatementAudio && !isMuted) {
      currentStatementAudio.pause();
    }
  };

  const handleShowInstructions = () => {
    playClickSound();
    setGameState('instructions');
  };

  const handleStartGame = () => {
    playClickSound();
    setGameState('playing');
    setCurrentIndex(0);
    setScore(0);
  };

  const handleAnswer = (answer: 'Assertive' | 'Passive' | 'Aggressive') => {
    playClickSound();
    
    // Stop current statement audio immediately
    if (currentStatementAudio) {
      currentStatementAudio.pause();
      currentStatementAudio.currentTime = 0;
      setCurrentStatementAudio(null);
    }
    
    const currentStatement = statements[currentIndex];
    const isCorrect = answer === currentStatement.correctAnswer;
    
    setFeedback(isCorrect ? 'correct' : 'incorrect');
    
    const newScore = isCorrect ? score + 1 : score;
    if (isCorrect) {
      setScore(newScore);
    }

    setTimeout(() => {
      setFeedback(null);
      if (currentIndex < statements.length - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        setGameState('result');
      }
    }, 800);
  };

  const handleRestart = () => {
    playClickSound();
    setGameState('playing');
    setCurrentIndex(0);
    setScore(0);
    setFeedback(null);
  };

  const handleBackToIntro = () => {
    playClickSound();
    setGameState('intro');
    setCurrentIndex(0);
    setScore(0);
    setFeedback(null);
  };

  const currentStatement = statements[currentIndex];
  const progress = ((currentIndex + 1) / statements.length) * 100;

  return (
    <div className="w-full max-w-4xl mx-auto my-4 md:my-12 px-2 md:px-4">
      <AnimatePresence mode="wait">
        {/* Intro State */}
        {gameState === 'intro' && (
          <motion.div
            key="intro"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f0f4f8] rounded-lg p-4 md:p-12 shadow-lg border border-[#d4dce5] text-center relative overflow-hidden min-h-[500px] md:h-[600px] flex items-center"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            {/* Mute Button */}
            <div className="absolute top-4 right-4 z-20">
              <motion.button
                onClick={toggleMute}
                whileHover={{ scale: 1.3, opacity: 1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-gray-500" />
                ) : (
                  <Volume2 className="w-4 h-4 text-gray-500" />
                )}
              </motion.button>
            </div>
            
            <div className="relative z-10">
              
              {/* Thought Bubbles */}
              <div className="flex justify-center items-start gap-2 md:gap-3 mb-2 md:mb-3">
                <motion.img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/happy1.png"
                  alt="Happy thought"
                  className="w-10 h-10 md:w-14 md:h-14 object-contain"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                />
                <motion.img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/sad1.png"
                  alt="Sad thought"
                  className="w-10 h-10 md:w-14 md:h-14 object-contain"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
                />
                <motion.img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/upset1.png"
                  alt="Upset thought"
                  className="w-10 h-10 md:w-14 md:h-14 object-contain"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
                />
              </div>
              
              {/* Woman in Thought */}
              <div className="flex justify-center mb-3 md:mb-4">
                <img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/girl-in-thoughr.png"
                  alt="Woman thinking"
                  className="w-32 h-32 md:w-48 md:h-48 object-contain"
                />
              </div>
              
              <h3 className="text-xl md:text-3xl font-[outfit] tracking-wider uppercase mb-2 md:mb-3 text-gray-900" style={{ fontWeight: 900 }}>
                Communication Challenge
              </h3>
              <p className="text-base md:text-xl font-[outfit] tracking-wide text-gray-700 mb-1 md:mb-2" style={{ fontWeight: 600 }}>
                Test Your Communication Skills
              </p>
              <p className="text-sm md:text-base text-gray-600 mb-4 md:mb-6 font-[outfit] tracking-wide max-w-2xl mx-auto px-2">
                Can you identify <b>assertive, passive,</b> and <b>aggressive</b> communication styles?
              </p>
              
              <motion.button
                onClick={handleShowInstructions}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 md:px-8 py-3 md:py-4 bg-[#d97242] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#c36538] transition-all inline-flex items-center gap-2 text-sm md:text-base"
                style={{ fontWeight: 700 }}
              >
                Start Challenge
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5" />
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Instructions State */}
        {gameState === 'instructions' && (
          <motion.div
            key="instructions"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f0f4f8] rounded-lg p-4 md:p-12 shadow-lg border border-[#d4dce5] text-center relative overflow-hidden min-h-[500px] md:h-[600px] flex items-center"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            {/* Mute Button */}
            <div className="absolute top-4 right-4 z-20">
              <motion.button
                onClick={toggleMute}
                whileHover={{ scale: 1.1, opacity: 1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-gray-500" />
                ) : (
                  <Volume2 className="w-4 h-4 text-gray-500" />
                )}
              </motion.button>
            </div>
            
            <div className="relative z-10 w-full">
              <h3 className="text-2xl md:text-4xl font-[outfit] tracking-wider uppercase mb-4 md:mb-8 text-gray-900" style={{ fontWeight: 900 }}>
                How to Play
              </h3>
              
              <div className="text-left space-y-3 md:space-y-4 mb-6 md:mb-8 bg-white/60 p-4 md:p-8 rounded-lg max-w-2xl mx-auto">
                <ul className="list-disc list-inside space-y-2 md:space-y-3 text-base md:text-xl text-gray-700 font-[outfit]">
                  <li>Read workplace statements one by one</li>
                  <li>Identify if each is <strong>Assertive</strong>, <strong>Passive</strong>, or <strong>Aggressive</strong></li>
                  <li>Complete all {statements.length} statements to see your score</li>
                </ul>
              </div>
              
              <motion.button
                onClick={handleStartGame}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 md:px-8 py-3 md:py-4 bg-[#d97242] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#c36538] transition-all inline-flex items-center gap-2 text-sm md:text-base"
                style={{ fontWeight: 700 }}
              >
                Start
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5" />
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Playing State */}
        {gameState === 'playing' && (
          <motion.div
            key="playing"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f0f4f8] rounded-lg p-4 md:p-12 shadow-lg border border-[#d4dce5] min-h-[500px] md:h-[600px] flex flex-col relative overflow-hidden"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            {/* Mute Button */}
            <div className="absolute top-4 right-4 z-20">
              <motion.button
                onClick={toggleMute}
                whileHover={{ scale: 1.1, opacity: 1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-gray-500" />
                ) : (
                  <Volume2 className="w-4 h-4 text-gray-500" />
                )}
              </motion.button>
            </div>
            
            <div className="relative z-10 flex-1 flex flex-col">
              {/* Header */}
              <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-4 md:mb-8 gap-3 md:gap-4">
                <div className="flex-1">
                  <h3 className="text-base md:text-2xl font-[outfit] tracking-wider text-gray-900 mb-2 md:mb-3" style={{ fontWeight: 700 }}>
                    Statement {currentIndex + 1} of {statements.length}
                  </h3>
                  <div className="w-full bg-white/50 h-2 md:h-3 rounded-full shadow-inner">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${progress}%` }}
                      className="h-2 md:h-3 rounded-full bg-gradient-to-r from-[#d97242] to-[#c36538] transition-all duration-300 shadow-sm"
                    ></motion.div>
                  </div>
                </div>
                
                <div className="text-center md:text-right md:ml-8">
                  <div className="inline-block bg-white/70 px-4 md:px-6 py-2 md:py-3 rounded-lg shadow-sm">
                    <div className="text-xs md:text-sm text-gray-600 font-[outfit] tracking-wide mb-1" style={{ fontWeight: 500 }}>SCORE</div>
                    <div className="text-2xl md:text-3xl font-[outfit] tracking-wider text-[#7b9eb5]" style={{ fontWeight: 900 }}>
                      {score}/{statements.length}
                    </div>
                  </div>
                </div>
              </div>

              {/* Statement */}
              <div className="flex-1 flex items-center justify-center mb-4 md:mb-8">
                <div 
                  className="p-4 md:p-12 rounded-xl bg-white shadow-lg border-2 border-[#d4dce5] w-full max-w-3xl"
                >
                  <p className="text-base md:text-2xl text-center leading-relaxed text-gray-800 font-[outfit] tracking-wide" style={{ fontWeight: 500 }}>
                    "{currentStatement.text}"
                  </p>
                </div>
              </div>

              {/* Question */}
              <div className="text-center mb-3 md:mb-6">
                <p className="text-sm md:text-xl font-[outfit] tracking-wide text-gray-700" style={{ fontWeight: 600 }}>
                  What type of communication is this?
                </p>
              </div>

              {/* Answer Buttons */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-6">
                <motion.button
                  onClick={() => handleAnswer('Assertive')}
                  disabled={feedback !== null}
                  whileTap={feedback === null ? { scale: 0.98 } : {}}
                  className={`py-3 md:py-5 px-4 md:px-6 rounded-lg text-sm md:text-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg ${
                    feedback === 'correct' && currentStatement.correctAnswer === 'Assertive'
                      ? 'ring-4 ring-green-400 bg-[#7b9eb5] text-white shadow-lg'
                      : feedback === 'incorrect' && currentStatement.correctAnswer === 'Assertive'
                      ? 'ring-4 ring-red-400 bg-[#7b9eb5] text-white shadow-lg'
                      : 'bg-[#7b9eb5] text-white hover:bg-[#6a8ea4]'
                  }`}
                  style={{ fontWeight: 700 }}
                >
                  Assertive
                </motion.button>

                <motion.button
                  onClick={() => handleAnswer('Passive')}
                  disabled={feedback !== null}
                  whileTap={feedback === null ? { scale: 0.98 } : {}}
                  className={`py-3 md:py-5 px-4 md:px-6 rounded-lg text-sm md:text-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg ${
                    feedback === 'correct' && currentStatement.correctAnswer === 'Passive'
                      ? 'ring-4 ring-green-400 bg-[#e8b89e] text-gray-800 shadow-lg'
                      : feedback === 'incorrect' && currentStatement.correctAnswer === 'Passive'
                      ? 'ring-4 ring-red-400 bg-[#e8b89e] text-gray-800 shadow-lg'
                      : 'bg-[#e8b89e] text-gray-800 hover:bg-[#daa68a]'
                  }`}
                  style={{ fontWeight: 700 }}
                >
                  Passive
                </motion.button>

                <motion.button
                  onClick={() => handleAnswer('Aggressive')}
                  disabled={feedback !== null}
                  whileTap={feedback === null ? { scale: 0.98 } : {}}
                  className={`py-3 md:py-5 px-4 md:px-6 rounded-lg text-sm md:text-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg ${
                    feedback === 'correct' && currentStatement.correctAnswer === 'Aggressive'
                      ? 'ring-4 ring-green-400 bg-[#d97242] text-white shadow-lg'
                      : feedback === 'incorrect' && currentStatement.correctAnswer === 'Aggressive'
                      ? 'ring-4 ring-red-400 bg-[#d97242] text-white shadow-lg'
                      : 'bg-[#d97242] text-white hover:bg-[#c36538]'
                  }`}
                  style={{ fontWeight: 700 }}
                >
                  Aggressive
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Result State */}
        {gameState === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f5f9fc] rounded-lg p-4 md:p-12 shadow-lg border border-[#d4e3ed] text-center relative overflow-visible min-h-[500px] md:min-h-[600px] flex items-center"
          >
            {/* Mute Button */}
            <div className="absolute top-4 right-4 z-20">
              <motion.button
                onClick={toggleMute}
                whileHover={{ scale: 1.1, opacity: 1 }}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                aria-label={isMuted ? 'Unmute' : 'Mute'}
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-gray-500" />
                ) : (
                  <Volume2 className="w-4 h-4 text-gray-500" />
                )}
              </motion.button>
            </div>
            
            <div className="relative z-10 w-full">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="inline-block relative mb-2 md:mb-3"
              >
                {/* Main image - girl with thumbs up */}
                <img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/girl-thumbs.png" 
                  alt="Success"
                  className="w-24 md:w-32 h-auto"
                />
                {/* Floating image above */}
                <motion.img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/happy1.png"
                  alt="Happy"
                  className="absolute -top-4 -left-4 w-12 md:w-16 h-auto"
                  animate={{ 
                    y: [0, -10, 0],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ 
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
              </motion.div>

              <h3 className="text-xl md:text-3xl font-[outfit] tracking-wider uppercase mb-2 text-gray-900" style={{ fontWeight: 900 }}>
                Challenge Complete! 🎉
              </h3>
              
              <p className="text-lg md:text-2xl mb-2 font-[outfit] tracking-wider text-[#4288b5]" style={{ fontWeight: 900 }}>
                Score: {score}/{statements.length} ({Math.round((score / statements.length) * 100)}%)
              </p>
              
              <p className="text-base md:text-xl text-gray-700 mt-4 md:mt-6 mb-4 md:mb-6 font-[outfit] tracking-wide max-w-2xl mx-auto px-2">
                {score === statements.length ? 'Perfect! You have an excellent understanding of communication styles!' :
                 score >= statements.length * 0.75 ? 'Great job! You have a strong grasp of communication styles.' :
                 score >= statements.length * 0.5 ? 'Good effort! Keep practicing to improve your recognition skills.' :
                 'Keep learning! Review the differences between each style and try again.'}
              </p>

              {/* Quick Reference Toggle Button */}
              <motion.button
                onClick={() => {
                  playClickSound();
                  setShowQuickReference(!showQuickReference);
                }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="mb-4 px-4 md:px-6 py-2 md:py-3 bg-white/70 hover:bg-white/90 rounded-lg font-[outfit] tracking-wider text-gray-800 shadow-md hover:shadow-lg transition-all inline-flex items-center gap-2 border border-[#d4dce5] text-sm md:text-base"
                style={{ fontWeight: 600 }}
              >
                📖 View Quick Reference
              </motion.button>

              <div className="flex flex-wrap justify-center gap-2 md:gap-3">
                <motion.button
                  onClick={handleRestart}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 md:px-6 py-2 md:py-3 bg-[#d97242] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#c36538] transition-all inline-flex items-center gap-2 text-sm md:text-base"
                  style={{ fontWeight: 700 }}
                >
                  <RefreshCw className="w-4 h-4 md:w-5 md:h-5" />
                  Play Again
                </motion.button>
                
                <motion.button
                  onClick={handleBackToIntro}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 md:px-6 py-2 md:py-3 bg-white border-2 border-[#d4c5e8] text-[#8b7ba8] rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl transition-all inline-flex items-center gap-2 text-sm md:text-base"
                  style={{ fontWeight: 700 }}
                >
                  Back to Start
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Reference Popup Overlay */}
      <AnimatePresence>
        {showQuickReference && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={() => {
              playClickSound();
              setShowQuickReference(false);
            }}
          >
            {/* Backdrop */}
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
            
            {/* Modal Content */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative bg-white rounded-lg p-8 max-w-3xl w-full shadow-2xl border-2 border-[#d4dce5] max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => {
                  playClickSound();
                  setShowQuickReference(false);
                }}
                className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                aria-label="Close"
              >
                ✕
              </button>

              <h4 className="text-2xl font-[outfit] tracking-wider mb-6 text-gray-900 text-center" style={{ fontWeight: 700 }}>
                Communication Styles Reference
              </h4>
              <div className="grid gap-6">
                <div className="bg-[#e8f4f8] p-6 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-[#487698] text-lg mb-3" style={{ fontWeight: 700 }}>
                    ✓ Assertive Communication
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    Clear, respectful, and solution-focused. Expresses needs and boundaries while respecting others. Promotes collaboration and mutual understanding.
                  </p>
                </div>
                <div className="bg-[#f5ede8] p-6 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-[#8E7F7A] text-lg mb-3" style={{ fontWeight: 700 }}>
                    ✓ Passive Communication
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    Indirect, avoidant, and self-sacrificing. Struggles to express needs or set boundaries. Often leads to resentment and miscommunication.
                  </p>
                </div>
                <div className="bg-[#f9e8e0] p-6 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-[#d97242] text-lg mb-3" style={{ fontWeight: 700 }}>
                    ✓ Aggressive Communication
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    Blaming, hostile, and confrontational. Prioritizes own needs at the expense of others. Creates defensiveness and damages relationships.
                  </p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}