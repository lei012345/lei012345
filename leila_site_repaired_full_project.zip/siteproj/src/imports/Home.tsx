import { Navigation } from "../components/Navigation";
import { AboutAnimated } from "../components/AboutAnimated";
import { Projects } from "../components/Projects";
import { DesignProcess } from "../components/DesignProcess";
import { StandaloneBonusGame } from "../components/ui/StandaloneBonusGame";
import { Contact } from "../components/Contact";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";
import { motion } from "motion/react";
import pointerHand from "figma:asset/971f514c24b6bc492cd618ec01a3f2084d09cbfa.png";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";

export function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      {/* Add padding top to account for fixed navigation */}
      <main className="pt-0">
        <AboutAnimated />
        
        {/* Design Process Section */}
        <section id="process" className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30">
          <div className="max-w-[1400px] mx-auto">
            <div className="mb-12 text-center">
              <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] tracking-wider uppercase" style={{ fontWeight: 900 }}>
                My Design Process
              </h2>
              <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
                A systematic approach to creating meaningful design solutions
              </p>
            </div>
            <DesignProcess />
          </div>
        </section>
        
        {/* Interactive Game Section */}
        <section id="game" className="py-16 px-4 md:px-8 lg:px-12">
          <div className="max-w-[1400px] mx-auto">
            {/* Mobile: Title at top */}
            <div className="lg:hidden text-center mb-8 space-y-6">
              <h2 className="text-4xl md:text-5xl font-[outfit] tracking-wider uppercase text-gray-900 relative inline-block" style={{ fontWeight: 900 }}>
                <motion.img 
                  src={pointerHand}
                  alt="pointer hand"
                  className="h-20 md:h-40 absolute -top-20 md:-top-36 left-1/2 transform -translate-x-1/2"
                  animate={{ y: [0, -10, 0] }}
                  transition={{ 
                    duration: 2.5, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                  }}
                />
                Try It Yourself
              </h2>
              <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
               Get a glimpse into my interactive instruction style by completing this challenge!
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              {/* Left Column - Communication Challenge Game */}
              <div>
                <StandaloneBonusGame />
              </div>
              
              {/* Right Column - Title and Button (Desktop only) */}
              <div className="hidden lg:block space-y-6">
                <h2 className="text-4xl md:text-5xl font-[outfit] tracking-wider uppercase text-gray-900 relative inline-block" style={{ fontWeight: 900 }}>
                  <motion.img 
                    src={pointerHand}
                    alt="pointer hand"
                    className="h-32 md:h-40 absolute -top-36 md:-top-48 left-1/2 transform -translate-x-1/2"
                    animate={{ y: [0, -10, 0] }}
                    transition={{ 
                      duration: 2.5, 
                      repeat: Infinity, 
                      ease: "easeInOut" 
                    }}
                  />
                  Try It Yourself
                </h2>
                <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
                 Get a glimpse into my interactive instruction style by completing this challenge!
                </p>
                
                {/* More Challenges Link - Desktop */}
                <Link to="/game" className="flex justify-center">
                  <motion.div
                    whileHover={{ x: 5 }}
                    className="font-[outfit] tracking-wider text-[#6b5b95] cursor-pointer inline-flex items-center gap-3 text-[32px]"
                    style={{ fontWeight: 200 }}
                  >
                    MORE
                    <ArrowRight className="w-10 h-10 md:w-12 md:h-14" />
                  </motion.div>
                </Link>
              </div>
            </div>

            {/* Mobile: MORE link at bottom */}
            <div className="lg:hidden mt-8">
              <Link to="/game" className="flex justify-center">
                <motion.div
                  whileHover={{ x: 5 }}
                  className="font-[outfit] tracking-wider text-[#6b5b95] cursor-pointer inline-flex items-center gap-3 text-[32px]"
                  style={{ fontWeight: 200 }}
                >
                  MORE
                  <ArrowRight className="w-10 h-10 md:w-12 md:h-14" />
                </motion.div>
              </Link>
            </div>
          </div>
        </section>
        
        <Projects />
        
        <Contact />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}