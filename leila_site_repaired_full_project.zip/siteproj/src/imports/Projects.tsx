import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { useState, useEffect, useRef } from "react";
import { Link } from "react-router";
import { useLoading } from "../context/LoadingContext";
import { useInView } from "motion/react";

type Project = typeof portfolioData.projects[number];

function ProjectCard({ project, index, isInView }: { project: Project; index: number; isInView: boolean }) {
  const [hovered, setHovered] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const { showLoading } = useLoading();

  const allPhotos = (project as any).conceptPhotos as string[] | undefined;
  const photos = allPhotos?.filter((src) => src !== project.cardImage);
  const hasPhotos = photos && photos.length > 0;

  useEffect(() => {
    if (hovered && hasPhotos && photos!.length > 1) {
      intervalRef.current = setInterval(() => {
        setActiveIndex((prev) => (prev + 1) % photos!.length);
      }, 1200);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setActiveIndex(0);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [hovered, hasPhotos]);

  return (
    <motion.div
      key={project.id}
      className="group w-full"
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link to={`/project/${project.id}`} className="block" onClick={showLoading}>
        {/* Folder Structure */}
        <div className="relative pt-8">
          {/* Folder Tab - Behind the card */}
          <div className="flex absolute top-0 left-0 z-0">
            <div 
              className="bg-[#f5f2f7] px-6 py-2 flex items-center gap-2 border-t border-2 border-r border-white shadow-lg"
              style={{
                clipPath: 'polygon(8px 0%, calc(100% - 8px) 0%, 100% 100%, 0% 100%)'
              }}
            >
              <span className="text-xs text-[#262626] font-[outfit] tracking-wider" style={{ fontWeight: 600 }}>
                {project.title}
              </span>
            </div>
          </div>

          {/* Folder Body */}
          <motion.div
            className="relative bg-white overflow-hidden transition-all shadow-sm hover:shadow-md z-10"
            whileHover={{ y: -5 }}
            transition={{ duration: 0.2 }}
          >
            {/* Project Image */}
            <div
              className="aspect-[16/10] w-full overflow-hidden bg-gradient-to-br from-muted to-muted/50 relative"
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={() => setHovered(false)}
            >
              {project.cardImage ? (
                <>
                  <img
                    src={project.cardImage}
                    alt={project.title}
                    loading="eager"
                    fetchpriority="high"
                    className={`w-full h-full object-cover transition-transform duration-500 ${hovered ? 'scale-105' : 'scale-100'} ${project.id === 1 ? 'object-top' : ''} ${project.id === 8 ? 'object-[center_40%]' : ''}`}
                  />

                  {/* White Overlay with Logo */}
                  {project.logo && (
                    <div className="absolute inset-0 flex items-center justify-center bg-white/85">
                      {project.id === 9 ? (
                        <h3 className="text-2xl font-[outfit] tracking-wider text-center px-6 text-[#262626]" style={{ fontWeight: 700 }}>
                          Navigating<br />Difficult Conversations at Work
                        </h3>
                      ) : (
                        <img
                          src={project.logo}
                          alt={project.title}
                          className={`w-auto object-contain ${project.id === 1 ? 'h-14' : project.id === 7 ? 'h-20' : project.id === 8 ? 'h-24' : 'h-16'}`}
                        />
                      )}
                    </div>
                  )}

                  {hasPhotos && (
                    <>
                      {photos!.map((src, i) => (
                        <img
                          key={i}
                          src={src}
                          alt={`${project.title} concept ${i + 1}`}
                          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500"
                          style={{ opacity: hovered && activeIndex === i ? 1 : 0 }}
                        />
                      ))}

                      <div
                        className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1 transition-opacity duration-300"
                        style={{ opacity: hovered ? 1 : 0 }}
                      >
                        {photos!.map((_, i) => (
                          <div
                            key={i}
                            className="w-1 h-1 rounded-full transition-all duration-300"
                            style={{
                              background: activeIndex === i ? '#ffffff' : 'rgba(255,255,255,0.45)',
                              transform: activeIndex === i ? 'scale(1.2)' : 'scale(1)',
                            }}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </>
              ) : null}
            </div>
          </motion.div>
        </div>
      </Link>
    </motion.div>
  );
}

export function Projects() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="projects" className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30" ref={ref}>
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2 className="text-4xl md:text-5xl mb-4 uppercase tracking-wider font-[outfit]" style={{ fontWeight: 900 }}>
            Featured Projects
          </h2>
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
            Explore my latest work in web and graphic design
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioData.projects.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} isInView={isInView} />
          ))}
        </div>
      </div>
    </section>
  );
}