import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { Target, Sparkles, RefreshCw, ArrowRight, CheckCircle2, AlertCircle, Lightbulb, Users, BookOpen, Navigation, FileText, Layers } from "lucide-react";
import confusedLearnerImage from 'figma:asset/2284f82d0102a2c6cff9425dc97b0acb070c8837.png';
import successLearnerImage from 'figma:asset/c3dff7d49c2f91f6d47d09a445c321d9cd51b0f1.png';

// Import custom game option images
import clearGoalImage from 'figma:asset/db70a250edcec0b5aa14f70c8a2119bb235b5e0a.png';
import chunkContentImage from 'figma:asset/85523ba20edca8913b6dd7b96c64adc7d6a951c8.png';
import interactiveScenarioImage from 'figma:asset/fb1207658cbffca89c9da54b661a823adcdc570b.png';
import supportiveFeedbackImage from 'figma:asset/05623a762563b73fffe284caff6a27fa0599bc1d.png';
import simplerNavigationImage from 'figma:asset/828b5d23b364cbea260dd34ed3c2bbb1fb4d710d.png';
import moreParagraphsImage from 'figma:asset/8a99366673d71bb7d50c7eade6f843f4d657421a.png';
import hideInstructionsImage from 'figma:asset/9c0fd9255597b4ae62dda69fd405f04802a01b5b.png';
import longPageImage from 'figma:asset/c96bf6234cfbfe7ab60971ad50732d5fd218b950.png';

interface GameOption {
  id: number;
  text: string;
  image: string;
  isGood: boolean;
  points: number;
}

type GameState = 'intro' | 'playing' | 'result';

export function LearningExperienceGame() {
  const [gameState, setGameState] = useState<GameState>('intro');
  const [selectedOptions, setSelectedOptions] = useState<number[]>([]);
  const [showConfetti, setShowConfetti] = useState(false);

  const options: GameOption[] = [
    { id: 1, text: "Clear learning goal", image: clearGoalImage, isGood: true, points: 2 },
    { id: 2, text: "Chunk content into steps", image: chunkContentImage, isGood: true, points: 2 },
    { id: 3, text: "Add interactive scenario", image: interactiveScenarioImage, isGood: true, points: 2 },
    { id: 4, text: "Give supportive feedback", image: supportiveFeedbackImage, isGood: true, points: 2 },
    { id: 5, text: "Use simpler navigation", image: simplerNavigationImage, isGood: true, points: 2 },
    { id: 6, text: "Add 5 more paragraphs", image: moreParagraphsImage, isGood: false, points: 0 },
    { id: 7, text: "Hide instructions in dropdowns", image: hideInstructionsImage, isGood: false, points: 0 },
    { id: 8, text: "Put everything on one long page", image: longPageImage, isGood: false, points: 1 },
  ];

  const handleOptionClick = (optionId: number) => {
    if (selectedOptions.includes(optionId)) {
      setSelectedOptions(selectedOptions.filter(id => id !== optionId));
    } else if (selectedOptions.length < 3) {
      setSelectedOptions([...selectedOptions, optionId]);
    }
  };

  const calculateScore = () => {
    return selectedOptions.reduce((total, optionId) => {
      const option = options.find(opt => opt.id === optionId);
      return total + (option?.points || 0);
    }, 0);
  };

  const getResultMessage = () => {
    const score = calculateScore();
    if (score >= 5) {
      return {
        title: "Excellent Choice! 🌟",
        message: "You prioritized clarity, engagement, and support. Your choices help reduce cognitive overload and support learner confidence.",
        percentage: 95
      };
    } else if (score >= 3) {
      return {
        title: "Great Start! ✨",
        message: "You helped the learner succeed. A few adjustments could make the experience even stronger.",
        percentage: 75
      };
    } else {
      return {
        title: "You Improved the Experience! 💡",
        message: "Good learning design is all about thoughtful choices. Keep experimenting!",
        percentage: 60
      };
    }
  };

  const handleSeeResult = () => {
    setGameState('result');
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 3000);
  };

  const handlePlayAgain = () => {
    setSelectedOptions([]);
    setGameState('playing');
    setShowConfetti(false);
  };

  const handleStart = () => {
    setGameState('playing');
    setSelectedOptions([]);
    setShowConfetti(false);
  };

  return (
    <div className="w-full max-w-4xl mx-auto my-12 px-4">
      <AnimatePresence mode="wait">
        {/* Intro State */}
        {gameState === 'intro' && (
          <motion.div
            key="intro"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f0f4f8] rounded-lg p-8 md:p-12 shadow-lg border border-[#d4dce5] text-center relative overflow-hidden"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#e8dff5]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            <div className="relative z-10">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="inline-block p-4 bg-white rounded-lg shadow-md mb-6"
              >
                <Lightbulb className="w-12 h-12 text-[#e0b668]" />
              </motion.div>
              
              <h3 className="text-3xl md:text-4xl font-[outfit] tracking-wider uppercase mb-4 text-gray-900" style={{ fontWeight: 900 }}>
                Mini Challenge
              </h3>
              <p className="text-xl md:text-2xl font-[outfit] tracking-wide text-gray-700 mb-3" style={{ fontWeight: 600 }}>
                Build a Better Learning Experience
              </p>
              <p className="text-lg text-gray-600 mb-8 font-[outfit] tracking-wide max-w-2xl mx-auto">
                Can you help this learner succeed in under 30 seconds?
              </p>
              
              <motion.button
                onClick={handleStart}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 bg-[#7b9eb5] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#6a8ea4] transition-all inline-flex items-center gap-2"
                style={{ fontWeight: 700 }}
              >
                Start Challenge
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Playing State */}
        {gameState === 'playing' && (
          <motion.div
            key="playing"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-lg p-8 md:p-10 shadow-lg border border-gray-100"
          >
            {/* Scenario */}
            <div className="mb-8 text-center">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-[#e3f2fd] rounded-md mb-4">
                <Users className="w-4 h-4 text-[#5b8faa]" />
                <span className="text-sm font-[outfit] tracking-wider text-[#5b8faa]" style={{ fontWeight: 700 }}>
                  SCENARIO
                </span>
              </div>
              
              {/* Confused Learner Image */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mb-6 flex justify-center"
              >
                <img 
                  src={confusedLearnerImage} 
                  alt="Confused learner at computer" 
                  className="w-full max-w-md rounded-lg shadow-md"
                />
              </motion.div>
              
              <p className="text-xl md:text-2xl font-[outfit] tracking-wide text-gray-800 mb-2" style={{ fontWeight: 400 }}>
                Jordan is taking an online training, but feels <span className="font-bold">overwhelmed</span>, <span className="font-bold">bored</span>, and <span className="font-bold">unsure</span> what to do next.
              </p>
              <p className="text-lg font-[outfit] tracking-wide text-gray-600">
                Choose <span className="font-bold text-[#8b7ba8]">3 design improvements</span> to help Jordan succeed.
              </p>
            </div>

            {/* Selected Counter */}
            <div className="flex justify-center mb-6">
              <div className="px-6 py-3 bg-[#f3eff8] rounded-md border border-[#d4c5e8]">
                <span className="font-[outfit] tracking-wider text-gray-700" style={{ fontWeight: 700 }}>
                  Selected: <span className="text-[#8b7ba8] text-xl">{selectedOptions.length}</span> of 3
                </span>
              </div>
            </div>

            {/* Options Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              {options.map((option, index) => {
                const isSelected = selectedOptions.includes(option.id);
                
                return (
                  <motion.button
                    key={option.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    onClick={() => handleOptionClick(option.id)}
                    disabled={!isSelected && selectedOptions.length >= 3}
                    className={`p-5 rounded-lg border-2 transition-all text-left relative overflow-hidden ${
                      isSelected
                        ? 'border-[#8b7ba8] bg-[#f3eff8] shadow-lg scale-105'
                        : 'border-gray-200 bg-white hover:border-[#b5a8c5] hover:shadow-md'
                    } ${!isSelected && selectedOptions.length >= 3 ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
                    whileHover={isSelected || selectedOptions.length < 3 ? { scale: 1.05 } : {}}
                    whileTap={isSelected || selectedOptions.length < 3 ? { scale: 0.95 } : {}}
                  >
                    {isSelected && (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute top-2 right-2"
                      >
                        <div className="w-6 h-6 bg-[#8b7ba8] rounded-full flex items-center justify-center">
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </div>
                      </motion.div>
                    )}
                    
                    <img 
                      src={option.image} 
                      alt={option.text} 
                      className="w-20 h-20 mb-3 object-cover rounded-md bg-gray-50 p-2 mx-auto"
                    />
                    <p className="font-[outfit] tracking-wide text-base leading-relaxed text-center" style={{ fontWeight: 600 }}>
                      {option.text}
                    </p>
                  </motion.button>
                );
              })}
            </div>

            {/* See Result Button */}
            <div className="text-center">
              <motion.button
                onClick={handleSeeResult}
                disabled={selectedOptions.length !== 3}
                whileHover={selectedOptions.length === 3 ? { scale: 1.05 } : {}}
                whileTap={selectedOptions.length === 3 ? { scale: 0.95 } : {}}
                className={`px-10 py-4 rounded-md font-[outfit] tracking-wider shadow-lg inline-flex items-center gap-2 transition-all ${
                  selectedOptions.length === 3
                    ? 'bg-[#7b9eb5] text-white hover:shadow-xl hover:bg-[#6a8ea4] cursor-pointer'
                    : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                }`}
                style={{ fontWeight: 700 }}
              >
                See Result
                <ArrowRight className="w-5 h-5" />
              </motion.button>
            </div>
          </motion.div>
        )}

        {/* Result State */}
        {gameState === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.5 }}
            className="bg-[#f5f9fc] rounded-lg p-8 md:p-12 shadow-lg border border-[#d4e3ed] text-center relative overflow-hidden"
          >
            {/* Confetti Effect */}
            {showConfetti && (
              <div className="absolute inset-0 pointer-events-none">
                {[...Array(30)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ y: -20, x: Math.random() * 100 + '%', opacity: 1 }}
                    animate={{ y: '100vh', opacity: 0 }}
                    transition={{ duration: Math.random() * 2 + 1, delay: Math.random() * 0.5 }}
                    className="absolute w-2 h-2 rounded-full"
                    style={{
                      backgroundColor: ['#ec4899', '#8b5cf6', '#3b82f6', '#fbbf24', '#10b981'][i % 5],
                      left: Math.random() * 100 + '%'
                    }}
                  />
                ))}
              </div>
            )}

            <div className="relative z-10">
              {/* Success Icon */}
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mb-6 flex justify-center"
              >
                <img 
                  src={successLearnerImage} 
                  alt="Happy learner celebrating success" 
                  className="w-full max-w-md rounded-lg shadow-md"
                />
              </motion.div>

              {/* Result Message */}
              <motion.h3
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-3xl md:text-4xl font-[outfit] tracking-wider uppercase mb-4 text-gray-900"
                style={{ fontWeight: 900 }}
              >
                {getResultMessage().title}
              </motion.h3>
              
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-lg md:text-xl text-gray-700 mb-8 font-[outfit] tracking-wide max-w-2xl mx-auto leading-relaxed"
              >
                {getResultMessage().message}
              </motion.p>

              {/* Progress Bar */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="max-w-md mx-auto mb-8"
              >
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-[outfit] tracking-wider text-gray-600" style={{ fontWeight: 700 }}>
                    EXPERIENCE IMPROVED
                  </span>
                  <span className="text-2xl font-[outfit] tracking-wider text-[#8b7ba8]" style={{ fontWeight: 900 }}>
                    {getResultMessage().percentage}%
                  </span>
                </div>
                <div className="h-4 bg-gray-200 rounded-md overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${getResultMessage().percentage}%` }}
                    transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
                    className="h-full bg-[#8b7ba8] rounded-md"
                  />
                </div>
              </motion.div>

              {/* Buttons */}
              <div className="flex flex-wrap justify-center gap-4">
                <motion.button
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6 }}
                  onClick={handlePlayAgain}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-[#7b9eb5] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#6a8ea4] transition-all inline-flex items-center gap-2"
                  style={{ fontWeight: 700 }}
                >
                  <RefreshCw className="w-5 h-5" />
                  Play Again
                </motion.button>
                
                <motion.a
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.7 }}
                  href="/#projects"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-8 py-4 bg-white border-2 border-[#b5a8c5] text-[#6b5b95] rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl transition-all inline-flex items-center gap-2"
                  style={{ fontWeight: 700 }}
                >
                  View My Portfolio
                  <ArrowRight className="w-5 h-5" />
                </motion.a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}