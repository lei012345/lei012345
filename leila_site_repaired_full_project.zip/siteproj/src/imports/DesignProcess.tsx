import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import Lottie from "lottie-react";
import imaginaryAnimation from "../../imports/Imaginary.json";
import typingAnimation from "../../imports/Typing.json";
import analyticsAnimation from "../../imports/analytics.json";
import hrAnimation from "../../imports/Hr.json";
import editAnimation from "../../imports/edit.json";

export function DesignProcess() {
  if (!portfolioData.designProcess || portfolioData.designProcess.length === 0) {
    return null;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
      {portfolioData.designProcess.map((step, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
          className="relative"
        >
          <div className="bg-white rounded-lg p-5 shadow-sm hover:shadow-md transition-all border border-gray-100 h-full flex flex-col">
            {/* Phase number and icon */}
            <div className="flex items-center gap-3 mb-3">
              {/* Show Lottie animations for all phases */}
              {index === 0 ? (
                <div className="w-20 h-20 flex items-center justify-center">
                  <Lottie 
                    animationData={imaginaryAnimation} 
                    loop={true}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
              ) : index === 1 ? (
                <div className="w-20 h-20 flex items-center justify-center">
                  <Lottie 
                    animationData={editAnimation} 
                    loop={true}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
              ) : index === 2 ? (
                <div className="w-20 h-20 flex items-center justify-center">
                  <Lottie 
                    animationData={typingAnimation} 
                    loop={true}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
              ) : index === 3 ? (
                <div className="w-20 h-20 flex items-center justify-center">
                  <Lottie 
                    animationData={hrAnimation} 
                    loop={true}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
              ) : index === 4 ? (
                <div className="w-20 h-20 flex items-center justify-center">
                  <Lottie 
                    animationData={analyticsAnimation} 
                    loop={true}
                    style={{ width: '100%', height: '100%' }}
                  />
                </div>
              ) : (
                <div className="text-3xl">{step.icon}</div>
              )}
            </div>

            {/* Phase name */}
            <h4 className="font-[outfit] tracking-wider uppercase text-lg text-gray-900 mb-2" style={{ fontWeight: 900 }}>
              {step.phase}
            </h4>

            {/* Description */}
            <p className="text-sm text-gray-600 font-[outfit] tracking-wide leading-relaxed mb-4 flex-grow">
              {step.description}
            </p>

            {/* Activities */}
            {step.activities && step.activities.length > 0 && (
              <div className="mt-auto">
                
                <ul className="space-y-1" role="list">
                  {step.activities.map((activity, actIndex) => (
                    null
                  ))}
                </ul>
              </div>
            )}
          </div>
        </motion.div>
      ))}
    </div>
  );
}