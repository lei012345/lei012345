import image_36fa19961c80c3544217481b4c6561bc5f35e9d8 from 'figma:asset/36fa19961c80c3544217481b4c6561bc5f35e9d8.png'
import image_4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04 from 'figma:asset/4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04.png'
import image_dc4e18ba35d0ced21cd143a575da00bab9af844e from 'figma:asset/dc4e18ba35d0ced21cd143a575da00bab9af844e.png'
import image_0cc03541e8cef4f3915a5cedf29f6512201349e7 from 'figma:asset/0cc03541e8cef4f3915a5cedf29f6512201349e7.png'
import { useParams, Link } from "react-router";
import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { ArrowLeft, ExternalLink, Github, Sparkles, Target, Users, Lightbulb, TrendingUp, CheckCircle2, AlertCircle, BookOpen, Briefcase, Clock, Rocket } from "lucide-react";
import { useEffect, useState } from "react";

export function ProjectDetail() {
  const { id } = useParams();
  const project = portfolioData.projects.find((p) => p.id === Number(id));
  const [activeSection, setActiveSection] = useState<string>('overview');

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <div className="text-center">
          <h1 className="text-4xl mb-4 font-[outfit] tracking-wider" style={{ fontWeight: 800 }}>
            Project Not Found
          </h1>
          <Link
            to="/"
            className="text-blue-500 hover:underline inline-flex items-center gap-2 font-[outfit] tracking-wider"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  // Check if this is an ID/LXD project (has the new metadata fields)
  const isIDProject = !!(project as any).role || !!(project as any).learningObjectives;

  // For non-ID projects, show the original layout
  if (!isIDProject) {
    return (
      <div className="min-h-screen bg-[#f0f9ff]">
        {/* Back Button */}
        <motion.div
          className="fixed top-6 left-6 z-50"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Link
            to="/"
            className="flex items-center gap-2 px-4 py-2 bg-white border border-border/50 rounded-full shadow-lg hover:shadow-xl transition-all font-[outfit] tracking-wider"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm" style={{ fontWeight: 600 }}>
              Back
            </span>
          </Link>
        </motion.div>

        {/* Hero Section */}
        <section className="pt-32 pb-20 px-6 relative overflow-hidden">
          <div className="max-w-7xl mx-auto relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              {/* Left Column - Project Info */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-8"
              >
                {/* Main Info Container */}
                <div>
                  {/* Project icon */}
                  <div className="w-full max-w-2xl rounded-2xl overflow-hidden mb-6 relative">
                    <img 
                      src={image_4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04} 
                      alt={project.title}
                      className="w-full h-auto"
                    />
                  </div>

                  <p className="text-xl text-muted-foreground mb-8 max-w-3xl font-[outfit] tracking-wide">
                    {project.detailedDescription || project.description}
                  </p>

                  {/* Action buttons */}
                  <div className="flex flex-wrap gap-4">
                    <motion.a
                      href={project.liveUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`px-6 py-3 bg-gradient-to-r ${project.color} text-white rounded-full inline-flex items-center gap-2 hover:shadow-lg transition-shadow font-[outfit] tracking-wider`}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{ fontWeight: 700 }}
                    >
                      View Live Site <ExternalLink className="w-4 h-4" />
                    </motion.a>
                    <motion.a
                      href={project.githubUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-6 py-3 bg-white border-2 border-foreground/10 rounded-full inline-flex items-center gap-2 hover:border-foreground/30 transition-colors font-[outfit] tracking-wider"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      style={{ fontWeight: 700 }}
                    >
                      <Github className="w-4 h-4" />
                      GitHub
                    </motion.a>
                  </div>
                </div>

                {/* Features Container */}
                <div className="bg-white rounded-2xl p-8 md:p-10 shadow-sm">
                  <h2 className="text-3xl mb-8 font-[outfit] tracking-wider" style={{ fontWeight: 800 }}>
                    Features
                  </h2>
                  <div className="space-y-4">
                    {project.features.map((feature, index) => (
                      <motion.div
                        key={index}
                        className="flex items-start gap-4 p-5 bg-gray-50 rounded-xl shadow-sm border border-border/50 hover:shadow-md transition-shadow"
                        initial={{ opacity: 0, x: -20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                        viewport={{ once: true }}
                      >
                        <Sparkles className="w-5 h-5 text-pink-400 flex-shrink-0 mt-0.5" />
                        <p className="text-foreground/80 font-[outfit] tracking-wide">{feature}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>

              {/* Right Column - Mobile Preview */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="flex justify-center lg:justify-end lg:sticky lg:top-32"
              >
                <div className="relative">
                  {/* Phone Frame */}
                  <div className="relative bg-black rounded-[2.5rem] p-2.5 shadow-2xl">
                    {/* Notch */}
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-black rounded-b-3xl z-10"></div>
                    
                    {/* Screen */}
                    <div className="bg-white rounded-[2rem] overflow-hidden w-[440px] h-[800px] relative">
                      <iframe
                        src={project.liveUrl}
                        className="w-full h-full border-0"
                        title={`${project.title} Preview`}
                        sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                      />
                    </div>
                  </div>

                  {/* Phone Buttons */}
                  <div className="absolute right-0 top-20 w-1 h-10 bg-black rounded-l-lg"></div>
                  <div className="absolute right-0 top-32 w-1 h-14 bg-black rounded-l-lg"></div>
                  <div className="absolute right-0 top-48 w-1 h-14 bg-black rounded-l-lg"></div>
                  <div className="absolute left-0 top-28 w-1 h-7 bg-black rounded-r-lg"></div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Back to Projects */}
        <section className="py-12 px-6">
          <div className="max-w-5xl mx-auto text-center">
            <Link
              to="/#projects"
              className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-blue-400 to-cyan-400 text-white rounded-full hover:shadow-lg transition-shadow font-[outfit] tracking-wider"
              style={{ fontWeight: 700 }}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to All Projects
            </Link>
          </div>
        </section>
      </div>
    );
  }

  // ID/LXD Project Layout
  const projectData = project as any;
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      {/* Back Button */}
      <motion.div
        className="fixed top-6 left-6 z-50"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link
          to="/"
          className="flex items-center gap-2 px-5 py-2.5 bg-white border border-gray-200 rounded-full shadow-lg hover:shadow-xl transition-all font-[outfit] tracking-wider"
        >
          <ArrowLeft className="w-4 h-4 text-gray-700" />
          <span className="text-sm text-gray-900" style={{ fontWeight: 600 }}>
            Back
          </span>
        </Link>
      </motion.div>

      {/* Hero Section */}
      <section className="pt-28 pb-16 px-6 relative overflow-hidden">
        <div className="max-w-6xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            {/* Project Title */}
            <motion.h1 
              className="text-5xl md:text-6xl font-[outfit] tracking-wider uppercase mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
              style={{ fontWeight: 900 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              {projectData.title === "ID-Project-1" ? "Navigating Difficult Conversations at Work" : project.title}
            </motion.h1>

            {/* Quick Info Cards */}
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-4 gap-4 max-w-5xl mx-auto mt-10"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
            >
              {projectData.projectType && (
                <div className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all border border-blue-100">
                  <div className="flex items-center gap-2 mb-2">
                    <BookOpen className="w-5 h-5 text-blue-500" />
                    <p className="text-xs uppercase tracking-wider text-gray-500 font-[outfit]" style={{ fontWeight: 700 }}>Type</p>
                  </div>
                  <p className="text-sm text-gray-900 font-[outfit] tracking-wide" style={{ fontWeight: 600 }}>{projectData.projectType}</p>
                </div>
              )}
              
              {projectData.role && (
                <div className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all border border-purple-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Briefcase className="w-5 h-5 text-purple-500" />
                    <p className="text-xs uppercase tracking-wider text-gray-500 font-[outfit]" style={{ fontWeight: 700 }}>My Role</p>
                  </div>
                  <p className="text-sm text-gray-900 font-[outfit] tracking-wide" style={{ fontWeight: 600 }}>{projectData.role}</p>
                </div>
              )}
              
              {projectData.duration && (
                <div className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all border border-pink-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="w-5 h-5 text-pink-500" />
                    <p className="text-xs uppercase tracking-wider text-gray-500 font-[outfit]" style={{ fontWeight: 700 }}>Duration</p>
                  </div>
                  <p className="text-sm text-gray-900 font-[outfit] tracking-wide" style={{ fontWeight: 600 }}>{projectData.duration}</p>
                </div>
              )}
              
              {projectData.client && (
                <div className="bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-all border border-yellow-100">
                  <div className="flex items-center gap-2 mb-2">
                    <Rocket className="w-5 h-5 text-yellow-600" />
                    <p className="text-xs uppercase tracking-wider text-gray-500 font-[outfit]" style={{ fontWeight: 700 }}>Client</p>
                  </div>
                  <p className="text-sm text-gray-900 font-[outfit] tracking-wide" style={{ fontWeight: 600 }}>{projectData.client}</p>
                </div>
              )}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Main Content */}
      <section className="pb-20 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Challenge & Solution Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {projectData.challenge && (
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-red-50 to-orange-50 rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-red-100"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm">
                    <AlertCircle className="w-6 h-6 text-red-500" />
                  </div>
                  <h2 className="text-2xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    The Challenge
                  </h2>
                </div>
                <p className="text-gray-700 leading-relaxed font-[outfit] tracking-wide">
                  {projectData.challenge}
                </p>
              </motion.div>
            )}

            {projectData.solution && (
              <motion.div
                initial={{ opacity: 0, x: 30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-green-100"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-white rounded-xl shadow-sm">
                    <Lightbulb className="w-6 h-6 text-green-500" />
                  </div>
                  <h2 className="text-2xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    The Solution
                  </h2>
                </div>
                <p className="text-gray-700 leading-relaxed font-[outfit] tracking-wide">
                  {projectData.solution}
                </p>
              </motion.div>
            )}
          </div>

          {/* Learning Objectives */}
          {projectData.learningObjectives && projectData.learningObjectives.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="bg-white rounded-3xl p-8 md:p-10 shadow-sm mb-8 border border-blue-100"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl">
                  <Target className="w-6 h-6 text-blue-600" />
                </div>
                <h2 className="text-3xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                  Learning Objectives
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {projectData.learningObjectives.map((objective: string, index: number) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex items-start gap-3 p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl hover:shadow-md transition-all"
                  >
                    <CheckCircle2 className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                    <p className="text-gray-700 font-[outfit] tracking-wide leading-relaxed">{objective}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          )}

          {/* Project Details Grid */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8"
          >
            {projectData.audience && (
              <div className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-purple-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-gradient-to-br from-purple-100 to-pink-100 rounded-xl">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="text-xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    Target Audience
                  </h3>
                </div>
                <p className="text-gray-700 font-[outfit] tracking-wide leading-relaxed">{projectData.audience}</p>
              </div>
            )}

            {projectData.impact && (
              <div className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-green-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-gradient-to-br from-green-100 to-emerald-100 rounded-xl">
                    <TrendingUp className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="text-xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    Impact & Results
                  </h3>
                </div>
                <p className="text-gray-700 font-[outfit] tracking-wide leading-relaxed">{projectData.impact}</p>
              </div>
            )}

            {projectData.methodology && (
              <div className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-yellow-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-gradient-to-br from-yellow-100 to-orange-100 rounded-xl">
                    <Sparkles className="w-6 h-6 text-yellow-600" />
                  </div>
                  <h3 className="text-xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    Methodology
                  </h3>
                </div>
                <p className="text-gray-700 font-[outfit] tracking-wide leading-relaxed">{projectData.methodology}</p>
              </div>
            )}

            {projectData.deliverables && (
              <div className="bg-white rounded-3xl p-8 shadow-sm hover:shadow-lg transition-all border border-blue-100">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-gradient-to-br from-blue-100 to-cyan-100 rounded-xl">
                    <Rocket className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-[outfit] tracking-wider uppercase text-gray-900" style={{ fontWeight: 800 }}>
                    Deliverables
                  </h3>
                </div>
                <p className="text-gray-700 font-[outfit] tracking-wide leading-relaxed">{projectData.deliverables}</p>
              </div>
            )}
          </motion.div>

          {/* Action Buttons */}
          {(project.liveUrl || project.githubUrl) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
              className="flex flex-wrap justify-center gap-4 mt-12"
            >
              {project.liveUrl && (
                <motion.a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-4 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-full inline-flex items-center gap-2 hover:shadow-xl transition-shadow font-[outfit] tracking-wider"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  style={{ fontWeight: 700 }}
                >
                  View Live Project <ExternalLink className="w-5 h-5" />
                </motion.a>
              )}
              {project.githubUrl && (
                <motion.a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-4 bg-white border-2 border-gray-200 text-gray-900 rounded-full inline-flex items-center gap-2 hover:border-gray-400 hover:shadow-lg transition-all font-[outfit] tracking-wider"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  style={{ fontWeight: 700 }}
                >
                  <Github className="w-5 h-5" />
                  View Code
                </motion.a>
              )}
            </motion.div>
          )}
        </div>
      </section>

      {/* Back to Projects */}
      <section className="py-12 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <Link
            to="/#projects"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-blue-400 to-cyan-400 text-white rounded-full hover:shadow-xl transition-all font-[outfit] tracking-wider"
            style={{ fontWeight: 700 }}
          >
            <ArrowLeft className="w-5 h-5" />
            Back to All Projects
          </Link>
        </div>
      </section>
    </div>
  );
}
