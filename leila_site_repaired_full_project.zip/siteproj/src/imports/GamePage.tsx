import { Navigation } from "../components/Navigation";
import { LearningExperienceGame } from "../components/LearningExperienceGame";
import { StandaloneBonusGame } from "../components/ui/StandaloneBonusGame";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";
import { motion } from "motion/react";
import pointerHand from "figma:asset/971f514c24b6bc492cd618ec01a3f2084d09cbfa.png";

export function GamePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        {/* Interactive Game Section */}
        <section className="py-16 px-4 md:px-8 lg:px-12">
          <div className="max-w-[1400px] mx-auto text-center mb-8">
            <h2 className="text-4xl md:text-5xl font-[outfit] tracking-wider uppercase mb-4 text-gray-900 inline-flex items-center justify-center gap-3" style={{ fontWeight: 900 }}>
              Try It Yourself
              <motion.img 
                src={pointerHand}
                alt="pointer hand"
                className="h-12 md:h-14"
                animate={{ y: [0, -10, 0] }}
                transition={{ 
                  duration: 2.5, 
                  repeat: Infinity, 
                  ease: "easeInOut" 
                }}
              />
            </h2>
            <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
              Interactive learning experience design demonstration
            </p>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-[1400px] mx-auto">
            <LearningExperienceGame />
            <StandaloneBonusGame />
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
