import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { AboutPage } from "./pages/AboutPage";
import { ProcessPage } from "./pages/ProcessPage";
import { ProjectsPage } from "./pages/ProjectsPage";
import { GamePage } from "./pages/GamePage";
import { SkillsPage } from "./pages/SkillsPage";
import { ContactPage } from "./pages/ContactPage";
import { VeteransCareDetail } from "./pages/VeteransCareDetail";
import { Project7Detail } from "./pages/Project7Detail";
import { Project8Detail } from "./pages/Project8Detail";
import { Project9Detail } from "./pages/Project9Detail";
import { RootLayout } from "./pages/RootLayout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      {
        index: true,
        Component: Home,
      },
      {
        path: "about",
        Component: AboutPage,
      },
      {
        path: "process",
        Component: ProcessPage,
      },
      {
        path: "game",
        Component: GamePage,
      },
      {
        path: "skills",
        Component: SkillsPage,
      },
      {
        path: "contact",
        Component: ContactPage,
      },
      {
        path: "projects",
        Component: ProjectsPage,
      },
      {
        path: "project/1",
        Component: VeteransCareDetail,
      },
      {
        path: "project/7",
        Component: Project7Detail,
      },
      {
        path: "project/8",
        Component: Project8Detail,
      },
      {
        path: "project/9",
        Component: Project9Detail,
      },
    ],
  },
]);