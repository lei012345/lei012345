import image_36fa19961c80c3544217481b4c6561bc5f35e9d8 from 'figma:asset/36fa19961c80c3544217481b4c6561bc5f35e9d8.png'
import { ArrowLeft, ExternalLink, Github, Sparkles, X, Heart, ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { useEffect, useState } from "react";
import { ProjectMetadata } from "../components/ProjectMetadata";

export function Project9Detail() {
  const project = portfolioData.projects.find((p) => p.id === 9);
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showAbout, setShowAbout] = useState(true);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, []);

  // Smooth scroll to section function
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, sectionId: string) => {
    e.preventDefault();
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Close modal on escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") setSelectedImageIndex(null);
    };
    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, []);

  // Navigation functions
  const goToNextImage = () => {
    setSelectedImageIndex((prev) => 
      prev !== null ? (prev + 1) % galleryImages.length : 0
    );
  };

  const goToPreviousImage = () => {
    setSelectedImageIndex((prev) => 
      prev !== null ? (prev - 1 + galleryImages.length) % galleryImages.length : 0
    );
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyboard = (e: KeyboardEvent) => {
      if (selectedImageIndex === null) return;
      if (e.key === "ArrowRight") goToNextImage();
      if (e.key === "ArrowLeft") goToPreviousImage();
    };
    window.addEventListener("keydown", handleKeyboard);
    return () => window.removeEventListener("keydown", handleKeyboard);
  }, [selectedImageIndex]);

  // Define gallery images
  const galleryImages = [
    {
      src: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-1.png",
      alt: "ID-Project-1 Image 1",
    },
    {
      src: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",
      alt: "ID-Project-1 Image 2",
    },
    {
      src: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kindred-pin.png",
      alt: "ID-Project-1 Image 3",
    },
    {
      src: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-hat.png",
      alt: "ID-Project-1 Image 4",
    },
  ];

  if (!project) return null;

  return (
    <>
      <motion.div 
        className="min-h-screen bg-[#f0f9ff]"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ x: "100%" }}
        transition={{ 
          duration: 0.4, 
          ease: [0.43, 0.13, 0.23, 0.96]
        }}
      >
        {/* Back Button */}
        <motion.div
          className="fixed top-6 left-6 z-50"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
        >
          <Link
            to="/#projects"
            className="flex items-center gap-2 px-4 py-2 bg-white border border-border/50 rounded-full shadow-lg hover:shadow-xl transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="text-sm font-[raleway] tracking-widest uppercase" style={{ fontWeight: 800 }}>
              Back
            </span>
          </Link>
        </motion.div>

        {/* Hero Section */}
        <section className="pt-32 pb-8 px-6 relative overflow-hidden">
          
          <div className="max-w-7xl mx-auto relative z-10">
            {/* Centered Single Column Layout */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="flex flex-col items-center"
            >
              {/* Project icon */}
              <div className={`w-full max-w-2xl rounded-2xl overflow-hidden mb-6 relative`}>
                <img 
                  src={image_36fa19961c80c3544217481b4c6561bc5f35e9d8} 
                  alt={project.title}
                  loading="eager"
                  fetchpriority="high"
                  className="w-2/3 h-auto mx-auto"
                />
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap gap-4 mb-12 justify-center font-[raleway] uppercase tracking-wider">
                <motion.a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-8 py-3 bg-[#6f94c7] text-white rounded-full inline-flex items-center gap-2 hover:shadow-lg transition-shadow"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="text-[14px] inline-flex items-center gap-1" style={{ fontWeight: 800 }}>View Live Site <ExternalLink className="w-4 h-4" /></span>
                </motion.a>
                <motion.a
                  href="#about"
                  onClick={(e) => scrollToSection(e, 'about')}
                  className="px-6 py-3 bg-white border-2 border-foreground/10 rounded-full inline-flex items-center gap-2 hover:border-foreground/30 transition-colors text-[13px]"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <span className="inline-flex items-center gap-1 text-[14px]" style={{ fontWeight: 800 }}>About</span>
                </motion.a>
              </div>

              {/* Concept Photos */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-white rounded-2xl p-8 shadow-sm max-w-4xl w-full mb-8"
              >
                <h2 className="text-3xl mb-4 text-center font-[raleway] tracking-wider uppercase" style={{ fontWeight: 900 }}>Concept Photos</h2>
                

                {/* Photo Grid */}
                <div className="grid grid-cols-2 gap-4 w-full mb-8">
                  {galleryImages.map((image, index) => (
                    <motion.div
                      key={index}
                      className="rounded-xl overflow-hidden shadow-lg relative group aspect-[4/3]"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                      whileHover={{ y: -4 }}
                    >
                      <img
                        src={image.src}
                        alt={image.alt}
                        loading="eager"
                        fetchpriority="high"
                        className="w-full h-full object-cover cursor-pointer"
                        onClick={() => setSelectedImageIndex(index)}
                      />
                    </motion.div>
                  ))}
                </div>

                {/* About Section - Banner style at bottom */}
                <div id="about" className="border-t border-border/20 pt-8 font-[raleway] tracking-wider">
                  <h2 
                    className="text-3xl mb-6 text-center uppercase" 
                    style={{ fontWeight: 900 }}
                  >
                    About
                  </h2>
                  <p className="text-xl text-[#1f1f1f] text-center leading-relaxed text-[#585f64] tracking-wider font-[raleway]">
                    <span className="font-bold">{project.title}</span> is a new project placeholder. Edit this content in portfolio-data.ts to describe your project in detail. This project follows the same structure and layout as Kindred Paws, giving you a consistent and professional presentation for your portfolio work.
                  </p>
                </div>
              </motion.div>

              {/* ID/LXD Project Metadata - Conditionally rendered if data exists */}
              <ProjectMetadata
                role={(project as any).role}
                client={(project as any).client}
                audience={(project as any).audience}
                learningObjectives={(project as any).learningObjectives}
                methodology={(project as any).methodology}
                deliverables={(project as any).deliverables}
                duration={(project as any).duration}
                impact={(project as any).impact}
                challenge={(project as any).challenge}
                solution={(project as any).solution}
                projectType={(project as any).projectType}
              />
            </motion.div>
          </div>
        </section>

        {/* Back to Projects */}
        <section className="py-12 px-6">
          <div className="max-w-5xl mx-auto text-center">
            <Link
              to="/#projects"
              className="inline-flex items-center gap-2 px-8 py-3 bg-[#6f94c7] text-white rounded-full hover:shadow-lg transition-shadow font-[raleway] tracking-widest uppercase font-bold"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Projects
            </Link>
          </div>
        </section>

        {/* Image Modal */}
        {selectedImageIndex !== null && (
          <motion.div
            className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-6 cursor-pointer group"
            onClick={() => setSelectedImageIndex(null)}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Previous Button - Fixed Left Position */}
            <button
              className="fixed left-8 top-1/2 -translate-y-1/2 bg-white rounded-full p-4 shadow-2xl hover:bg-gray-100 transition-all opacity-0 group-hover:opacity-100 hover:scale-110 z-10"
              onClick={(e) => {
                e.stopPropagation();
                goToPreviousImage();
              }}
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Image Container */}
            <motion.div
              className="relative max-w-5xl max-h-[90vh]"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ duration: 0.3 }}
              onClick={(e) => e.stopPropagation()}
            >
              <img
                src={galleryImages[selectedImageIndex].src}
                alt="Full Size"
                className="max-w-full max-h-[90vh] object-contain rounded-lg"
              />
              
              {/* Image Counter */}
              <div className="absolute -bottom-16 left-1/2 -translate-x-1/2 bg-black/70 text-white px-4 py-2 rounded-full text-sm transition-opacity opacity-0 group-hover:opacity-100">
                {selectedImageIndex + 1} / {galleryImages.length}
              </div>
            </motion.div>

            {/* Next Button - Fixed Right Position */}
            <button
              className="fixed right-8 top-1/2 -translate-y-1/2 bg-white rounded-full p-4 shadow-2xl hover:bg-gray-100 transition-all opacity-0 group-hover:opacity-100 hover:scale-110 z-10"
              onClick={(e) => {
                e.stopPropagation();
                goToNextImage();
              }}
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          </motion.div>
        )}
      </motion.div>
    </>
  );
}