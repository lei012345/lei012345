import { motion } from "motion/react";
import { useState, useEffect } from "react";
import {
  Menu,
  X,
  House,
  User,
  Sparkles,
  Briefcase,
  Pencil,
  MessageCircle,
  Palette,
  LucideIcon,
} from "lucide-react";
import { Link, useLocation } from "react-router";

interface NavigationProps {
  colorPicker?: {
    color: string;
    setColor: (color: string) => void;
    defaultColor: string;
    label: string;
  };
  skinTonePicker?: {
    color: string;
    setColor: (color: string) => void;
    defaultColor: string;
  };
}

interface NavItem {
  href: string;
  label: string;
  icon: LucideIcon;
}

export function Navigation({ colorPicker }: NavigationProps = {}) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [colorPickerClicked, setColorPickerClicked] = useState(false);
  const [showArrow, setShowArrow] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    if (location.pathname !== "/art-library" || !colorPicker) {
      return;
    }

    const showTimer = setTimeout(() => {
      if (!colorPickerClicked) {
        setShowArrow(true);
      }
    }, 5000);

    return () => clearTimeout(showTimer);
  }, [location.pathname, colorPickerClicked, colorPicker]);

  useEffect(() => {
    if (!showArrow) return;

    const hideTimer = setTimeout(() => {
      setShowArrow(false);
    }, 10000);

    return () => clearTimeout(hideTimer);
  }, [showArrow]);

  const navItems: NavItem[] = [
    { href: "/", label: "Home", icon: House },
    { href: "/about", label: "About", icon: User },
    { href: "/projects", label: "Projects", icon: Briefcase },
    { href: "/skills", label: "Skills", icon: Sparkles },
  ];

  const handleClick = () => {
    setIsOpen(false);
  };

  const isActive = (href: string) => {
    if (href === "/") {
      return location.pathname === "/";
    }
    return location.pathname === href;
  };

  return (
    <>
      {/* Desktop Navigation */}
      <motion.nav
        className={`hidden md:flex fixed top-0 left-0 right-0 z-50 transition-all duration-300 items-center justify-between px-6 ${
          scrolled ? "bg-white shadow-md border-b border-gray-200" : ""
        }`}
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        {/* Left spacer so center nav stays centered */}
        <div className="w-[220px]" />

        {/* Center Navigation Items */}
        <div className="absolute left-1/2 transform -translate-x-1/2 py-4">
          <ul className="flex items-center justify-center gap-2">
            {navItems.map((item) => (
              <motion.li
                key={item.href}
                whileHover={{ y: -2 }}
                transition={{ duration: 0.2 }}
              >
                <Link
                  to={item.href}
                  className={`px-4 py-2 text-[#6d5593] hover:text-[#7876A1] hover:bg-[#f5f2f8] rounded transition-all font-[outfit] tracking-wide ${
                    isActive(item.href) ? "bg-[#f5f2f8] text-[#6b5b95]" : ""
                  }`}
                  style={{ fontWeight: 600 }}
                >
                  {item.label}
                </Link>
              </motion.li>
            ))}
          </ul>
        </div>

        {/* Right side buttons */}
        <div className="py-4">
          <ul className="flex items-center gap-2">
            <motion.li whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
              <Link
                to="/art-customizer"
                className="px-6 py-2 bg-[#6d5593] text-white hover:bg-[#c595d8] rounded shadow-sm hover:shadow-md transition-all font-[outfit] tracking-wide"
                style={{ fontWeight: 700 }}
              >
                🎨 Art Customizer
              </Link>
            </motion.li>

            <motion.li whileHover={{ scale: 1.05 }} transition={{ duration: 0.2 }}>
              <Link
                to="/contact"
                className="px-6 py-2 bg-[#546DA6] text-white hover:bg-[#6a8ea4] rounded shadow-sm hover:shadow-md transition-all font-[outfit] tracking-wide"
                style={{ fontWeight: 700 }}
              >
                Contact
              </Link>
            </motion.li>
          </ul>
        </div>
      </motion.nav>

      {/* Mobile Navigation Button */}
      <motion.button
        className="fixed top-4 right-4 z-50 md:hidden w-12 h-12 bg-white border-2 border-[#d4c5e8] rounded-lg shadow-lg flex items-center justify-center"
        onClick={() => setIsOpen(!isOpen)}
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        {isOpen ? (
          <X className="w-5 h-5 text-[#6b5b95]" />
        ) : (
          <Menu className="w-5 h-5 text-[#6b5b95]" />
        )}
      </motion.button>

      {/* Mobile Navigation Menu */}
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-40 md:hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-gray-900/20 backdrop-blur-md"
            onClick={() => setIsOpen(false)}
          />

          <motion.div
            className="absolute top-20 right-6 left-6 bg-white rounded-lg shadow-2xl overflow-hidden border-2 border-[#d4c5e8]"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            <ul className="p-2">
              {navItems.map((item, index) => {
                const Icon = item.icon;

                return (
                  <motion.li
                    key={item.href}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Link
                      to={item.href}
                      onClick={handleClick}
                      className={`flex items-center gap-3 px-5 py-3.5 rounded-md transition-all group ${
                        isActive(item.href) ? "bg-[#f5f2f8]" : "hover:bg-[#f5f2f8]"
                      }`}
                    >
                      <Icon className="w-5 h-5 text-[#6b5b95] group-hover:scale-110 transition-transform" />
                      <span
                        className="font-[outfit] tracking-wide text-gray-800"
                        style={{ fontWeight: 600 }}
                      >
                        {item.label}
                      </span>
                    </Link>
                  </motion.li>
                );
              })}

              <motion.li
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: navItems.length * 0.05 }}
                className="mt-2 px-3"
              >
                <Link
                  to="/art-customizer"
                  onClick={handleClick}
                  className="flex items-center justify-center gap-3 py-3.5 rounded-md bg-[#6D5593] text-white shadow-md hover:shadow-lg hover:bg-[#c595d8] transition-all px-[20px] py-[12px] mx-[0px] my-[10px]"
                >
                  <Palette className="w-5 h-5" />
                  <span className="font-[outfit] tracking-wide" style={{ fontWeight: 700 }}>
                    Art Customizer
                  </span>
                </Link>
              </motion.li>

              <motion.li
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: (navItems.length + 1) * 0.05 }}
                className="px-3"
              >
                <Link
                  to="/contact"
                  onClick={handleClick}
                  className="flex items-center justify-center gap-3 py-3.5 rounded-md bg-[#546DA6] text-white shadow-md hover:shadow-lg hover:bg-[#6a8ea4] transition-all px-[20px] py-[12px] mx-[0px] my-[8px]"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span className="font-[outfit] tracking-wide" style={{ fontWeight: 700 }}>
                    Contact
                  </span>
                </Link>
              </motion.li>
            </ul>
          </motion.div>
        </motion.div>
      )}
    </>
  );
}