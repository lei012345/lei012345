import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router';

// PNG URLs from GitHub
const birdFly1 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd1.png';
const birdFly3 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd2.png';
const birdFly4 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd3.png';
const birdFly5 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd4-2.png';
const birdFly7 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd4.png';
const birdFly8 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd5.png';
const birdFly9 = 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bd6.png';

type AnimationPhase = 'flying' | 'landing' | 'perched';
type BubbleType = 'intro' | 'hover' | null;

interface FlyingBirdProps {
  startX?: number;
  endX?: number;
  yPosition?: number;
  flyDuration?: number;
  delay?: number;
  size?: number;
  loop?: boolean;
}

export function FlyingBird({
  startX = -10,
  endX = 70,
  yPosition = 20,
  flyDuration = 3,
  delay = 0,
  size = 200,
  loop = false,
}: FlyingBirdProps) {
  const [phase, setPhase] = useState<AnimationPhase>('flying');
  const [landingFrame, setLandingFrame] = useState(0);
  const [perchedFrame, setPerchedFrame] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  const [currentPosition, setCurrentPosition] = useState({ x: startX, y: yPosition });
  const [targetPosition, setTargetPosition] = useState({ x: endX, y: yPosition });

  const [isHovered, setIsHovered] = useState(false);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [lastHoverTime, setLastHoverTime] = useState<number>(0);
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [responsiveSize, setResponsiveSize] = useState(size);

  const [hasShownIntroBubble, setHasShownIntroBubble] = useState(false);

  const [bubbleMounted, setBubbleMounted] = useState(false);
  const [bubbleVisible, setBubbleVisible] = useState(false);
  const [bubbleType, setBubbleType] = useState<BubbleType>(null);

  const birdRef = useRef<HTMLDivElement>(null);
  const bubbleHideTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bubbleAutoHideTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flightRestartTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const chatMessages = [
    "If you have any questions for Leila, don't hesitate to bug her! I do it all the time!",
    'Leila just created an Art Customizer! Check it out right here on her website!',
  ];

  const landingFrames = [birdFly3, birdFly4, birdFly5];
  const perchedFrames = [birdFly7, birdFly8, birdFly9];
  const frameDuration = 80;
  const BUBBLE_EXIT_MS = 180;

  // FIRST-OPTION FIX:
  // Keeps the intro bubble a little longer, while still tying the timing to the landing sequence.
  // Since the intro appears once the bird is perched, this just gives it a slightly more intentional hold.
  const INTRO_EXTRA_TIME = 6200;
  const INTRO_BUBBLE_DURATION = landingFrames.length * frameDuration + INTRO_EXTRA_TIME;

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);

      if (mobile) {
        setTargetPosition({ x: 15, y: 48 });
      } else {
        setTargetPosition({ x: endX, y: yPosition });
      }
    };

    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, [endX, yPosition]);

  useEffect(() => {
    setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  useEffect(() => {
    const updateSize = () => {
      const mobile = window.innerWidth < 768;
      setResponsiveSize(mobile ? size * 0.6 : size);
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, [size]);

  useEffect(() => {
    return () => {
      if (bubbleHideTimeoutRef.current) clearTimeout(bubbleHideTimeoutRef.current);
      if (bubbleAutoHideTimeoutRef.current) clearTimeout(bubbleAutoHideTimeoutRef.current);
      if (flightRestartTimeoutRef.current) clearTimeout(flightRestartTimeoutRef.current);
    };
  }, []);

  const clearBubbleTimers = () => {
    if (bubbleHideTimeoutRef.current) clearTimeout(bubbleHideTimeoutRef.current);
    if (bubbleAutoHideTimeoutRef.current) clearTimeout(bubbleAutoHideTimeoutRef.current);
  };

  const getRandomPosition = () => {
    const mobile = window.innerWidth < 768;

    const newX = Math.random() * 90 + 5;
    const newY = Math.random() * 60 + 15;

    const minX = mobile ? 15 : 10;
    const maxX = mobile ? 85 : 90;
    const adjustedX = Math.max(minX, Math.min(maxX, newX));

    return {
      x: adjustedX,
      y: newY,
    };
  };

  const showBubble = (type: BubbleType) => {
    clearBubbleTimers();

    setBubbleType(type);
    setBubbleMounted(true);

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        setBubbleVisible(true);
      });
    });
  };

  const hideBubble = (onHidden?: () => void) => {
    clearBubbleTimers();

    setBubbleVisible(false);

    bubbleHideTimeoutRef.current = setTimeout(() => {
      setBubbleMounted(false);
      setBubbleType(null);
      onHidden?.();
    }, BUBBLE_EXIT_MS);
  };

  const startFlyingToNextPosition = () => {
    const newTarget = getRandomPosition();
    setCurrentPosition(targetPosition);
    setTargetPosition(newTarget);
    setLandingFrame(0);
    setPerchedFrame(0);
    setPhase('flying');
  };

  const fadeOutBubbleThenFly = () => {
    if (bubbleMounted && bubbleVisible) {
      hideBubble(() => {
        startFlyingToNextPosition();
      });
    } else {
      startFlyingToNextPosition();
    }
  };

  useEffect(() => {
    if (isHovered && phase === 'flying') {
      const birdElement = document.querySelector('.flying-bird-' + Math.floor(startX));
      if (birdElement) {
        const rect = birdElement.getBoundingClientRect();
        const newX = (rect.left / window.innerWidth) * 100;
        const newY = (rect.top / window.innerHeight) * 100;
        setTargetPosition({ x: newX, y: newY });
        setCurrentPosition({ x: newX, y: newY });
      }

      setLandingFrame(0);
      setPhase('landing');
    }
  }, [isHovered, phase, startX]);

  useEffect(() => {
    if (bubbleType === 'intro') return;

    if (!isTouchDevice && isHovered && phase === 'perched') {
      const currentTime = Date.now();
      const timeSinceLastHover = currentTime - lastHoverTime;

      if (timeSinceLastHover > 3000) {
        setCurrentMessageIndex((prev) => (prev + 1) % chatMessages.length);
        setLastHoverTime(currentTime);
      }

      showBubble('hover');
    } else if (!isTouchDevice && !isHovered && bubbleType === 'hover') {
      hideBubble();
    }
  }, [isHovered, phase, chatMessages.length, isTouchDevice, lastHoverTime, bubbleType]);

  useEffect(() => {
    if (!isTouchDevice && phase === 'perched' && !hasShownIntroBubble) {
      setHasShownIntroBubble(true);
      setCurrentMessageIndex(0);
      showBubble('intro');

      bubbleAutoHideTimeoutRef.current = setTimeout(() => {
        hideBubble();
      }, INTRO_BUBBLE_DURATION);

      return () => {
        if (bubbleAutoHideTimeoutRef.current) {
          clearTimeout(bubbleAutoHideTimeoutRef.current);
        }
      };
    }
  }, [phase, hasShownIntroBubble, isTouchDevice, INTRO_BUBBLE_DURATION]);

  useEffect(() => {
    if (!isTouchDevice || !bubbleMounted) return;

    const handleClickOutside = (event: MouseEvent | TouchEvent) => {
      if (birdRef.current && !birdRef.current.contains(event.target as Node)) {
        hideBubble();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('touchstart', handleClickOutside);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('touchstart', handleClickOutside);
    };
  }, [bubbleMounted, isTouchDevice]);

  useEffect(() => {
    if (phase === 'perched') {
      const interval = setInterval(() => {
        setPerchedFrame((prev) => (prev + 1) % perchedFrames.length);
      }, 150);

      return () => clearInterval(interval);
    }
  }, [phase, perchedFrames.length]);

  useEffect(() => {
    if (loop && !isMobile && phase === 'perched' && !isHovered) {
      flightRestartTimeoutRef.current = setTimeout(() => {
        fadeOutBubbleThenFly();
      }, 3000);

      return () => {
        if (flightRestartTimeoutRef.current) {
          clearTimeout(flightRestartTimeoutRef.current);
        }
      };
    }
  }, [phase, loop, isMobile, isHovered, bubbleMounted, bubbleVisible, targetPosition]);

  useEffect(() => {
    if (phase === 'landing') {
      const interval = setInterval(() => {
        setLandingFrame((prev) => {
          if (prev < landingFrames.length - 1) {
            return prev + 1;
          } else {
            setPhase('perched');
            return prev;
          }
        });
      }, frameDuration);

      return () => clearInterval(interval);
    }
  }, [phase, landingFrames.length]);

  const handleFlyingComplete = () => {
    setLandingFrame(0);
    setPhase('landing');
  };

  const handleBirdClick = () => {
    if (!isTouchDevice && phase !== 'perched') return;

    setCurrentMessageIndex(Math.floor(Math.random() * chatMessages.length));
    showBubble('hover');

    if (bubbleAutoHideTimeoutRef.current) {
      clearTimeout(bubbleAutoHideTimeoutRef.current);
    }

    bubbleAutoHideTimeoutRef.current = setTimeout(() => {
      hideBubble();
    }, 5000);
  };

  const getCurrentSprite = () => {
    if (phase === 'flying') return birdFly1;
    if (phase === 'landing') return landingFrames[landingFrame];
    return perchedFrames[perchedFrame];
  };

  const isFlyingRight = targetPosition.x > currentPosition.x;
  const bubbleBelowBird = targetPosition.y < 25;

  const renderMessage = (message: string) => {
    const leilaRegex = /(Leila)/g;

    if (message.includes('bug her')) {
      const parts = message.split('bug her');
      return (
        <>
          {parts[0].split(leilaRegex).map((part, i) =>
            part === 'Leila' ? <strong key={i}>{part}</strong> : part
          )}
          <Link
            to="/contact"
            className="text-[#546DA6] hover:text-[#6b5b95] font-semibold underline"
            onClick={(e) => e.stopPropagation()}
          >
            bug her
          </Link>
          {parts[1].split(leilaRegex).map((part, i) =>
            part === 'Leila' ? <strong key={i}>{part}</strong> : part
          )}
        </>
      );
    }

    if (message.includes('Art Customizer')) {
      const parts = message.split('Art Customizer');
      return (
        <>
          {parts[0].split(leilaRegex).map((part, i) =>
            part === 'Leila' ? <strong key={i}>{part}</strong> : part
          )}
          <Link
            to="/art-customizer"
            className="text-[#546DA6] hover:text-[#6b5b95] font-semibold underline"
            onClick={(e) => e.stopPropagation()}
          >
            Art Customizer
          </Link>
          {parts[1].split(leilaRegex).map((part, i) =>
            part === 'Leila' ? <strong key={i}>{part}</strong> : part
          )}
        </>
      );
    }

    return message.split(leilaRegex).map((part, i) =>
      part === 'Leila' ? <strong key={i}>{part}</strong> : part
    );
  };

  return (
    <AnimatePresence>
      <motion.div
        className={`absolute pointer-events-auto z-30 flying-bird-${Math.floor(startX)}`}
        initial={{
          x: `${currentPosition.x}vw`,
          y: `${currentPosition.y}vh`,
          opacity: 1,
          scaleX: isFlyingRight ? -1 : 1,
        }}
        animate={{
          x: `${targetPosition.x}vw`,
          y:
            phase === 'perched'
              ? [`${targetPosition.y}vh`, `${targetPosition.y - 1}vh`, `${targetPosition.y}vh`]
              : phase === 'flying'
                ? [
                    `${currentPosition.y}vh`,
                    `${targetPosition.y - 2}vh`,
                    `${targetPosition.y + 1}vh`,
                    `${targetPosition.y}vh`,
                  ]
                : `${targetPosition.y}vh`,
          opacity: 1,
          scaleX: isFlyingRight ? -1 : 1,
        }}
        transition={{
          delay: phase === 'flying' ? delay : 0,
          x: {
            duration: phase === 'flying' ? flyDuration : 0,
            ease: 'linear',
          },
          y:
            phase === 'perched'
              ? {
                  duration: 2,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }
              : phase === 'flying'
                ? {
                    duration: flyDuration,
                    ease: 'easeInOut',
                  }
                : {
                    duration: 0,
                    ease: 'linear',
                  },
        }}
        onAnimationComplete={() => {
          if (phase === 'flying') {
            handleFlyingComplete();
          }
        }}
        style={{
          width: responsiveSize,
          height: responsiveSize,
        }}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        onClick={handleBirdClick}
        ref={birdRef}
      >
        <motion.img
          src={getCurrentSprite()}
          alt="Flying bird"
          className="w-full h-full object-contain"
        />

        <AnimatePresence>
          {bubbleMounted && (
            <motion.div
              key={bubbleType ?? 'bubble'}
              className={`absolute left-1/2 -translate-x-1/2 w-40 md:w-64 bg-white rounded-2xl p-2 md:p-4 shadow-lg border-2 border-gray-200 ${
                bubbleBelowBird ? 'top-full mt-1' : 'bottom-full mb-1'
              }`}
              style={{
                scaleX: isFlyingRight ? -1 : 1,
                pointerEvents: 'auto',
              }}
              initial={{
                opacity: 0,
                scale: 0.94,
                y: bubbleBelowBird ? -6 : 6,
              }}
              animate={{
                opacity: bubbleVisible ? 1 : 0,
                scale: bubbleVisible ? 1 : 0.94,
                y: bubbleVisible ? 0 : 2,
              }}
              exit={{
                opacity: 0,
                scale: 0.94,
                y: 2,
              }}
              transition={{
                opacity: {
                  duration: bubbleVisible ? 0.15 : 0.18,
                  ease: [0.4, 0, 0.2, 1],
                },
                scale: {
                  duration: bubbleVisible ? 0.15 : 0.18,
                  ease: [0.4, 0, 0.2, 1],
                },
                y: {
                  duration: bubbleVisible ? 0.15 : 0.18,
                  ease: [0.4, 0, 0.2, 1],
                },
              }}
            >
              <div className="text-sm md:text-lg text-gray-800 leading-relaxed">
                {renderMessage(chatMessages[currentMessageIndex])}
              </div>

              <motion.div
                className={`absolute left-1/2 -translate-x-1/2 w-0 h-0 ${
                  bubbleBelowBird ? 'top-0 -mt-2' : 'bottom-0 -mb-2'
                }`}
                animate={{ opacity: bubbleVisible ? 1 : 0 }}
                transition={{
                  duration: bubbleVisible ? 0.15 : 0.18,
                  ease: [0.4, 0, 0.2, 1],
                }}
                style={
                  bubbleBelowBird
                    ? {
                        borderLeft: '8px solid transparent',
                        borderRight: '8px solid transparent',
                        borderBottom: '8px solid white',
                      }
                    : {
                        borderLeft: '8px solid transparent',
                        borderRight: '8px solid transparent',
                        borderTop: '8px solid white',
                      }
                }
              />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </AnimatePresence>
  );
}
