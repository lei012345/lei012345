import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Send, User, MessageSquare, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import emailjs from '@emailjs/browser';
import Lottie from 'lottie-react';
import emailConfirmationAnimation from '../../imports/Email_confirmation_sent.json';

interface ContactFormProps {
  recipientEmail: string;
}

export function ContactForm({ recipientEmail }: ContactFormProps) {
  const formRef = useRef<HTMLFormElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [showAnimation, setShowAnimation] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!formRef.current) return;

    // Replace these with your actual EmailJS credentials
    const SERVICE_ID = 'leiladesign_contact_form'; // e.g., 'service_abc123'
    const TEMPLATE_ID = 'template_41nocth'; // e.g., 'template_xyz789'
    const PUBLIC_KEY = 'IpPWl_ZvCpwRNqfFR'; // e.g., 'abcdef123456'

    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const result = await emailjs.sendForm(
        SERVICE_ID,
        TEMPLATE_ID,
        formRef.current,
        PUBLIC_KEY
      );

      if (result.text === 'OK') {
        setShowAnimation(true);
        formRef.current.reset();
        
        // Show success message after animation completes
        setTimeout(() => {
          setSubmitStatus('success');
        }, 3500);
        
        // Fade out animation after it completes (around 4 seconds)
        setTimeout(() => {
          setShowAnimation(false);
        }, 4000);
      }
    } catch (error: any) {
      console.error('EmailJS error:', error);
      setSubmitStatus('error');
      setErrorMessage(error.text || 'Failed to send message. Please try again.');
      
      // Reset error message after 5 seconds
      setTimeout(() => {
        setSubmitStatus('idle');
        setErrorMessage('');
      }, 5000);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form ref={formRef} onSubmit={handleSubmit} className="space-y-4 relative">
      {/* Success Animation - appears in middle of form */}
      <AnimatePresence>
        {showAnimation && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 z-50 pointer-events-none"
          >
            <Lottie
              animationData={emailConfirmationAnimation}
              loop={false}
              speed={1.5}
              style={{ width: '100%', height: '100%' }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Name Input */}
      <div>
        <label htmlFor="user_name" className="block text-sm mb-2 text-[#6D5593] tracking-wide uppercase font-[Outfit]" style={{ fontWeight: 700 }}>
          Name
        </label>
        <div className="relative">
          <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            id="user_name"
            name="user_name"
            required
            placeholder="Your name"
            disabled={isSubmitting}
            className="w-full pl-12 pr-4 py-3 rounded-md border border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#b5a8c5] focus:outline-none focus:ring-2 focus:ring-[#b5a8c5]/20 transition-all text-[#464b50] disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
      </div>

      {/* Email Input */}
      <div>
        <label htmlFor="user_email" className="block text-sm mb-2 text-[#6D5593] font-[outfit] tracking-wide uppercase" style={{ fontWeight: 700 }}>
          Email
        </label>
        <div className="relative">
          <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="email"
            id="user_email"
            name="user_email"
            required
            placeholder="your.email@example.com"
            disabled={isSubmitting}
            className="w-full pl-12 pr-4 py-3 rounded-md border border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#b5a8c5] focus:outline-none focus:ring-2 focus:ring-[#b5a8c5]/20 transition-all text-[#464b50] disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
      </div>

      {/* Message Textarea */}
      <div>
        <label htmlFor="message" className="block text-sm mb-2 text-[#6D5593] font-[outfit] tracking-wide uppercase" style={{ fontWeight: 700 }}>
          Message
        </label>
        <div className="relative">
          <MessageSquare className="absolute left-4 top-4 w-5 h-5 text-gray-400" />
          <textarea
            id="message"
            name="message"
            required
            rows={8}
            placeholder="Your message"
            disabled={isSubmitting}
            className="w-full pl-12 pr-4 py-3 rounded-md border border-gray-200 bg-gray-50/50 focus:bg-white focus:border-[#b5a8c5] focus:outline-none focus:ring-2 focus:ring-[#b5a8c5]/20 transition-all resize-none text-[#464b50] disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>
      </div>

      {/* Status Messages */}
      {submitStatus === 'success' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 p-3 bg-green-50 border border-green-200 rounded-md text-green-700"
        >
          <CheckCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm" style={{ fontWeight: 600 }}>
            Message sent successfully! I'll get back to you soon.
          </p>
        </motion.div>
      )}

      {submitStatus === 'error' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-md text-red-700"
        >
          <AlertCircle className="w-5 h-5 flex-shrink-0" />
          <p className="text-sm" style={{ fontWeight: 600 }}>
            {errorMessage || 'Failed to send message. Please try again.'}
          </p>
        </motion.div>
      )}

      {/* Submit Button */}
      <div className="relative">
        <motion.button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-gradient-to-r from-[#546DA6] to-[#546DA6] py-4 px-8 rounded-md hover:shadow-xl hover:scale-105 transition-all flex items-center justify-center gap-3 group text-white font-bold font-[outfit] tracking-wide text-lg disabled:opacity-50 disabled:cursor-not-allowed"
          whileHover={!isSubmitting ? { scale: 1.02 } : {}}
          whileTap={!isSubmitting ? { scale: 0.98 } : {}}
          style={{ fontWeight: 800 }}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Sending...</span>
            </>
          ) : (
            <>
              <span className="font-[outfit] uppercase tracking-wider">Send Message</span>
              <Send className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </>
          )}
        </motion.button>
      </div>
    </form>
  );
}