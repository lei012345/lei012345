import { motion } from "motion/react";
import Lottie from "lottie-react";
import animationData from "../../imports/animation-data.json";

export function ProjectLoadingAnimation() {
  return (
    <motion.div
      className="fixed inset-0 z-[9999] flex items-center justify-center bg-white/80 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="w-[200px] h-[200px]">
        <Lottie
          animationData={animationData}
          loop={true}
          autoplay={true}
        />
      </div>
    </motion.div>
  );
}
