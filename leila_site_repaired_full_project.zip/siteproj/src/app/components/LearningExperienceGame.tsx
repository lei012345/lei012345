import { motion, AnimatePresence } from "motion/react";
import { useState, useEffect } from "react";
import { Sparkles, RefreshCw, ArrowRight, Lightbulb, Eraser, BookOpen } from "lucide-react";

// ==================================================
// EASY IMAGE EDITING - REPLACE THESE WITH YOUR OWN IMAGES
// ==================================================
const SLIDE_IMAGES = {
  step0_boring: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-0.png',
  step1_textErased: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-2.png',
  step2_improvement1: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-3.png',
  step3_improvement2: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-4.png',
  step4_improvement3: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-5.png',
  step5_improvement4: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-6.png',
  step6_improvement5: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/game-click.gif',
  step7_improvement6: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-14.png',
  step8_final: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-12.png',
};

const TOTAL_STEPS = 8;

// Step configurations
const STEP_CONFIG = [
  { label: 'Erase Heavy Text', color: '#d97242' },
  { label: 'Improve Typography', color: '#7b9eb5' },
  { label: 'Add color', color: '#e8b89e' },
  { label: 'Improve layout', color: '#f4a261' },
  { label: 'Enhance it', color: '#a8c5da' },
  { label: 'Click to reveal information', color: '#8ecae6' },
  { label: 'Add visuals', color: '#b5a8c5' },
  { label: 'Polish & Finalize', color: '#6a8ea4' },
];

type GameState = 'intro' | 'playing' | 'completed';

export function LearningExperienceGame() {
  const [gameState, setGameState] = useState<GameState>('intro');
  const [currentStep, setCurrentStep] = useState(0);
  const [showAfter, setShowAfter] = useState(false);
  const [showDesignReference, setShowDesignReference] = useState(false);

  // Preload click sound once on mount for better performance
  const [clickSound] = useState(() => {
    const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/button2.mp3');
    audio.volume = 0.3;
    audio.preload = 'auto';
    audio.load();
    return audio;
  });

  // Play button click sound
  const playButtonSound = () => {
    clickSound.currentTime = 0; // Reset to start for rapid clicks
    clickSound.play().catch(err => console.error('Button sound failed:', err));
  };

  const handleStart = () => {
    playButtonSound();
    setGameState('playing');
    setCurrentStep(0);
  };

  const handleNextStep = () => {
    playButtonSound();
    if (currentStep < TOTAL_STEPS) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleComplete = () => {
    playButtonSound();
    setGameState('completed');
    setShowAfter(false);
  };

  const handlePlayAgain = () => {
    playButtonSound();
    setGameState('playing');
    setCurrentStep(0);
    setShowAfter(false);
  };

  const handleBackToIntro = () => {
    playButtonSound();
    setGameState('intro');
    setCurrentStep(0);
    setShowAfter(false);
  };

  // Trigger the before->after animation when completion screen loads
  useEffect(() => {
    if (gameState === 'completed') {
      const timer = setTimeout(() => {
        setShowAfter(true);
      }, 800);
      return () => clearTimeout(timer);
    }
  }, [gameState]);

  // Play shine sound when transformation reveal appears
  useEffect(() => {
    if (showAfter) {
      const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/done1.mp3');
      audio.play().catch(err => console.error('Shine sound failed:', err));
    }
  }, [showAfter]);

  // Play completion sound when text appears
  useEffect(() => {
    if (gameState === 'completed') {
      const timer = setTimeout(() => {
        const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/reveal2.mp3');
        audio.play().catch(err => console.error('Completion sound failed:', err));
      }, 1800); // Match the text animation delay
      return () => clearTimeout(timer);
    }
  }, [gameState]);

  // Get the current slide image based on step
  const getCurrentSlideImage = () => {
    switch (currentStep) {
      case 0: return SLIDE_IMAGES.step0_boring;
      case 1: return SLIDE_IMAGES.step1_textErased;
      case 2: return SLIDE_IMAGES.step2_improvement1;
      case 3: return SLIDE_IMAGES.step3_improvement2;
      case 4: return SLIDE_IMAGES.step4_improvement3;
      case 5: return SLIDE_IMAGES.step5_improvement4;
      case 6: return SLIDE_IMAGES.step6_improvement5;
      case 7: return SLIDE_IMAGES.step7_improvement6;
      case 8: return SLIDE_IMAGES.step8_final;
      default: return SLIDE_IMAGES.step0_boring;
    }
  };

  const progress = (currentStep / TOTAL_STEPS) * 100;

  return (
    <div className="w-full flex justify-center items-center px-4">
      <div className="min-h-[500px] md:min-h-[800px] w-full">
        {/* Intro State */}
        {gameState === 'intro' && (
          <div
            key="intro"
            className="bg-[#f0f4f8] rounded-lg shadow-lg border border-[#d4dce5] text-center relative overflow-hidden w-full max-w-[1250px] mx-auto p-6 md:p-12 min-h-[600px] md:h-[750px] flex items-center justify-center"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#e8dff5]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            <div className="relative z-10 w-full">
              {/* Before and After Preview */}
              <div className="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-8 mb-4 md:mb-6">
                <motion.img 
                  src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/reveal4.gif"
                  alt="Design game"
                  className="w-full max-w-[350px] md:max-w-[600px] h-auto cursor-pointer"
                  animate={{ y: [0, -15, 0] }}
                  transition={{ 
                    duration: 3,
                    repeat: Infinity,
                    ease: [0.45, 0.05, 0.55, 0.95],
                    repeatType: "reverse"
                  }}
                  onClick={handleStart}
                  whileHover={{ scale: 1.05, transition: { duration: 0.3, ease: "easeOut" } }}
                  whileTap={{ scale: 0.95, transition: { duration: 0.15, ease: "easeInOut" } }}
                />
              </div>
              
              <h3 className="font-[outfit] tracking-wider uppercase mb-3 md:mb-6 bg-gradient-to-r from-[#9d7b8f] via-[#e88b8b] to-[#f5a694] bg-clip-text text-transparent text-[28px] md:text-[40px] px-4" style={{ fontWeight: 900 }}>
                Improve the E-Learning Visuals
              </h3>
              
              <p className="font-[outfit] tracking-wide text-gray-700 mb-4 md:mb-6 text-[18px] md:text-[24px] px-4" style={{ fontWeight: 500 }}>
               Transform a boring slide into an engaging visual experience!
              </p>
              
              <motion.button
                onClick={handleStart}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 md:px-8 py-3 md:py-4 bg-[#7b9eb5] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#6a8ea4] transition-all inline-flex items-center gap-2 text-[24px] md:text-[32px]"
                style={{ fontWeight: 700 }}
              >
                START
                <ArrowRight className="w-5 h-5 md:w-8 md:h-8" />
              </motion.button>
            </div>
          </div>
        )}

        {/* Playing State */}
        {gameState === 'playing' && (
          <div
            key="playing"
            className="bg-[#f0f4f8] rounded-lg shadow-lg border border-[#d4dce5] relative overflow-hidden w-full max-w-[1250px] mx-auto p-6 md:p-8 min-h-[500px] md:h-[750px]"
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
            <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
            
            <div className="relative z-10">
              {/* Compact Header with Progress */}
              <div className="px-6 pt-4 pb-3">
                <div className="flex items-center justify-between gap-4 mb-2">
                  <h3 className="text-lg font-[outfit] tracking-wider text-gray-900" style={{ fontWeight: 700 }}>
                    Improve the E-Learning Visuals
                  </h3>
                  <div className="text-sm font-[outfit] text-gray-700 whitespace-nowrap" style={{ fontWeight: 600 }}>
                    {currentStep}/{TOTAL_STEPS}
                  </div>
                </div>
                <div className="bg-white/50 h-2 rounded-full shadow-inner">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${progress}%` }}
                    className="h-2 rounded-full bg-gradient-to-r from-[#e0a090] to-[#ffc973] transition-all duration-300 shadow-sm"
                  ></motion.div>
                </div>
              </div>

              {/* Vertical Layout: Text above, Image center, Buttons below */}
              <div className="flex flex-col items-center gap-4 px-6 pb-6">
                {/* TOP: Text Commentary */}
                <div className="w-full max-w-[800px]">
                  <p className="text-[#7b7fb3] font-semibold font-[outfit] italic text-center bg-white/90 px-8 py-4 rounded-lg shadow-md text-[20px]">
                    {currentStep === 0 && "This slide is overwhelming with too much text. Let's transform it!"}
                    {currentStep === 1 && "Perfect! With a clean slate, we can now build an engaging visual experience."}
                    {currentStep === 2 && "Better typography immediately makes the content more readable and professional."}
                    {currentStep === 3 && "Strategic use of color creates visual hierarchy and instantly enhances the overall appearance of content."}
                    {currentStep === 4 && "Restructuring the layout improves scanability, but we can make it even better!"}
                    {currentStep === 5 && "Much cleaner! Now the information is organized and easy to digest."}
                    {currentStep === 6 && "Interactive elements allow users to explore content at their own pace and reduce cognitive load."}
                    {currentStep === 7 && "Visuals and illustrations help convey ideas faster than text alone, but also elevate any e-learning content!"}
                    {currentStep === 8 && "Final touches bring everything together! 🪄"}
                  </p>
                </div>

                {/* CENTER: Image at exact dimensions */}
                <div 
                  key={getCurrentSlideImage()}
                  className="flex-shrink-0"
                >
                  <div className="bg-white rounded-lg shadow-xl border-2 border-[#d4dce5] overflow-hidden">
                    <img 
                      src={getCurrentSlideImage()}
                      alt="Slide preview"
                      className="block w-full max-w-[300px] md:max-w-[800px] max-h-[200px] md:max-h-[450px] h-auto object-contain"
                    />
                  </div>
                </div>

                {/* BOTTOM: Action Button */}
                <div className="flex justify-center">
                  {currentStep < TOTAL_STEPS ? (
                    <button
                      onClick={handleNextStep}
                      className="px-4 md:px-8 py-3 md:py-4 rounded-lg text-white shadow-lg hover:shadow-xl transition-all flex items-center gap-2 font-[outfit] hover:scale-105 active:scale-95"
                      style={{ 
                        background: currentStep === 2 
                          ? 'linear-gradient(135deg, #d4a5a5 0%, #e8b89e 40%, #f4d6a5 60%, #b8d4a5 80%, #a5c5d4 90%, #c5b8d4 100%)'
                          : STEP_CONFIG[currentStep].color,
                        fontWeight: 700 
                      }}
                    >
                      <span className="text-[24px]">{STEP_CONFIG[currentStep].label}</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleComplete}
                      className="px-4 md:px-8 py-3 md:py-4 rounded-lg text-white shadow-lg hover:shadow-xl transition-all flex items-center gap-2 font-[outfit] hover:scale-105 active:scale-95"
                      style={{ 
                        background: 'linear-gradient(135deg, #7b9eb5 0%, #6a8ea4 100%)',
                        fontWeight: 700 
                      }}
                    >
                      <Sparkles className="w-4 h-4 md:w-8 md:h-8" />
                      <span className="text-[32px]">View Results</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Completion State */}
        {gameState === 'completed' && (
          <div
            key="completed"
            className="bg-[#f5f9fc] rounded-lg shadow-lg border border-[#d4e3ed] text-center relative overflow-hidden w-full max-w-[1250px] mx-auto p-8 md:p-12 min-h-[500px] md:h-[750px] flex items-center justify-center"
          >
            <div className="relative z-10 w-full max-h-full px-4">
              {/* Before/After Image Transformation */}
              <div className="mb-4 md:mb-6 relative inline-block">
                <AnimatePresence mode="wait">
                  {!showAfter ? (
                    <motion.div
                      key="before"
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 1.2, opacity: 0, rotate: 5 }}
                      transition={{ duration: 0.6 }}
                      className="relative"
                    >
                      <img 
                        src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g-13.png" 
                        alt="Before"
                        className="w-full max-w-[300px] md:max-w-[600px] h-auto mx-auto rounded-lg shadow-xl"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="after"
                      initial={{ scale: 0.8, opacity: 0, rotate: -5 }}
                      animate={{ scale: 1, opacity: 1, rotate: 0 }}
                      transition={{ 
                        duration: 0.8,
                        type: "spring",
                        bounce: 0.4
                      }}
                      className="relative"
                    >
                      <motion.div
                        animate={{ 
                          boxShadow: [
                            "0 0 0px rgba(123, 158, 181, 0)",
                            "0 0 30px rgba(123, 158, 181, 0.6)",
                            "0 0 0px rgba(123, 158, 181, 0)"
                          ]
                        }}
                        transition={{ 
                          duration: 2,
                          repeat: 2,
                          ease: "easeInOut"
                        }}
                        className="rounded-lg"
                      >
                        <img 
                          src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/reveal2.gif" 
                          alt="After - Transformed"
                          className="w-full max-w-[300px] md:max-w-[600px] h-auto mx-auto rounded-lg shadow-2xl"
                        />
                      </motion.div>
                      {/* Celebration sparkles */}
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.5, 0] }}
                        transition={{ duration: 1, delay: 0.3 }}
                        className="absolute -top-4 md:-top-8 -right-4 md:-right-8"
                      >
                        <Sparkles className="w-8 h-8 md:w-12 md:h-12 text-yellow-400" />
                      </motion.div>
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.5, 0] }}
                        transition={{ duration: 1, delay: 0.5 }}
                        className="absolute -bottom-4 md:-bottom-8 -left-4 md:-left-8"
                      >
                        <Sparkles className="w-8 h-8 md:w-12 md:h-12 text-pink-400" />
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <motion.h3 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.8 }}
                className="font-[outfit] tracking-wider uppercase mb-2 md:mb-3 text-gray-900 text-[20px] md:text-[36px]" 
                style={{ fontWeight: 900 }}
              >
                🎉 Transformation Complete!
              </motion.h3>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2 }}
                className="text-gray-700 mb-4 md:mb-6 font-[outfit] tracking-wide max-w-2xl mx-auto text-[14px] md:text-[24px] px-2"
              >
                You've successfully transformed a boring, text-heavy slide into an engaging, visually appealing learning experience!
              </motion.p>

              {/* Design Reference Button */}
              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2.1 }}
                onClick={() => setShowDesignReference(!showDesignReference)}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="mb-3 md:mb-4 px-4 md:px-6 py-2 md:py-3 bg-white/70 hover:bg-white/90 rounded-lg font-[outfit] tracking-wider text-gray-800 shadow-md hover:shadow-lg transition-all inline-flex items-center gap-2 border border-[#d4dce5] text-[16px] md:text-[24px]"
                style={{ fontWeight: 600 }}
              >
                
                📖 View Design Principles
              </motion.button>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 2.2 }}
                className="flex flex-wrap justify-center gap-2 md:gap-4"
              >
                <motion.button
                  onClick={handlePlayAgain}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 md:px-8 py-2 md:py-4 bg-[#7b9eb5] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#6a8ea4] transition-all inline-flex items-center gap-2 text-[16px] md:text-[24px]"
                  style={{ fontWeight: 700 }}
                >
                  <RefreshCw className="w-4 h-4 md:w-5 md:h-5" />
                  Play Again
                </motion.button>
                
                <motion.button
                  onClick={handleBackToIntro}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 md:px-8 py-2 md:py-4 bg-white border-2 border-[#b5a8c5] text-[#6b5b95] rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl transition-all inline-flex items-center gap-2 text-[16px] md:text-[24px]"
                  style={{ fontWeight: 700 }}
                >
                  Back to Start
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5" />
                </motion.button>
              </motion.div>
            </div>
          </div>
        )}
      </div>

      {/* Design Principles Reference Popup */}
      <AnimatePresence>
        {showDesignReference && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={() => setShowDesignReference(false)}
          >
            {/* Backdrop */}
            <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
            
            {/* Modal Content */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="relative bg-white rounded-lg p-8 max-w-4xl w-full shadow-2xl max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close Button */}
              <button
                onClick={() => setShowDesignReference(false)}
                className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                aria-label="Close"
              >
                ✕
              </button>

              <h4 className="text-2xl font-[outfit] tracking-wider mb-6 text-gray-900 text-center" style={{ fontWeight: 700 }}>
                E-Learning Design Principles
              </h4>
              
              <div className="mb-6 bg-gradient-to-r from-[#e8f4f8] to-[#f0f4f8] p-6 rounded-lg border-l-4 border-[#7b9eb5]">
                <p className="font-[outfit] text-gray-800 text-base leading-relaxed" style={{ fontWeight: 600 }}>
                  <strong>Overview:</strong> Throughout this exercise, we applied evidence-based instructional design principles to transform dense, text-heavy content into an engaging, learner-centered experience. Each modification was intentional—reducing cognitive load, improving information retention, and creating a more accessible learning environment.
                </p>
              </div>

              <div className="grid gap-5">
                {/* Step 1: Remove Text Overload */}
                <div className="bg-[#f9e8e0] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-[#d97242] text-lg mb-2" style={{ fontWeight: 700 }}>
                    1. Remove Text Overload
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong>When learners are bombarded with excessive text, cognitive overload occurs, making it harder to process and retain information. Starting with a clean slate allows us to rebuild with intention.
                  </p>
                </div>

                {/* Step 2: Improve Typography */}
                <div className="bg-[#e8f4f8] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-[#7b9eb5] text-lg mb-2" style={{ fontWeight: 700 }}>
                    2. Improve Typography
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Legible, well-sized typography is foundational to accessible design. Proper font choices, sizing, and spacing improve readability and reduce eye strain, making content more approachable for all learners, including those with visual impairments.
                  </p>
                </div>

                {/* Step 3: Add Strategic Color */}
                <div className="bg-[#f5ede8] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#d37b4c]" style={{ fontWeight: 700 }}>
                    3. Add Strategic Color
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Color creates visual hierarchy and directs attention to key concepts. When used purposefully, color helps learners distinguish between different types of information, improves recall, and makes the content more engaging without adding visual clutter.
                  </p>
                </div>

                {/* Step 4: Restructure Layout */}
                <div className="bg-[#fff4e6] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#ea7618]" style={{ fontWeight: 700 }}>
                    4. Restructure Layout
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Organized layouts improve scanability and help learners quickly locate relevant information. Grouping related content, using whitespace effectively, and creating clear visual pathways support cognitive processing and reduce mental effort.
                  </p>
                </div>

                {/* Step 5: Enhance Organization */}
                <div className="bg-[#e8f0f8] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#6aa8d3]" style={{ fontWeight: 700 }}>
                    5. Enhance Organization
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Clear information hierarchy allows learners to digest content in manageable chunks. Breaking information into smaller, organized segments aligns with chunking theory and helps prevent cognitive overload.
                  </p>
                </div>

                {/* Step 6: Add Interactivity */}
                <div className="bg-[#e6f7fa] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#4cacd9]" style={{ fontWeight: 700 }}>
                    6. Add Interactivity
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Interactive elements give learners control over their pace and depth of exploration. Click-to-reveal features reduce initial cognitive load while allowing curious learners to dive deeper, accommodating different learning styles and preferences.
                  </p>
                </div>

                {/* Step 7: Incorporate Visuals */}
                <div className="bg-[#f0e8f5] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#8967b3]" style={{ fontWeight: 700 }}>
                    7. Incorporate Visual Metaphors
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Relevant illustrations and icons support dual coding theory—our brains process visual and verbal information through different channels. Visuals help learners create mental models faster, improve retention, and make abstract concepts more concrete.
                  </p>
                </div>

                {/* Step 8: Polish & Finalize */}
                <div className="bg-[#e8f2f6] p-5 rounded-lg">
                  <p className="font-[outfit] tracking-wide text-lg mb-2 text-[#4a8ab1]" style={{ fontWeight: 700 }}>
                    8. Polish & Finalize
                  </p>
                  <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                    <strong>Why:</strong> Attention to details like consistent spacing, alignment, and subtle visual effects creates a cohesive, professional experience. A polished design builds learner trust and reduces distractions, allowing them to focus on the content itself.
                  </p>
                </div>
              </div>

              {/* Summary Section */}
              <div className="mt-6 bg-gradient-to-br from-[#7b9eb5]/10 to-[#b5a8c5]/10 p-6 rounded-lg border-2 border-[#7b9eb5]/30">
                <h5 className="font-[outfit] tracking-wider text-gray-900 text-xl mb-3 text-center" style={{ fontWeight: 700 }}>
                  ✨ Summary of Changes
                </h5>
                <p className="text-base text-gray-800 font-[outfit] leading-relaxed mb-3">
                  We transformed an overwhelming, text-heavy slide into an engaging, learner-friendly experience by:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-700 font-[outfit]">
                  <li><strong>Reducing cognitive load</strong> through chunking and whitespace</li>
                  <li><strong>Improving accessibility</strong> with better typography and color contrast</li>
                  <li><strong>Creating visual hierarchy</strong> to guide attention and comprehension</li>
                  <li><strong>Adding interactivity</strong> to empower self-paced learning</li>
                  <li><strong>Using visual metaphors</strong> to support dual coding and retention</li>
                  <li><strong>Polishing details</strong> to build trust and eliminate distractions</li>
                </ul>
                <p className="text-base text-gray-800 font-[outfit] leading-relaxed mt-3">
                  The result: a slide that respects learners' cognitive capacity, supports diverse learning needs, and makes complex information approachable and memorable.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}