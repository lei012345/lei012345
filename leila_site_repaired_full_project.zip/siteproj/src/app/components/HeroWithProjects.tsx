import { motion, AnimatePresence } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { Mail, Pencil, Phone, GraduationCap, Folder, MessageCircle, ChevronRight } from "lucide-react";
import profileImage from 'figma:asset/c99a0f3e0f541d5b2ac93fbcce84f2959d5c3287.png';
import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "react-router";
import { useInView } from "motion/react";
import { ContactForm } from "./ContactForm";
import { useLoading } from "../context/LoadingContext";

type Project = typeof portfolioData.projects[number];

function ProjectCard({ project, index, isInView }: { project: Project; index: number; isInView: boolean }) {
  const [hovered, setHovered] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const { showLoading } = useLoading();

  const allPhotos = (project as any).conceptPhotos as string[] | undefined;
  const photos = allPhotos?.filter((src) => src !== project.cardImage);
  const hasPhotos = photos && photos.length > 0;

  useEffect(() => {
    if (hovered && hasPhotos && photos!.length > 1) {
      intervalRef.current = setInterval(() => {
        setActiveIndex((prev) => (prev + 1) % photos!.length);
      }, 1200);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
      setActiveIndex(0);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [hovered, hasPhotos]);

  return (
    <motion.div
      key={project.id}
      className="group w-full"
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
    >
      <Link to={`/project/${project.id}`} className="block" onClick={showLoading}>
        {/* Folder Structure */}
        <div className="relative pt-8">
          {/* Folder Tab - Behind the card */}
          <div className="flex absolute top-0 left-0 z-0">
            <div 
              className="bg-[#f5f2f7] px-6 py-2 flex items-center gap-2 border-t border-2 border-r border-white shadow-lg"
              style={{
                clipPath: 'polygon(8px 0%, calc(100% - 8px) 0%, 100% 100%, 0% 100%)'
              }}
            >
              <span className="text-xs text-[#262626] font-[outfit] tracking-wider" style={{ fontWeight: 600 }}>
                {project.title}
              </span>
            </div>
          </div>

          {/* Folder Body */}
          <motion.div
            className="relative bg-white overflow-hidden transition-all shadow-sm hover:shadow-md z-10"
            whileHover={{ y: -5 }}
            transition={{ duration: 0.2 }}
          >
            {/* Project Image */}
            <div
              className="aspect-[16/10] w-full overflow-hidden bg-gradient-to-br from-muted to-muted/50 relative"
              onMouseEnter={() => setHovered(true)}
              onMouseLeave={() => setHovered(false)}
            >
              {project.cardImage ? (
                <>
                  <img
                    src={project.cardImage}
                    alt={project.title}
                    loading="eager"
                    fetchpriority="high"
                    className={`w-full h-full object-cover transition-transform duration-500 ${hovered ? 'scale-105' : 'scale-100'} ${project.id === 1 ? 'object-top' : ''} ${project.id === 8 ? 'object-[center_40%]' : ''}`}
                  />

                  {/* White Overlay with Logo */}
                  {project.logo && (
                    <div className="absolute inset-0 flex items-center justify-center bg-white/85">
                      {project.id === 9 ? (
                        <h3 className="text-2xl font-[outfit] tracking-wider text-center px-6 text-[#262626]" style={{ fontWeight: 700 }}>
                          Navigating<br />Difficult Conversations at Work
                        </h3>
                      ) : (
                        <img
                          src={project.logo}
                          alt={project.title}
                          className={`w-auto object-contain ${project.id === 1 ? 'h-14' : project.id === 7 ? 'h-20' : project.id === 8 ? 'h-24' : 'h-16'}`}
                        />
                      )}
                    </div>
                  )}

                  {hasPhotos && (
                    <>
                      {photos!.map((src, i) => (
                        <img
                          key={i}
                          src={src}
                          alt={`${project.title} concept ${i + 1}`}
                          className="absolute inset-0 w-full h-full object-cover transition-opacity duration-500"
                          style={{ opacity: hovered && activeIndex === i ? 1 : 0 }}
                        />
                      ))}

                      <div
                        className="absolute bottom-1 left-1/2 -translate-x-1/2 flex gap-1 transition-opacity duration-300"
                        style={{ opacity: hovered ? 1 : 0 }}
                      >
                        {photos!.map((_, i) => (
                          <div
                            key={i}
                            className="w-1 h-1 rounded-full transition-all duration-300"
                            style={{
                              background: activeIndex === i ? '#ffffff' : 'rgba(255,255,255,0.45)',
                              transform: activeIndex === i ? 'scale(1.2)' : 'scale(1)',
                            }}
                          />
                        ))}
                      </div>
                    </>
                  )}
                </>
              ) : null}
            </div>
          </motion.div>
        </div>
      </Link>
    </motion.div>
  );
}

export function HeroWithProjects() {
  const [activeTab, setActiveTab] = useState<'projects' | 'skills' | 'contact'>('projects');
  const [isTabExpanded, setIsTabExpanded] = useState(false);
  const [isBackButtonHovered, setIsBackButtonHovered] = useState(false);
  const [hasPlayedInitialAnimation, setHasPlayedInitialAnimation] = useState(false);
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [clickedSkill, setClickedSkill] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const skillsRef = useRef(null);
  const isSkillsInView = useInView(skillsRef, { once: true, margin: "-100px" });
  const tabContentRef = useRef<HTMLDivElement>(null);
  const location = useLocation();

  // Detect mobile viewport
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1280);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Play initial tab animation once
  useEffect(() => {
    const timer = setTimeout(() => {
      setHasPlayedInitialAnimation(true);
    }, 2000);
    
    return () => clearTimeout(timer);
  }, []);

  // Handle navigation from project detail pages
  useEffect(() => {
    if (location.hash === '#projects') {
      setActiveTab('projects');
      setIsTabExpanded(true);
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      setTimeout(() => {
        if (tabContentRef.current) {
          tabContentRef.current.scrollTop = 0;
        }
      }, 100);
    }
  }, [location.hash]);

  const handleTabClick = (tabId: 'projects' | 'skills' | 'contact') => {
    setActiveTab(tabId);
    setIsTabExpanded(true);
    
    setTimeout(() => {
      if (tabContentRef.current) {
        tabContentRef.current.scrollTop = 0;
      }
    }, 50);
  };

  const handleGetInTouch = () => {
    setActiveTab('contact');
    setIsTabExpanded(true);
    
    setTimeout(() => {
      if (tabContentRef.current) {
        tabContentRef.current.scrollTop = 0;
      }
    }, 50);
    
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const tabs = [
    { id: 'projects' as const, label: 'Projects', color: 'from-blue-400 to-cyan-400' },
    { id: 'skills' as const, label: 'Skills', color: 'from-pink-400 to-rose-400' },
    { id: 'contact' as const, label: 'Contact', color: 'from-yellow-400 to-orange-400' },
  ];

  return (
    <section id="home" className="min-h-screen px-4 md:px-8 lg:px-12 py-6 pb-3 relative overflow-hidden" ref={ref}>
      <div className="max-w-[1500px] mx-auto relative z-10">
        {/* Mobile: Stack everything vertically */}
        <div className="flex flex-col xl:hidden gap-4">
          {/* Hero Content */}
          <div className="w-full bg-white rounded-2xl p-6 md:p-8 shadow-sm">
            <div className="flex flex-col items-center text-center">
              {/* Profile Image */}
              <motion.div
                className="relative flex-shrink-0"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                <img
                  src={profileImage}
                  alt="Profile"
                  loading="eager"
                  fetchpriority="high"
                  className="w-30 h-30 md:w-52 md:h-52 rounded-full object-cover shadow-lg hover:shadow-xl transition-shadow ring-4 ring-white"
                />
              </motion.div>

              {/* Name */}
              <motion.h1
                className="text-[#1f1f1f] text-[20px] md:text-[30px] leading-tight mt-6 tracking-widest uppercase"
                style={{ fontFamily: 'outfit, sans-serif', fontWeight: 900 }}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
              >
                {portfolioData.name}
              </motion.h1>

              {/* Role/Title and Education */}
              <div className="mt-4 space-y-2.5 w-full">
                <motion.div
                  className="flex items-center justify-center gap-2.5"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                >
                  <span 
                    className="tracking-widest text-[#715c94] mx-[0px] mt-[-18px] mb-[0px] text-[15px] font-[Manrope]" 
                    style={{ fontWeight: 700 }}
                  >
                    WEB & GRAPHIC DESIGNER
                  </span>
                </motion.div>
                
                <motion.div
                  className="flex flex-col sm:flex-row sm:items-center justify-center gap-1 sm:gap-2 text-[#7496b5] font-[Fustat] text-[13px]"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                >
                  <div className="flex items-center justify-center gap-2">
                    <GraduationCap className="w-4 h-4 flex-shrink-0" />
                    <span className="text-[#48647D] font-[outfit] font-semibold tracking-wider text-[11px]">George Mason University</span>
                  </div>
                  <span className="hidden sm:inline">•</span>
                  <span className="text-center text-[#48647D] font-[outfit] font-semibold tracking-wider text-[11px]">BA in Communication</span>
                </motion.div>
              </div>

              {/* Bio Paragraph */}
              <motion.p
                className="text-[#40464f] leading-relaxed mt-6 tracking-wider text-left font-[Outfit] text-[13px]"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                Hi, I'm Leila, a DMV-based web and graphic designer who loves turning ideas into meaningful visual experiences. I focus on creating modern, user-friendly brands and websites that feel intentional and approachable. When I'm not designing, you'll usually find me illustrating, editing videos, or experimenting with short animations.
              </motion.p>
            </div>
            
            {/* Get in touch - at bottom of hero section */}
            <motion.div
              className="w-full mt-8 pt-6 border-t border-border/20"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.7 }}
            >
              <button
                onClick={handleGetInTouch}
                className="w-full bg-blue-50 py-3.5 px-6 rounded-xl hover:shadow-lg hover:scale-[1.02] hover:bg-blue-100 transition-all flex items-center justify-center gap-2 group border border-blue-200 text-[#30529f] font-bold font-[outfit] tracking-wide"
                style={{ fontWeight: 800 }}
              >
                <Mail className="w-5 h-5 group-hover:scale-110 transition-transform" style={{ color: '#30529F' }} />
                GET IN TOUCH
              </button>
            </motion.div>
          </div>

          {/* Projects */}
          <div id="projects" className="relative">
            <div className="flex">
              <div 
                className="bg-white px-6 py-3 flex items-center gap-2"
                style={{
                  clipPath: 'polygon(12px 0%, calc(100% - 12px) 0%, 100% 100%, 0% 100%)',
                  boxShadow: '0 -2px 4px rgba(0,0,0,0.05), 2px 0 4px rgba(0,0,0,0.05), -2px 0 4px rgba(0,0,0,0.05)'
                }}
              >
                <Folder className="w-4 h-4 text-gray-700" />
                <span className="text-sm text-gray-900" style={{ fontWeight: 600 }}>Projects</span>
              </div>
            </div>
            
            <div className="bg-white rounded-b-2xl rounded-tr-2xl p-8 md:p-10 shadow-sm">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
                transition={{ duration: 0.6 }}
                className="mb-8"
              >
                <h2 className="mb-6 uppercase tracking-wider font-[outfit] text-[24px] text-center" style={{ fontWeight: 800 }}>
                  Featured Projects
                </h2>
              </motion.div>

              <div className="grid grid-cols-1 gap-6">
                {portfolioData.projects.map((project, index) => (
                  <ProjectCard key={project.id} project={project} index={index} isInView={isInView} />
                ))}
              </div>
            </div>
          </div>

          {/* Skills */}
          <div id="skills" className="relative">
            <div className="flex">
              <div 
                className="bg-white px-6 py-3 flex items-center gap-2"
                style={{
                  clipPath: 'polygon(12px 0%, calc(100% - 12px) 0%, 100% 100%, 0% 100%)',
                  boxShadow: '0 -2px 4px rgba(0,0,0,0.05), 2px 0 4px rgba(0,0,0,0.05), -2px 0 4px rgba(0,0,0,0.05)'
                }}
              >
                <Pencil className="w-4 h-4 text-gray-700" />
                <span className="text-sm text-gray-900" style={{ fontWeight: 600 }}>Skills</span>
              </div>
            </div>
            
            <div className="bg-white rounded-b-2xl rounded-tr-2xl p-8 md:p-10 shadow-sm relative overflow-hidden">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="mb-8"
              >
                <h2 className="mb-3 font-[outfit] tracking-wider uppercase text-[24px] text-center" style={{ fontWeight: 800 }}>
                  Skills & Tools
                </h2>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 relative z-10">
                {portfolioData.skillCategories.map((category, categoryIndex) => (
                  <motion.div
                    key={categoryIndex}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
                    className="relative"
                  >
                    <div className="relative bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-all border border-gray-100">
                      <div className="flex items-center gap-2.5 mb-4">
                        <span className="text-2xl">{category.icon}</span>
                        <h3 className="font-[manrope] tracking-wider uppercase text-base text-gray-900" style={{ fontWeight: 900 }}>
                          {category.category}
                        </h3>
                      </div>

                      <div className={`${category.category === "Design Tools" || category.category === "Video & Motion" || category.category === "Other Tools" || category.category === "Web Development" ? "flex flex-wrap gap-3 justify-start items-center" : "flex flex-col gap-1.5"}`}>
                        {category.category === "Design Tools" || category.category === "Video & Motion" || category.category === "Other Tools" || category.category === "Web Development" ? (
                          category.skills.map((skill, skillIndex) => {
                            const iconMap: Record<string, string> = {
                              "Figma": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/figma-logo_brandlogos.net_6n1pb-512x512.png",
                              "Procreate": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Procreate_icon.png",
                              "Adobe Photoshop": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_Photoshop_CC_icon.png",
                              "Adobe Illustrator": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/adobe-i.png",
                              "Adobe InDesign": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_InDesign_CC_icon.svg.png",
                              "Canva": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/canva-logo.png",
                              "Adobe Premiere Pro": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_Premiere_Pro_CC_icon.png",
                              "Adobe After Effects": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_After_Effects_CC_icon.svg.png",
                              "DaVinci Resolve": "https://lh3.googleusercontent.com/d/19uv8bMTA570DcsbibJb95rSktiD8hHn6",
                              "CapCut": "https://lh3.googleusercontent.com/d/18aO24j5-S4TXlXNKH73ISbp4mnq0qTiQ",
                              "ToonSquid": "https://lh3.googleusercontent.com/d/1Kac4cGEpkGqJOoOq1SuvNi0I5jGkNTHP",
                              "Git/GitHub": "https://lh3.googleusercontent.com/d/1smelog4b-XnLdUC7OQpN-xVg5CRYnqTB",
                              "Framer": "https://lh3.googleusercontent.com/d/1FxS68CbJlmfA_Ggg_ofybBrClhXlIA9N",
                              "Webflow": "https://lh3.googleusercontent.com/d/1MYzBpIUA_LgOjKlQ1BfvdUINLTyOGJs8",
                              "WordPress": "https://lh3.googleusercontent.com/d/1nsmizilqsmnyayS15llif5KCJdduEor1",
                              "Microsoft 365": "https://lh3.googleusercontent.com/d/16xbMUc257jSxGnpETWYLqcMzRsKOZYWd",
                              "Google Workspace": "https://lh3.googleusercontent.com/d/1tS2pbby2FlgEJu5eJEO-V3y1TLuky2Tz",
                              "HTML": "https://lh3.googleusercontent.com/d/1uR6hSItWKtF_plWJGYkglYc1OY-irUBr",
                              "CSS": "https://lh3.googleusercontent.com/d/1w9tRIFyFlO-A7gQgUDFaJS7JGl-l2smH",
                              "JavaScript": "https://lh3.googleusercontent.com/d/1Z4uU5JzwrdYlCF2uvh5CR6W4QRjcW76k",
                              "React": "https://lh3.googleusercontent.com/d/1jxoxHlNe1e5bAc4aZhjPUbvUk68B95z9",
                              "TypeScript": "https://lh3.googleusercontent.com/d/1p41hFPajGG1hVnpwjqex2Md7GhiF3XDA",
                              "Tailwind CSS": "https://lh3.googleusercontent.com/d/1MQUpusX-cPjNuvP9apkSmhRfe2BmDqx1"
                            };
                            
                            return (
                              <motion.div
                                key={skillIndex}
                                className="relative group cursor-pointer"
                                initial={{ opacity: 0, scale: 0.5 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ delay: categoryIndex * 0.1 + skillIndex * 0.05 }}
                                whileHover={{ scale: 1.1 }}
                                onClick={() => setClickedSkill(clickedSkill === skill ? null : skill)}
                              >
                                <img
                                  src={iconMap[skill]}
                                  alt={skill}
                                  className="w-12 h-12 object-contain transition-all"
                                />
                                <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded-lg transition-opacity whitespace-nowrap pointer-events-none z-20 font-[outfit] tracking-wider ${clickedSkill === skill ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} style={{ fontWeight: 600 }}>
                                  {skill}
                                  <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900"></div>
                                </div>
                              </motion.div>
                            );
                          })
                        ) : (
                          category.skills.map((skill, skillIndex) => (
                            <motion.div
                              key={skillIndex}
                              className="text-sm text-gray-700 font-[raleway] tracking-wider hover:text-gray-900 transition-colors cursor-default relative"
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: categoryIndex * 0.1 + skillIndex * 0.05 }}
                              style={{ fontWeight: 500 }}
                            >
                              • {skill}
                            </motion.div>
                          ))
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>

          {/* Contact */}
          <div id="contact" className="relative">
            <div className="flex">
              <div 
                className="bg-white px-6 py-3 flex items-center gap-2"
                style={{
                  clipPath: 'polygon(12px 0%, calc(100% - 12px) 0%, 100% 100%, 0% 100%)',
                  boxShadow: '0 -2px 4px rgba(0,0,0,0.05), 2px 0 4px rgba(0,0,0,0.05), -2px 0 4px rgba(0,0,0,0.05)'
                }}
              >
                <MessageCircle className="w-4 h-4 text-gray-700" />
                <span className="text-sm text-gray-900" style={{ fontWeight: 600 }}>Contact</span>
              </div>
            </div>
            
            <div className="bg-white rounded-b-2xl rounded-tr-2xl p-8 md:p-10 shadow-sm">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="text-3xl mb-3 font-[outfit] tracking-wider uppercase text-center" style={{ fontWeight: 800 }}>
                  Get in Touch
                </h2>
                <p className="text-sm text-center text-[#40464f] font-[outfit] tracking-wider mb-6">
                  Fill out the form below and I'll get in touch as soon as possible. You may also email, call or send a text.
                </p>

                <div className="w-full max-w-2xl mx-auto">
                  <ContactForm recipientEmail={portfolioData.social.email} />
                </div>
              </motion.div>
            </div>
          </div>
        </div>

        {/* Desktop: Two columns with folder tabs */}
        <div className="hidden xl:flex gap-8 items-start relative justify-center">
          {/* Back to Hero Arrow */}
          <AnimatePresence>
            {isTabExpanded && (
              <motion.button
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                onClick={() => setIsTabExpanded(false)}
                onMouseEnter={() => {
                  setIsBackButtonHovered(true);
                  setIsTabExpanded(false);
                }}
                onMouseLeave={() => setIsBackButtonHovered(false)}
                className="fixed left-6 top-1/2 -translate-y-1/2 z-50 hover:scale-110 transition-all"
                aria-label="Back to hero"
              >
                <ChevronRight className="w-20 h-20 text-white drop-shadow-lg rotate-180 hover:drop-shadow-2xl transition-all" />
              </motion.button>
            )}
          </AnimatePresence>

          {/* Left Side: Hero */}
          <motion.div 
            className="overflow-hidden"
            animate={{ 
              width: isTabExpanded ? '0%' : '35%',
              opacity: isTabExpanded ? 0 : 1,
              marginRight: isTabExpanded ? '0px' : '0px'
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
          >
            <div className="w-full bg-white rounded-2xl p-6 shadow-sm overflow-hidden">
              <div className="flex flex-col items-center text-center">
                <motion.div
                  className="relative flex-shrink-0"
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.5 }}
                >
                  <img
                    src={profileImage}
                    alt="Profile"
                    loading="eager"
                    fetchpriority="high"
                    className="w-30 h-30 rounded-full object-cover shadow-lg hover:shadow-xl transition-shadow ring-4 ring-white"
                  />
                </motion.div>

                <motion.h1
                  className="text-[#1f1f1f] leading-tight mt-6 tracking-widest uppercase text-[24px]"
                  style={{ fontFamily: 'outfit, sans-serif', fontWeight: 900 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.1 }}
                >
                  {portfolioData.name}
                </motion.h1>

                <div className="mt-4 space-y-2.5 w-full">
                  <motion.div
                    className="flex items-center justify-center gap-2.5"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.2 }}
                  >
                    <span 
                      className="tracking-widest text-[#715c94] mx-[0px] mt-[-18px] mb-[0px] text-[15px] font-[Manrope]" 
                      style={{ fontWeight: 700 }}
                    >
                      WEB & GRAPHIC DESIGNER
                    </span>
                  </motion.div>
                  
                  <motion.div
                    className="flex flex-col sm:flex-row sm:items-center justify-center gap-1 sm:gap-2 text-[#7496b5] font-[Fustat] text-[13px]"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8, delay: 0.3 }}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <GraduationCap className="w-4 h-4 flex-shrink-0" />
                      <span className="text-[#48647D] font-[outfit] font-semibold tracking-wider text-[11px]">George Mason University</span>
                    </div>
                    <span className="hidden sm:inline">•</span>
                    <span className="text-center text-[#48647D] font-[outfit] font-semibold tracking-wider text-[11px]">BA in Communication</span>
                  </motion.div>
                </div>

                <motion.p
                  className="text-[#40464f] leading-relaxed mt-6 tracking-wider text-left font-[Outfit] text-[13px]"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                >
                  Hi, I'm Leila, a DMV-based web and graphic designer who loves turning ideas into meaningful visual experiences. I focus on creating modern, user-friendly brands and websites that feel intentional and approachable. When I'm not designing, you'll usually find me illustrating, editing videos, or experimenting with short animations.
                </motion.p>
              </div>
              
              <motion.div
                className="w-full mt-8 pt-6 border-t border-border/20"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.7 }}
              >
                <button
                  onClick={handleGetInTouch}
                  className="w-full bg-blue-50 py-3.5 px-6 rounded-xl hover:shadow-lg hover:scale-[1.02] hover:bg-blue-100 transition-all flex items-center justify-center gap-2 group border border-blue-200 text-[#30529f] font-bold font-[outfit] tracking-wide"
                  style={{ fontWeight: 800 }}
                >
                  <Mail className="w-5 h-5 group-hover:scale-110 transition-transform" style={{ color: '#30529F' }} />
                  GET IN TOUCH
                </button>
              </motion.div>
            </div>
          </motion.div>

          {/* Right Side: Folder Tabs + Content */}
          <motion.div 
            className="flex flex-col"
            animate={{ 
              width: isTabExpanded ? '85%' : '65%'
            }}
            transition={{ duration: 0.5, ease: "easeInOut" }}
            onMouseEnter={() => setIsTabExpanded(true)}
          >
            {/* Folder Tabs */}
            <div className="flex gap-1 mb-0 flex-shrink-0">
              {tabs.map((tab, index) => {
                const TabIcon = tab.id === 'skills' ? Pencil : tab.id === 'contact' ? MessageCircle : Folder;
                
                return (
                  <motion.button
                    key={tab.id}
                    onClick={() => handleTabClick(tab.id)}
                    className={`relative px-6 py-3 transition-all ${
                      activeTab === tab.id
                        ? 'bg-white'
                        : 'bg-white/40 hover:bg-white/60'
                    }`}
                    style={{
                      clipPath: 'polygon(12px 0%, calc(100% - 12px) 0%, 100% 100%, 0% 100%)',
                      borderRadius: 0,
                      boxShadow: activeTab === tab.id 
                        ? '0 -2px 4px rgba(0,0,0,0.05), 2px 0 4px rgba(0,0,0,0.05), -2px 0 4px rgba(0,0,0,0.05)'
                        : '0 -1px 2px rgba(0,0,0,0.03)'
                    }}
                    initial={{ y: 0 }}
                    animate={!hasPlayedInitialAnimation ? { 
                      y: [0, -12, 0]
                    } : {
                      y: 0
                    }}
                    transition={{
                      duration: 0.3,
                      delay: index * 0.1 + 0.8,
                      ease: "easeInOut"
                    }}
                  >
                    <div className="flex items-center gap-2 tracking-wider">
                      <TabIcon className={`w-4 h-4 ${activeTab === tab.id ? 'text-gray-700' : 'text-gray-400'}`} />
                      <span 
                        className={`text-sm ${activeTab === tab.id ? 'text-gray-900' : 'text-gray-500'} font-[outfit]`}
                        style={{ fontWeight: activeTab === tab.id ? 600 : 500 }}
                      >
                        {tab.label}
                      </span>
                    </div>
                    {activeTab === tab.id && (
                      <div className="absolute bottom-0 left-0 right-0 h-1" style={{ backgroundColor: '#5080B2' }} />
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Tab Content */}
            <div className="bg-white/80 backdrop-blur-sm rounded-b-2xl rounded-tr-2xl p-8 shadow-sm flex-1 overflow-y-auto" ref={tabContentRef}>
              <AnimatePresence mode="wait">
                {activeTab === 'projects' && (
                  <motion.div
                    key="projects"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    <h2 className="mb-6 uppercase tracking-wider font-[outfit] text-[24px]" style={{ fontWeight: 800 }}>Featured Projects</h2>
                    <div className="grid grid-cols-2 gap-4">
                      {portfolioData.projects.map((project, index) => (
                        <ProjectCard key={project.id} project={project} index={index} isInView={true} />
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'skills' && (
                  <motion.div
                    key="skills"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="relative"
                  >
                    <h2 className="mb-3 font-[outfit] tracking-wider uppercase text-[24px] text-center" style={{ fontWeight: 800 }}>
                      Skills & Tools
                    </h2>
                    
                    <div className="grid grid-cols-2 gap-4">
                      {portfolioData.skillCategories.map((category, categoryIndex) => (
                        <motion.div
                          key={categoryIndex}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.4, delay: categoryIndex * 0.1 }}
                          className="relative"
                        >
                          <div className="relative bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-all border border-gray-100">
                            <div className="flex items-center gap-2.5 mb-4">
                              <span className="text-2xl">{category.icon}</span>
                              <h3 className="tracking-wide uppercase text-base text-gray-900 font-[Outfit]" style={{ fontWeight: 800 }}>
                                {category.category}
                              </h3>
                            </div>

                            <div className={`${category.category === "Design Tools" || category.category === "Video & Motion" || category.category === "Other Tools" || category.category === "Web Development" ? "flex flex-wrap gap-3 justify-start items-center" : "flex flex-col gap-1.5"}`}>
                              {category.category === "Design Tools" || category.category === "Video & Motion" || category.category === "Other Tools" || category.category === "Web Development" ? (
                                category.skills.map((skill, skillIndex) => {
                                  const iconMap: Record<string, string> = {
                                    "Figma": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/figma-logo_brandlogos.net_6n1pb-512x512.png",
                                    "Procreate": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Procreate_icon.png",
                                    "Adobe Photoshop": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_Photoshop_CC_icon.png",
                                    "Adobe Illustrator": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/adobe-i.png",
                                    "Adobe InDesign": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_InDesign_CC_icon.svg.png",
                                    "Canva": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/canva-logo.png",
                                    "Adobe Premiere Pro": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_Premiere_Pro_CC_icon.png",
                                    "Adobe After Effects": "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Adobe_After_Effects_CC_icon.svg.png",
                                    "DaVinci Resolve": "https://lh3.googleusercontent.com/d/19uv8bMTA570DcsbibJb95rSktiD8hHn6",
                                    "CapCut": "https://lh3.googleusercontent.com/d/18aO24j5-S4TXlXNKH73ISbp4mnq0qTiQ",
                                    "ToonSquid": "https://lh3.googleusercontent.com/d/1Kac4cGEpkGqJOoOq1SuvNi0I5jGkNTHP",
                                    "Git/GitHub": "https://lh3.googleusercontent.com/d/1smelog4b-XnLdUC7OQpN-xVg5CRYnqTB",
                                    "Framer": "https://lh3.googleusercontent.com/d/1FxS68CbJlmfA_Ggg_ofybBrClhXlIA9N",
                                    "Webflow": "https://lh3.googleusercontent.com/d/1MYzBpIUA_LgOjKlQ1BfvdUINLTyOGJs8",
                                    "WordPress": "https://lh3.googleusercontent.com/d/1nsmizilqsmnyayS15llif5KCJdduEor1",
                                    "Microsoft 365": "https://lh3.googleusercontent.com/d/16xbMUc257jSxGnpETWYLqcMzRsKOZYWd",
                                    "Google Workspace": "https://lh3.googleusercontent.com/d/1tS2pbby2FlgEJu5eJEO-V3y1TLuky2Tz",
                                    "HTML": "https://lh3.googleusercontent.com/d/1uR6hSItWKtF_plWJGYkglYc1OY-irUBr",
                                    "CSS": "https://lh3.googleusercontent.com/d/1w9tRIFyFlO-A7gQgUDFaJS7JGl-l2smH",
                                    "JavaScript": "https://lh3.googleusercontent.com/d/1Z4uU5JzwrdYlCF2uvh5CR6W4QRjcW76k",
                                    "React": "https://lh3.googleusercontent.com/d/1jxoxHlNe1e5bAc4aZhjPUbvUk68B95z9",
                                    "TypeScript": "https://lh3.googleusercontent.com/d/1p41hFPajGG1hVnpwjqex2Md7GhiF3XDA",
                                    "Tailwind CSS": "https://lh3.googleusercontent.com/d/1MQUpusX-cPjNuvP9apkSmhRfe2BmDqx1"
                                  };
                                  
                                  return (
                                    <motion.div
                                      key={skillIndex}
                                      className="relative group cursor-pointer"
                                      initial={{ opacity: 0, scale: 0.5 }}
                                      animate={{ opacity: 1, scale: 1 }}
                                      transition={{ delay: categoryIndex * 0.1 + skillIndex * 0.05 }}
                                      whileHover={{ scale: 1.1 }}
                                      onClick={() => setClickedSkill(clickedSkill === skill ? null : skill)}
                                    >
                                      <img
                                        src={iconMap[skill]}
                                        alt={skill}
                                        className="w-12 h-12 object-contain transition-all"
                                      />
                                      <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 bg-gray-900 text-white text-xs rounded-lg transition-opacity whitespace-nowrap pointer-events-none z-20 font-[outfit] tracking-wider ${clickedSkill === skill ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} style={{ fontWeight: 600 }}>
                                        {skill}
                                        <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-gray-900"></div>
                                      </div>
                                    </motion.div>
                                  );
                                })
                              ) : (
                                category.skills.map((skill, skillIndex) => (
                                  <motion.div
                                    key={skillIndex}
                                    className="text-sm text-gray-700 font-[raleway] tracking-wider hover:text-gray-900 transition-colors cursor-default relative"
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ delay: categoryIndex * 0.1 + skillIndex * 0.05 }}
                                    style={{ fontWeight: 500 }}
                                  >
                                    • {skill}
                                  </motion.div>
                                ))
                              )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </motion.div>
                )}

                {activeTab === 'contact' && (
                  <motion.div
                    key="contact"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                    className="relative"
                  >
                    <h2 className="text-3xl mb-3 font-[outfit] tracking-wider uppercase" style={{ fontWeight: 800 }}>Get in Touch</h2>
                    <p className="text-sm mb-6 text-[#1f1f1f] font-[outfit] tracking-wider">Fill out the form below and I'll get in touch as soon as possible.<br /> You may also email, call or send a text.</p>

                    {activeTab === 'contact' && isTabExpanded && !isMobile && (
                      <motion.div 
                        key={`hero-info-${activeTab}`}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ 
                          opacity: 1,
                          scale: 1
                        }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        transition={{ duration: 0.3 }}
                        className="absolute top-0 right-0 w-[280px] z-10"
                      >
                        <div className="bg-gradient-to-br from-white to-gray-50 rounded-xl border border-gray-200 shadow-sm p-5">
                          <img
                            src={profileImage}
                            alt={portfolioData.name}
                            className="w-24 h-24 rounded-full object-cover ring-2 ring-white shadow-md mx-auto mb-4"
                          />
                          
                          <h3 className="font-[outfit] tracking-wider text-[#1f1f1f] text-base uppercase mb-4 text-center" style={{ fontWeight: 800 }}>
                            {portfolioData.name}
                          </h3>
                          
                          <div className="flex flex-col gap-2">
                            <a 
                              href={`mailto:${portfolioData.social.email}`}
                              className="flex items-center gap-2 p-2.5 bg-white rounded-lg hover:shadow-md hover:scale-[1.02] transition-all group border border-gray-200"
                            >
                              <Mail className="w-4.5 h-4.5 text-[#AF66AF] group-hover:scale-110 transition-transform flex-shrink-0" />
                              <p className="group-hover:text-gray-700 transition-colors text-[#af66af] font-[outfit] break-all text-left text-[16px] tracking-wide" style={{ fontWeight: 600 }}>
                                {portfolioData.social.email}
                              </p>
                            </a>
                            
                            <a 
                              href={`tel:${portfolioData.social.phone}`}
                              className="flex items-center gap-2 p-2.5 bg-white rounded-lg hover:shadow-md hover:scale-[1.02] transition-all group border border-gray-200"
                            >
                              <Phone className="w-4.5 h-4.5 text-[#5080B2] group-hover:scale-110 transition-transform flex-shrink-0" />
                              <p className="group-hover:text-gray-700 transition-colors text-[#5080b2] font-[outfit] tracking-wide text-[15px]" style={{ fontWeight: 600 }}>
                                {portfolioData.social.phone}
                              </p>
                            </a>
                          </div>
                        </div>
                      </motion.div>
                    )}

                    <div className="w-full">
                      <ContactForm recipientEmail={portfolioData.social.email} />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export default HeroWithProjects;