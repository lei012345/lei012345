import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { useState, useRef } from "react";
import { useInView } from "motion/react";
import Lottie from "lottie-react";
import typescriptAnimation from "../../imports/typescript-logo.json";
import trainingAnimation from "../../imports/training-animation.json";
import videoCameraAnimation from "../../imports/video_camera.json";
import dashboardAnimation from "../../imports/dashboard.json";

export function Skills() {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [clickedSkill, setClickedSkill] = useState<string | null>(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const floatingIcons = [
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-lottie.png', alt: 'Lottie', size: 'w-12 h-12', delay: 0 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-ps.png', alt: 'Photoshop', size: 'w-14 h-14', delay: 0.5 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-illustrator.png', alt: 'Illustrator', size: 'w-12 h-12', delay: 1 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-canva-logo.png', alt: 'Canva', size: 'w-16 h-16', delay: 1.5 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-articulate.jpg', alt: 'Articulate', size: 'w-12 h-12', delay: 2.5 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/99-Procreate_icon.png', alt: 'Procreate', size: 'w-14 h-14', delay: 3 },
    { src: 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/java1.png', alt: 'JavaScript', size: 'w-12 h-12', delay: 3.5 },
  ];

  return (
    <section id="skills" ref={ref} className="py-16 px-4 md:px-8 lg:px-12">
      <div className="max-w-[1400px] mx-auto">
        <motion.div 
          className="mb-12 text-center relative"
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          {/* Floating Icons - Horizontal Line Above */}
          <div className="flex gap-4 md:gap-6 items-center justify-center flex-wrap max-w-xl mx-auto mb-8">
            {floatingIcons.map((icon, index) => (
              <motion.div
                key={index}
                className={icon.size}
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? {
                  opacity: 0.80,
                  scale: 1,
                  y: [0, -15, 0],
                } : { opacity: 0, scale: 0 }}
                transition={{
                  opacity: { duration: 0.6, delay: icon.delay * 0.2 },
                  scale: { duration: 0.6, delay: icon.delay * 0.2 },
                  y: {
                    duration: 3 + Math.random() * 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: icon.delay * 0.2,
                  },
                }}
              >
                <img 
                  src={icon.src} 
                  alt={icon.alt}
                  className="w-full h-full object-contain"
                />
              </motion.div>
            ))}
          </div>

          <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] text-[#546DA6] tracking-wider uppercase" style={{ fontWeight: 900 }}>
            Skills & Expertise
          </h2>
          
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
            Tools and technologies I work with
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portfolioData.skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.category}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
              transition={{ duration: 0.5, delay: categoryIndex * 0.1 }}
              className="bg-gradient-to-br from-purple-50/50 via-pink-50/50 to-blue-50/50 rounded-3xl p-6 border border-gray-100 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12">
                  <Lottie 
                    animationData={category.category === "E-Learning Tools" ? trainingAnimation : category.category === "Video & Motion" ? videoCameraAnimation : category.category === "Design Tools" ? dashboardAnimation : typescriptAnimation}
                    loop={true}
                    className="w-full h-full bg-[#84464600]"
                  />
                </div>
                <h3 className="text-xl font-[outfit] tracking-wider uppercase text-[#6D5593]" style={{ fontWeight: 700 }}>
                  {category.category}
                </h3>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {category.skills.map((skill) => (
                  <motion.button
                    key={skill}
                    onClick={() => setClickedSkill(skill === clickedSkill ? null : skill)}
                    onMouseEnter={() => setHoveredSkill(skill)}
                    onMouseLeave={() => setHoveredSkill(null)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-4 py-2 rounded-full text-sm font-[outfit] tracking-wider transition-all ${
                      clickedSkill === skill
                        ? "bg-[#715c94] text-white shadow-md"
                        : hoveredSkill === skill
                        ? "bg-[#8b7ba8] text-white"
                        : "bg-white text-gray-700 border border-gray-200 hover:border-[#715c94]"
                    }`}
                  >
                    {skill}
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}