import { motion, AnimatePresence } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { Mail, Lightbulb, Users, Sparkles } from "lucide-react";
import { useState, useEffect } from "react";
import Lottie from "lottie-react";
import activityAnimation from "../../imports/Activity.json";
import accreditationAnimation from "../../imports/Accreditation_(1).json";
import toDoAnimation from "../../imports/To_Do_(1).json";
import iqAnimation from "../../imports/Iq.json";
import videoTimelineAnimation from "../../imports/Video_Timeline_(1).json";
import questionHubAnimation from "../../imports/Question_Hub.json";
import chooseAnimation from "../../imports/Choose_(1).json";
import womanLaptopAnimation from "../../imports/ID1.json";
import cloudsAnimation from "../../imports/clouds_loop.json";

const cloudUrl =
  "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/cloud3.png";

const womanImageUrl =
  "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/designing-1.png";

const clouds = [
  { id: 1, width: 160, top: "6%", left: "-12%", duration: 98, opacity: 0.58, floatDuration: 14 },
  { id: 2, width: 245, top: "18%", left: "-36%", duration: 84, opacity: 0.62, floatDuration: 16 },
  { id: 3, width: 185, top: "34%", left: "-58%", duration: 92, opacity: 0.56, floatDuration: 13 },
  { id: 4, width: 270, top: "52%", left: "-80%", duration: 86, opacity: 0.52, floatDuration: 17 },
  { id: 5, width: 150, top: "68%", left: "-30%", duration: 82, opacity: 0.6, floatDuration: 12 },
  { id: 6, width: 215, top: "84%", left: "-64%", duration: 90, opacity: 0.54, floatDuration: 15 },
];

export function AboutAnimated() {
  const [typedText, setTypedText] = useState("");
  const fullText = "DESIGNING ENGAGING";
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const morphingAnimations = [
    videoTimelineAnimation,
    iqAnimation,
    questionHubAnimation,
    activityAnimation,
    chooseAnimation,
    toDoAnimation,
    accreditationAnimation,
  ];

  const floatStyle = `
    @keyframes desktopFloatSmooth {
      0% {
        transform: translate3d(0, 0px, 0);
      }
      50% {
        transform: translate3d(0, -10px, 0);
      }
      100% {
        transform: translate3d(0, 0px, 0);
      }
    }

    .desktop-float {
      animation: desktopFloatSmooth 3.2s ease-in-out infinite;
      will-change: transform;
      backface-visibility: hidden;
      transform: translateZ(0);
    }
  `;

  useEffect(() => {
    let index = 0;
    const typingInterval = setInterval(() => {
      if (index <= fullText.length) {
        setTypedText(fullText.slice(0, index));
        index++;
      } else {
        clearInterval(typingInterval);
      }
    }, 50);

    return () => clearInterval(typingInterval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % morphingAnimations.length);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const handleGetInTouch = () => {
    const contactSection = document.getElementById("contact");
    if (contactSection) {
      const navHeight = 80;
      const elementPosition =
        contactSection.getBoundingClientRect().top + window.pageYOffset;
      const offsetPosition = elementPosition - navHeight;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <section
      id="about"
      className="relative w-full pt-0 pb-20 px-0 overflow-x-hidden"
    >
      <style>{floatStyle}</style>

      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/60 via-purple-50/60 to-pink-50/60 z-0"></div>

      <div className="absolute inset-0 pointer-events-none overflow-hidden z-[5]">
        {clouds.flatMap((cloud) => {
          const passes = [
            { keySuffix: "a", delay: 0 },
            { keySuffix: "b", delay: -(cloud.duration / 2) },
          ];

          return passes.map((pass) => (
            <motion.img
              key={`${cloud.id}-${pass.keySuffix}`}
              src={cloudUrl}
              alt=""
              className="absolute select-none"
              style={{
                width: `${cloud.width}px`,
                top: cloud.top,
                left: cloud.left,
                opacity: cloud.opacity,
                filter: `blur(${cloud.width > 230 ? 1.5 : 0}px)`,
              }}
              initial={{ x: 0, y: 0 }}
              animate={{
                x: "220vw",
                y: [0, -18, 0, 12, 0],
              }}
              transition={{
                x: {
                  duration: cloud.duration,
                  repeat: Infinity,
                  ease: "linear",
                  delay: pass.delay,
                },
                y: {
                  duration: cloud.floatDuration,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: pass.delay,
                },
              }}
            />
          ));
        })}
      </div>

      <div className="absolute top-20 right-10 w-72 h-72 bg-yellow-200/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-10 w-96 h-96 bg-blue-200/20 rounded-full blur-3xl"></div>

      <div className="max-w-[1400px] mx-auto relative z-20 px-4 md:px-8 lg:px-12 pt-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <motion.h1
              className="font-[outfit] tracking-tight"
              style={{ fontWeight: 800 }}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-[#6d5593] font-normal whitespace-normal md:whitespace-nowrap text-[24px] md:text-[2vw] lg:text-[1.8vw]">
                {typedText}
              </span>

              <span className="text-5xl md:text-6xl lg:text-7xl text-[#6d5593] block">
                {"LEARNING EXPERIENCES".split("").map((char, index) => (
                  <motion.span
                    className="text-[#6d55931]"
                    key={index}
                    initial={{ opacity: 0, filter: "blur(10px)" }}
                    whileInView={{ opacity: 1, filter: "blur(0px)" }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.06 }}
                  >
                    {char}
                  </motion.span>
                ))}
              </span>
            </motion.h1>

            {/* Mobile-only image under heading */}
            <motion.div
              className="relative flex lg:hidden items-center justify-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <motion.img
                src={womanImageUrl}
                alt="Instructional designer illustration"
                className="w-full max-w-sm object-contain relative z-30"
              />
            </motion.div>

            <motion.p
              className="text-xl md:text-2xl text-[#40464f] leading-relaxed font-[outfit]"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              Transforming complex information into engaging, interactive learning
              experiences that empower learners and drive measurable results.
            </motion.p>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={handleGetInTouch}
                className="bg-[#546DA6] py-4 px-8 rounded-md hover:shadow-xl hover:scale-105 transition-all inline-flex items-center gap-3 text-white font-bold"
              >
                <Mail className="w-6 h-6" />
                LET&apos;S CONNECT
              </button>

              <button
                onClick={() => {
                  const projectsSection = document.getElementById("projects");
                  if (projectsSection) {
                    window.scrollTo({
                      top:
                        projectsSection.getBoundingClientRect().top +
                        window.pageYOffset -
                        80,
                      behavior: "smooth",
                    });
                  }
                }}
                className="bg-white/80 py-4 px-8 rounded-md hover:shadow-lg hover:scale-105 border border-[#6d5593] text-[#6d5593] font-bold"
              >
                VIEW WORK
              </button>
            </div>
          </motion.div>

          {/* Desktop-only image on right */}
          <motion.div
            className="relative hidden lg:flex items-center justify-center"
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <img
              src={womanImageUrl}
              alt="Instructional designer illustration"
              className="w-full max-w-lg object-contain relative z-30 desktop-float"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
}