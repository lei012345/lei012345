export function SkipLink() {
  return (
    <a
      href="#main-content"
      className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-[9999] focus:px-6 focus:py-3 focus:bg-blue-600 focus:text-white focus:rounded-lg focus:shadow-lg focus:font-[outfit] focus:tracking-wider focus:uppercase focus:outline-none focus:ring-4 focus:ring-blue-300"
      style={{ fontWeight: 700 }}
    >
      Skip to main content
    </a>
  );
}
