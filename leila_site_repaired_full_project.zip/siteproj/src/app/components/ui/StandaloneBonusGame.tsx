// StandaloneBonusGame.tsx
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, RefreshCw, ArrowRight, Volume2, VolumeX } from 'lucide-react';

interface Statement {
  text: string;
  correctAnswer: 'Assertive' | 'Passive' | 'Aggressive';
  audioUrl: string;
  type: 'assertive' | 'passive' | 'aggressive';
}

const statements: Statement[] = [
  { text: "I understand the deadline is tight. Let's discuss what's realistic and how we can prioritize.", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-deadline.mp3', type: 'assertive' },
  { text: "Whatever you say. I'll just do my best, I guess...", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-domybest.mp3', type: 'passive' },
  { text: "You always give me impossible deadlines! This is ridiculous!", correctAnswer: 'Aggressive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-ridiculous.mp3', type: 'aggressive' },
  { text: "I can see this is important. Can we look at the timeline together and find a solution?", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-timeline.mp3', type: 'assertive' },
  { text: "Okay... I'll try to make it work somehow.", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-okay.mp3', type: 'passive' },
  { text: "You clearly don't understand how long design work takes!", correctAnswer: 'Aggressive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-designwork.mp3', type: 'aggressive' },
  { text: "I respect your concern. Here's what I can deliver by then, and what would need more time.", correctAnswer: 'Assertive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-respect.mp3', type: 'assertive' },
  { text: "I guess I can cancel my weekend plans again...", correctAnswer: 'Passive', audioUrl: 'https://raw.githubusercontent.com/lei012345/images/main/0-i%20guess.mp4', type: 'passive' },
];

// Shuffle function to randomize array
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

type GameState = 'intro' | 'instructions' | 'playing' | 'result';

interface StandaloneBonusGameProps {
  variant?: 'preview' | 'full';
}

export function StandaloneBonusGame({ variant = 'full' }: StandaloneBonusGameProps) {
  const [gameState, setGameState] = useState<GameState>('intro');
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [currentStatementAudio, setCurrentStatementAudio] = useState<HTMLAudioElement | null>(null);
  const [showQuickReference, setShowQuickReference] = useState(false);
  const [shuffledStatements, setShuffledStatements] = useState<Statement[]>(statements);
  
  // Preload click sound once on mount for better performance
  const [clickSound] = useState(() => {
    const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/button2.mp3');
    audio.preload = 'auto';
    audio.load();
    return audio;
  });

  // Play success sound when game ends
  useEffect(() => {
    if (gameState === 'result' && !isMuted) {
      const audio = new Audio('https://raw.githubusercontent.com/lei012345/images/main/success.mp3');
      audio.play().catch(err => console.error('Success sound failed:', err));
    }
  }, [gameState, isMuted]);

  // Play statement audio when statement changes
  useEffect(() => {
    if (gameState === 'playing' && !isMuted) {
      // Stop any currently playing audio first
      if (currentStatementAudio) {
        currentStatementAudio.pause();
        currentStatementAudio.currentTime = 0;
      }
      
      // For "cancel plans" statement, play immediately without setTimeout
      if (currentIndex === shuffledStatements.length - 1) {
        const audio = new Audio(shuffledStatements[currentIndex].audioUrl);
        console.log('Playing audio:', shuffledStatements[currentIndex].audioUrl);
        audio.volume = 1.0; // Maximum volume allowed by browser
        setCurrentStatementAudio(audio);
        
        // Add event listeners for debugging
        audio.addEventListener('loadeddata', () => console.log('Audio loaded successfully'));
        audio.addEventListener('error', (e) => console.error('Audio error:', e));
        
        audio.play().catch(err => console.error('Statement audio failed:', err));
        
        return () => {
          audio.pause();
          audio.currentTime = 0;
        };
      } else {
        // For other statements, use 500ms delay
        const timer = setTimeout(() => {
          const audio = new Audio(shuffledStatements[currentIndex].audioUrl);
          console.log('Playing audio:', shuffledStatements[currentIndex].audioUrl);
          setCurrentStatementAudio(audio);
          
          // Add event listeners for debugging
          audio.addEventListener('loadeddata', () => console.log('Audio loaded successfully'));
          audio.addEventListener('error', (e) => console.error('Audio error:', e));
          
          audio.play().catch(err => console.error('Statement audio failed:', err));
        }, 500);
        
        return () => {
          clearTimeout(timer);
          if (currentStatementAudio) {
            currentStatementAudio.pause();
            currentStatementAudio.currentTime = 0;
          }
        };
      }
    }
    
    return () => {
      if (currentStatementAudio) {
        currentStatementAudio.pause();
        currentStatementAudio.currentTime = 0;
      }
    };
  }, [currentIndex, gameState, isMuted]);

  const playClickSound = () => {
    if (!isMuted) {
      clickSound.currentTime = 0; // Reset to start for rapid clicks
      clickSound.play().catch(err => console.error('Click sound failed:', err));
    }
  };

  const toggleMute = () => {
    setIsMuted(!isMuted);
    if (currentStatementAudio && !isMuted) {
      currentStatementAudio.pause();
    }
  };

  const handleShowInstructions = () => {
    playClickSound();
    setGameState('instructions');
  };

  const handleStartGame = () => {
    playClickSound();
    setGameState('playing');
    setCurrentIndex(0);
    setScore(0);
    setShuffledStatements(shuffleArray(statements));
  };

  const handleAnswer = (answer: 'Assertive' | 'Passive' | 'Aggressive') => {
    playClickSound();
    
    // Stop current statement audio immediately
    if (currentStatementAudio) {
      currentStatementAudio.pause();
      currentStatementAudio.currentTime = 0;
      setCurrentStatementAudio(null);
    }
    
    const currentStatement = shuffledStatements[currentIndex];
    const isCorrect = answer === currentStatement.correctAnswer;
    
    setFeedback(isCorrect ? 'correct' : 'incorrect');
    
    const newScore = isCorrect ? score + 1 : score;
    if (isCorrect) {
      setScore(newScore);
    }

    setTimeout(() => {
      setFeedback(null);
      if (currentIndex < shuffledStatements.length - 1) {
        setCurrentIndex(currentIndex + 1);
      } else {
        setGameState('result');
      }
    }, 800);
  };

  const handleRestart = () => {
    playClickSound();
    setGameState('playing');
    setCurrentIndex(0);
    setScore(0);
    setFeedback(null);
    setShuffledStatements(shuffleArray(statements));
  };

  const handleBackToIntro = () => {
    playClickSound();
    setGameState('intro');
    setCurrentIndex(0);
    setScore(0);
    setFeedback(null);
  };

  const currentStatement = shuffledStatements[currentIndex];
  const progress = ((currentIndex + 1) / shuffledStatements.length) * 100;

  // Determine sizing based on variant
  const containerSize = variant === 'preview' 
    ? 'w-[700px] h-[420px]' 
    : 'w-[1250px] h-[750px]';
  
  const textSizes = variant === 'preview' 
    ? {
        title: 'text-[20px]',
        subtitle: 'text-[14px]',
        button: 'text-[18px]',
        instructionTitle: 'text-[28px]',
        instructionText: 'text-[18px]',
        statementText: 'text-[18px]',
        questionText: 'text-[22px]',
        answerButton: 'text-[18px]',
        resultTitle: 'text-[22px]',
        resultScore: 'text-[20px]',
        resultText: 'text-[18px]',
        thoughtBubbles: 'w-7 h-7',
        womanImage: 'w-24 h-24',
        arrowIcon: 'w-4 h-4',
      }
    : {
        title: 'text-[36px]',
        subtitle: 'text-[24px]',
        button: 'text-[32px]',
        instructionTitle: 'text-[48px]',
        instructionText: 'text-[32px]',
        statementText: 'text-[32px]',
        questionText: 'text-[40px]',
        answerButton: 'text-[32px]',
        resultTitle: 'text-[40px]',
        resultScore: 'text-[36px]',
        resultText: 'text-[32px]',
        thoughtBubbles: 'w-10 h-10 md:w-14 md:h-14',
        womanImage: 'w-32 h-32 md:w-60 md:h-60',
        arrowIcon: 'w-4 h-4 md:w-8 md:h-8',
      };

  return (
    <div className="w-full flex justify-center items-center px-4">
      <div className="min-h-[500px] md:min-h-[800px] w-full">
        <AnimatePresence mode="wait">
          {/* Intro State */}
          {gameState === 'intro' && (
            <div
              key="intro"
              className="bg-[#f0f4f8] rounded-lg p-6 md:p-16 shadow-lg border border-[#d4dce5] text-center relative overflow-hidden w-full max-w-[1250px] mx-auto min-h-[600px] md:h-[800px] flex items-center justify-center"
            >
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
              
              {/* Mute Button */}
              <div className="absolute top-4 right-4 z-20">
                <motion.button
                  onClick={toggleMute}
                  whileHover={{ scale: 1.3, opacity: 1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-gray-500" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-gray-500" />
                  )}
                </motion.button>
              </div>
              
              <div className="relative z-10">
                
                {/* Thought Bubbles */}
                <div className="flex justify-center items-start gap-2 md:gap-3 mb-2 md:mb-3">
                  <motion.img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/happy1.png"
                    alt="Happy thought"
                    className="w-14 h-14 md:w-20 md:h-20 object-contain"
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/sad1.png"
                    alt="Sad thought"
                    className="w-14 h-14 md:w-20 md:h-20 object-contain"
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.3 }}
                  />
                  <motion.img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/upset1.png"
                    alt="Upset thought"
                    className="w-14 h-14 md:w-20 md:h-20 object-contain"
                    animate={{ y: [0, -10, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 0.6 }}
                  />
                </div>
                
                {/* Woman in Thought */}
                <div className="flex justify-center mb-4 md:mb-4">
                  <img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/G00.png"
                    alt="Woman thinking"
                    className="w-56 md:w-70 h-auto object-contain cursor-pointer hover:opacity-80 transition-opacity"
                    onClick={handleShowInstructions}
                  />
                </div>
                
                <h3 className="font-[outfit] tracking-wider uppercase mb-2 md:mb-3 bg-[#d46b61] bg-clip-text text-transparent text-[28px] md:text-[40px] px-4" style={{ fontWeight: 900 }}>
                  Communication Challenge
                </h3>
                
                <p className="text-gray-600 mb-4 md:mb-6 font-[outfit] tracking-wide max-w-2xl mx-auto px-4 text-[20px]">
                  Can you identify <b>assertive, passive,</b> and <b>aggressive</b> communication styles?
                </p>
                
                <motion.button
                  onClick={handleShowInstructions}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 md:px-8 py-3 md:py-4 bg-[#546DA6] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#8a88b5] transition-all inline-flex items-center gap-2 text-[24px] md:text-[32px]"
                  style={{ fontWeight: 700 }}
                >
                  START
                  <ArrowRight className="w-5 h-5 md:w-8 md:h-8" />
                </motion.button>
              </div>
            </div>
          )}

          {/* Instructions State */}
          {gameState === 'instructions' && (
            <div
              key="instructions"
              className="bg-[#f0f4f8] rounded-lg p-12 md:p-16 shadow-lg border border-[#d4dce5] text-center relative overflow-hidden w-full max-w-[1250px] mx-auto h-[500px] md:h-[800px] flex items-center"
            >
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
              
              {/* Mute Button */}
              <div className="absolute top-4 right-4 z-20">
                <motion.button
                  onClick={toggleMute}
                  whileHover={{ scale: 1.1, opacity: 1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-gray-500" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-gray-500" />
                  )}
                </motion.button>
              </div>
              
              <div className="relative z-10 w-full">
                <h3 className="font-[outfit] tracking-wider uppercase mb-4 md:mb-8 text-gray-900 text-[36px]" style={{ fontWeight: 900 }}>
                  How to Play
                </h3>
                
                <div className="text-left space-y-1 md:space-y-4 mb-3 md:mb-8 bg-white/60 p-2 md:p-8 rounded-lg max-w-6xl mx-auto">
                  <ul className="list-disc list-outside pl-4 md:pl-6 space-y-1 md:space-y-3 text-gray-700 font-[outfit]">
                    <li className="pl-1 text-[14px] md:text-[24px]">Read workplace statements one by one</li>
                    <li className="text-[14px] md:text-[24px] pl-1">Identify if each is <strong>Assertive</strong>, <strong>Passive</strong>, or <strong>Aggressive</strong></li>
                    <li className="text-[14px] md:text-[24px] pl-1">Complete all {statements.length} statements to see your score</li>
                    <li className="list-none -ml-4 md:-ml-6 text-[14px] md:text-[24px] pl-5" style={{ textIndent: '-1.25rem' }}>💡 <strong>Tip:</strong> Having audio on improves the experience (spoken dialogue)</li>
                  </ul>
                </div>
                
                <motion.button
                  onClick={handleStartGame}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 md:px-8 py-3 md:py-4 bg-[#D46B61] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#ed8980] transition-all inline-flex items-center gap-2 text-[24px]"
                  style={{ fontWeight: 700 }}
                >
                 BEGIN
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5" />
                </motion.button>
              </div>
            </div>
          )}

          {/* Playing State */}
          {gameState === 'playing' && (
            <div
              key="playing"
              className="bg-[#f0f4f8] rounded-lg p-8 md:p-16 shadow-lg border border-[#d4dce5] flex flex-col relative overflow-hidden w-full max-w-[1250px] mx-auto min-h-[600px] md:h-[900px]"
            >
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#ffd4a3]/30 rounded-full blur-3xl"></div>
              <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#c5dce8]/30 rounded-full blur-3xl"></div>
              
              {/* Mute Button */}
              <div className="absolute top-4 right-4 z-20">
                <motion.button
                  onClick={toggleMute}
                  whileHover={{ scale: 1.1, opacity: 1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-gray-500" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-gray-500" />
                  )}
                </motion.button>
              </div>
              
              <div className="relative z-10 flex-1 flex flex-col">
                {/* Header */}
                <div className="flex flex-col md:flex-row md:justify-between md:items-center mb-6 md:mb-10 gap-3 md:gap-4">
                  <div className="flex-1">
                    <h3 className="font-[outfit] tracking-wider text-gray-900 mb-2 md:mb-3 text-base md:text-2xl" style={{ fontWeight: 700 }}>
                      Statement {currentIndex + 1} of {statements.length}
                    </h3>
                    <div className="w-full bg-white/50 rounded-full shadow-inner h-2 md:h-3">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${progress}%` }}
                        className="rounded-full bg-gradient-to-r from-[#d46b61] to-[#c36538] transition-all duration-300 shadow-sm h-2 md:h-3"
                      ></motion.div>
                    </div>
                  </div>
                  
                  <div className="text-center md:text-right md:ml-8">
                    <div className="inline-block bg-white/70 rounded-lg shadow-sm px-4 md:px-6 py-2 md:py-3">
                      <div className="text-gray-600 font-[outfit] tracking-wide mb-1 text-xs md:text-sm" style={{ fontWeight: 500 }}>SCORE</div>
                      <div className="font-[outfit] tracking-wider text-[#7b9eb5] text-2xl md:text-3xl" style={{ fontWeight: 900 }}>
                        {score}/{statements.length}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Statement */}
                <div className="flex-1 flex items-center justify-center mb-6 md:mb-10">
                  <div className="rounded-xl bg-white shadow-lg border-2 border-[#d4dce5] w-full max-w-3xl flex flex-col items-center p-6 md:p-8 gap-4 md:gap-6">
                    <img 
                      src={
                        currentStatement.type === 'assertive' 
                          ? 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g001.png'
                          : currentStatement.type === 'aggressive'
                          ? 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g002.png'
                          : 'https://raw.githubusercontent.com/lei012345/images/refs/heads/main/g003.png'
                      }
                      alt={currentStatement.type}
                      className="flex-shrink-0 object-contain rounded-full p-2 w-20 h-20 md:w-35 md:h-35"
                      style={{
                        backgroundColor: currentStatement.type === 'assertive' 
                          ? '#e9eef2'
                          : currentStatement.type === 'aggressive'
                          ? '#e9eef2'
                          : '#e9eef2'
                      }}
                    />
                    <p className="text-center leading-relaxed text-gray-800 font-[outfit] tracking-wide flex-1 text-[24px]" style={{ fontWeight: 500 }}>
                      "{currentStatement.text}"
                    </p>
                  </div>
                </div>

                {/* Question */}
                <div className="text-center mb-6 md:mb-8 mt-2 md:-mt-24">
                  <p className="font-[outfit] tracking-wide text-gray-700 px-4 mx-[0px] mt-[-7px] mb-[0px] text-[32px]" style={{ fontWeight: 600 }}>
                    What type of communication is this?
                  </p>
                </div>

                {/* Answer Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 md:gap-6">
                  <motion.button
                    onClick={() => handleAnswer('Assertive')}
                    disabled={feedback !== null}
                    whileTap={feedback === null ? { scale: 0.98 } : {}}
                    className={`rounded-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg py-3 md:py-5 px-6 md:px-8 whitespace-nowrap ${ feedback === 'correct' && currentStatement.correctAnswer === 'Assertive' ? 'ring-4 ring-green-400 bg-[#7b9eb5] text-white shadow-lg' : feedback === 'incorrect' && currentStatement.correctAnswer === 'Assertive' ? 'ring-4 ring-red-400 bg-[#7b9eb5] text-white shadow-lg' : 'bg-[#7b9eb5] text-white hover:bg-[#6a8ea4]' } text-[20px]`}
                    style={{ fontWeight: 700 }}
                  >
                    Assertive
                  </motion.button>

                  <motion.button
                    onClick={() => handleAnswer('Passive')}
                    disabled={feedback !== null}
                    whileTap={feedback === null ? { scale: 0.98 } : {}}
                    className={`rounded-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg py-3 md:py-5 px-6 md:px-8 whitespace-nowrap ${ feedback === 'correct' && currentStatement.correctAnswer === 'Passive' ? 'ring-4 ring-green-400 bg-[#e8b89e] text-gray-800 shadow-lg' : feedback === 'incorrect' && currentStatement.correctAnswer === 'Passive' ? 'ring-4 ring-red-400 bg-[#e8b89e] text-gray-800 shadow-lg' : 'bg-[#e8b89e] text-gray-800 hover:bg-[#daa68a]' } text-[20px]`}
                    style={{ fontWeight: 700 }}
                  >
                    Passive
                  </motion.button>

                  <motion.button
                    onClick={() => handleAnswer('Aggressive')}
                    disabled={feedback !== null}
                    whileTap={feedback === null ? { scale: 0.98 } : {}}
                    className={`rounded-lg font-[outfit] tracking-wider transition-all shadow-md hover:shadow-lg py-3 md:py-5 px-6 md:px-8 whitespace-nowrap ${ feedback === 'correct' && currentStatement.correctAnswer === 'Aggressive' ? 'ring-4 ring-green-400 bg-[#d46b61] text-white shadow-lg' : feedback === 'incorrect' && currentStatement.correctAnswer === 'Aggressive' ? 'ring-4 ring-red-400 bg-[#d46b61] text-white shadow-lg' : 'bg-[#d46b61] text-white hover:bg-[#c2594f]' } text-[20px]`}
                    style={{ fontWeight: 700 }}
                  >Aggressive</motion.button>
                </div>
              </div>
            </div>
          )}

          {/* Result State */}
          {gameState === 'result' && (
            <div
              key="result"
              className="bg-[#f5f9fc] rounded-lg p-8 md:p-16 shadow-lg border border-[#d4e3ed] text-center relative overflow-hidden w-full max-w-[1250px] mx-auto min-h-[600px] md:h-[900px] flex items-center"
            >
              {/* Mute Button */}
              <div className="absolute top-4 right-4 z-20">
                <motion.button
                  onClick={toggleMute}
                  whileHover={{ scale: 1.1, opacity: 1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 bg-white/30 hover:bg-white/50 rounded-full transition-all opacity-40 hover:opacity-100"
                  aria-label={isMuted ? 'Unmute' : 'Mute'}
                >
                  {isMuted ? (
                    <VolumeX className="w-4 h-4 text-gray-500" />
                  ) : (
                    <Volume2 className="w-4 h-4 text-gray-500" />
                  )}
                </motion.button>
              </div>
              
              <div className="relative z-10 w-full">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ duration: 0.5, delay: 0.2 }}
                  className="inline-block relative mb-4 md:mb-6"
                >
                  {/* Main image - girl with thumbs up */}
                  <img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/girl-thumbs.png" 
                    alt="Success"
                    className="w-48 md:w-60 h-auto mx-auto"
                  />
                  {/* Floating image above */}
                  <motion.img 
                    src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/happy1.png"
                    alt="Happy"
                    className="absolute top-0 left-1/2 -translate-x-[110%] w-12 md:w-16 h-auto"
                    animate={{ 
                      y: [-20, -30, -20],
                      rotate: [0, 5, -5, 0]
                    }}
                    transition={{ 
                      duration: 2,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                  />
                </motion.div>

                <h3 className="font-[outfit] tracking-wider uppercase mb-3 md:mb-4 text-gray-900 text-[24px] md:text-[40px] px-2" style={{ fontWeight: 900 }}>
                  Challenge Complete! 🎉
                </h3>
                
                <p className="mb-3 md:mb-4 font-[outfit] tracking-wider text-[#4288b5] text-[20px] md:text-[36px]" style={{ fontWeight: 900 }}>
                  Score: {score}/{statements.length} ({Math.round((score / statements.length) * 100)}%)</p>
                
                <p className="text-gray-700 mt-4 md:mt-6 mb-5 md:mb-8 font-[outfit] tracking-wide max-w-2xl mx-auto px-4 text-[24px]">
                  {score === statements.length ? 'Perfect! You have an excellent understanding of communication styles!' :
                   score >= statements.length * 0.75 ? 'Great job! You have a strong grasp of communication styles.' :
                   score >= statements.length * 0.5 ? 'Good effort! Keep practicing to improve your recognition skills.' :
                   'Keep learning! Review the differences between each style and try again.'}
                </p>

                {/* Quick Reference Toggle Button */}
                <motion.button
                  onClick={() => {
                    playClickSound();
                    setShowQuickReference(!showQuickReference);
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="mb-5 md:mb-6 px-4 md:px-8 py-2 md:py-4 bg-white/70 hover:bg-white/90 rounded-lg font-[outfit] tracking-wider text-gray-800 shadow-md hover:shadow-lg transition-all inline-flex items-center gap-2 border border-[#d4dce5] text-[16px] md:text-[24px]"
                  style={{ fontWeight: 600 }}
                >
                  📖 View Quick Reference
                </motion.button>

                <div className="flex flex-wrap justify-center gap-2 md:gap-3">
                  <motion.button
                    onClick={handleRestart}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 md:px-8 py-2 md:py-4 bg-[#d46b61] text-white rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl hover:bg-[#c2594f] transition-all inline-flex items-center gap-2 text-[16px] md:text-[24px]"
                    style={{ fontWeight: 700 }}
                  >
                    <RefreshCw className="w-4 h-4 md:w-5 md:h-5" />
                    Play Again
                  </motion.button>
                  
                  <motion.button
                    onClick={handleBackToIntro}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-4 md:px-8 py-2 md:py-4 bg-white border-2 border-[#6D5593] text-[#6D5593] rounded-md font-[outfit] tracking-wider shadow-lg hover:shadow-xl transition-all inline-flex items-center gap-2 text-[16px] md:text-[24px]"
                    style={{ fontWeight: 700 }}
                  >
                    Back to Start
                  </motion.button>
                </div>
              </div>
            </div>
          )}
        </AnimatePresence>

        {/* Quick Reference Popup Overlay */}
        <AnimatePresence>
          {showQuickReference && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4"
              onClick={() => {
                playClickSound();
                setShowQuickReference(false);
              }}
            >
              {/* Backdrop */}
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm"></div>
              
              {/* Modal Content */}
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="relative bg-white rounded-lg p-8 max-w-3xl w-full shadow-2xl max-h-[90vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  onClick={() => {
                    playClickSound();
                    setShowQuickReference(false);
                  }}
                  className="absolute top-4 right-4 w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                  aria-label="Close"
                >
                  ✕
                </button>

                <h4 className="text-2xl font-[outfit] tracking-wider mb-6 text-gray-900 text-center" style={{ fontWeight: 700 }}>
                  Communication Styles Reference
                </h4>
                <div className="grid gap-6">
                  <div className="bg-[#e8f4f8] p-6 rounded-lg">
                    <p className="font-[outfit] tracking-wide text-[#487698] text-lg mb-3" style={{ fontWeight: 700 }}>
                      ✓ Assertive Communication
                    </p>
                    <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                      Clear, respectful, and solution-focused. Expresses needs and boundaries while respecting others. Promotes collaboration and mutual understanding.
                    </p>
                  </div>
                  <div className="bg-[#f5ede8] p-6 rounded-lg">
                    <p className="font-[outfit] tracking-wide text-[#8E7F7A] text-lg mb-3" style={{ fontWeight: 700 }}>
                      ✓ Passive Communication
                    </p>
                    <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                      Indirect, avoidant, and self-sacrificing. Struggles to express needs or set boundaries. Often leads to resentment and miscommunication.
                    </p>
                  </div>
                  <div className="bg-[#f9e8e0] p-6 rounded-lg">
                    <p className="font-[outfit] tracking-wide text-[#d97242] text-lg mb-3" style={{ fontWeight: 700 }}>
                      ✓ Aggressive Communication
                    </p>
                    <p className="text-base text-gray-700 font-[outfit] leading-relaxed">
                      Blaming, hostile, and confrontational. Prioritizes own needs at the expense of others. Creates defensiveness and damages relationships.
                    </p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}