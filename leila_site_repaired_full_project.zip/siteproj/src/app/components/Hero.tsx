import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { Mail, Pencil, MousePointer, Monitor, ChevronDown } from "lucide-react";
import profileImage from 'figma:asset/c99a0f3e0f541d5b2ac93fbcce84f2959d5c3287.png';
import { useState, useEffect } from "react";

export function Hero() {
  const [isHoveringProfile, setIsHoveringProfile] = useState(false);
  const [iconIndex, setIconIndex] = useState(0);
  const [isHoveringBtn, setIsHoveringBtn] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIconIndex((prev) => (prev + 1) % 3);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const icons = [
    { Icon: Pencil, color: '#f472b6' },
    { Icon: MousePointer, color: '#60a5fa' },
    { Icon: Monitor, color: '#facc15' },
  ];

  return (
    <section className="min-h-screen flex items-end justify-center px-6 py-12 pb-32 md:pb-40 relative overflow-hidden">
      <div className="max-w-5xl mx-auto relative z-10 mb-12 md:mb-16">
        <div className="relative p-10 md:p-14">

          <div className="flex flex-col md:flex-row items-center md:items-start gap-8 md:gap-12">
            {/* Profile Image */}
            <motion.div
              className="relative flex-shrink-0"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
            >
              {isHoveringProfile && (
                <motion.div
                  className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 bg-white border-2 border-pink-400 rounded-2xl px-4 py-2 shadow-lg whitespace-nowrap z-20"
                  initial={{ opacity: 0, y: 10, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.8 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                >
                  <div className="text-sm font-medium text-foreground">Thanks for visiting! :)</div>
                  <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-8 border-l-transparent border-r-8 border-r-transparent border-t-8 border-t-pink-400" />
                  <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px w-0 h-0 border-l-[7px] border-l-transparent border-r-[7px] border-r-transparent border-t-[7px] border-t-white" />
                </motion.div>
              )}
              <img
                src={profileImage}
                alt="Profile"
                loading="eager"
                fetchpriority="high"
                className="w-56 h-56 md:w-64 md:h-64 rounded-full object-cover shadow-lg hover:shadow-xl transition-shadow"
                onMouseEnter={() => setIsHoveringProfile(true)}
                onMouseLeave={() => setIsHoveringProfile(false)}
              />
            </motion.div>

            {/* Content */}
            <div className="flex-1 text-left">
              <motion.div
                className="mb-2"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h1
                  className="bg-black bg-clip-text text-transparent text-[36px] md:text-[48px] text-[#000000]"
                  style={{ fontWeight: 500, lineHeight: 1.2, fontFamily: 'Poppins, sans-serif' }}
                >
                  {portfolioData.name}
                </h1>
              </motion.div>

              <motion.p
                className="text-muted-foreground text-[#7496b5] font-[Fustat] text-[16px] mx-[0px] mt-[-6px] mb-[24px] flex items-center justify-start gap-3"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
              >
                <span className="order-2 md:order-1 relative inline-flex items-center justify-center w-6 h-6 md:w-10 md:h-10">
                  {icons.map(({ Icon, color }, index) => (
                    <motion.span
                      key={index}
                      className="absolute"
                      initial={{ opacity: 0, scale: 0.5 }}
                      animate={{
                        opacity: iconIndex === index ? 1 : 0,
                        scale: iconIndex === index ? 1 : 0.5,
                        rotate: iconIndex === index ? 0 : 180,
                      }}
                      transition={{ duration: 0.5, ease: "easeInOut" }}
                    >
                      <Icon size={24} className="md:w-9 md:h-9" style={{ color }} />
                    </motion.span>
                  ))}
                </span>
                <span className="order-1 md:order-2">WEB & GRAPHIC DESIGNER</span>
              </motion.p>

              <motion.p
                className="text-base max-w-xl text-[#464b50] px-[0px] mx-[0px] mt-[-8px] mb-[37px] text-left"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
              >
                I'm Leila, a web and graphic designer based in the DMV. I create modern, user-focused brand identities, websites, and digital experiences that are clear, thoughtful, and strategic. Beyond design, I enjoy illustration, video editing, and creating short animations.
              </motion.p>

              <motion.div
                className="flex flex-wrap items-center justify-center md:justify-start gap-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
              >
                <motion.button
                  type="button"
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="px-8 py-3 bg-gradient-to-r from-pink-400 to-rose-400 text-white rounded-full inline-flex items-center gap-2 hover:shadow-lg transition-shadow cursor-pointer"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Let's Chat <Mail className="w-4 h-4" />
                </motion.button>

                {/* View Projects button — CSS gradient border */}
                <motion.a
                  href="#projects"
                  onClick={(e) => { e.preventDefault(); document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' }); }}
                  className="px-8 py-3 rounded-full inline-flex items-center gap-2 relative"
                  style={{
                    border: '2px solid transparent',
                    background: isHoveringBtn
                      ? 'linear-gradient(white, white) padding-box, linear-gradient(to right, #f9a8d4, #d8b4fe) border-box'
                      : 'linear-gradient(white, white) padding-box, linear-gradient(to right, #d8b4fe, #d8b4fe) border-box',
                    transition: 'background 0.25s ease',
                  }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onMouseEnter={() => setIsHoveringBtn(true)}
                  onMouseLeave={() => setIsHoveringBtn(false)}
                >
                  View Projects
                </motion.a>
              </motion.div>

              <motion.div
                className="flex justify-center mt-16"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 1 }}
              >
                <motion.button
                  onClick={() => {
                    const projectsSection = document.getElementById('projects');
                    projectsSection?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex flex-col items-center gap-2 text-muted-foreground hover:text-foreground transition-colors cursor-pointer bg-transparent border-none"
                  animate={{ y: [0, 8, 0] }}
                  transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                >
                  <ChevronDown className="w-8 h-8" />
                </motion.button>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
