import { motion, useInView } from "motion/react";
import { useRef, useState } from "react";

export function Projects({ preview = false }: { preview?: boolean }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isExpanded, setIsExpanded] = useState(false);

  // REPLACE THESE WITH YOUR REAL PROJECT DETAILS
  const project = {
    title: "Navigating Difficult Conversations at Work",
    description:
      "This project is my first instructional design build, where I designed and developed an interactive course on navigating difficult workplace conversations using Storyline 360. The experience is grounded in scenario-based learning, allowing learners to make decisions and see how their communication choices impact outcomes such as trust, clarity, and workplace tension. I focused on creating realistic interactions, meaningful feedback, and a learner-centered flow that encourages reflection and behavior change. Through this project, I applied key LXD principles including scenario design,user-focused interaction, feedback loops, and visual storytelling to create a practical, engaging learning experience.",
    tools: [
      "Articulate Storyline 360",
      "Adobe Illustrator",
      "Adobe Photoshop",
      "ElevenLabs",
      "Figma",
    ],
    interactions: [
      "Spoken narration",
      "Knowledge checks",
      "Scenario-based interactions",
      "Custom visual layout",
      "Spoken dialogue",
    ],
    screenshot: "PASTE_YOUR_SCREENSHOT_URL_HERE",
    courseLink:
      "https://navigating-difficult-conversations.netlify.app/story.html",
  };

  return (
    <section
      id="projects"
      ref={ref}
      className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30"
    >
      <div className="max-w-[1400px] mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6 }}
          className="mb-12 text-center"
        >
          <h2
            className="text-4xl md:text-5xl mb-4 text-[#546DA6] uppercase tracking-wider font-[outfit]"
            style={{ fontWeight: 900 }}
          >
            Projects
          </h2>
          <p className="text-[#40464f] font-[outfit] tracking-wider text-lg max-w-3xl mx-auto"></p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="bg-white rounded-[28px] shadow-sm border border-white/70 overflow-hidden"
        >
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_1fr] items-center gap-8 lg:gap-12 p-6 md:p-8 lg:p-10">
            {/* LEFT: SCREENSHOT */}
            <a
              href={preview ? "/projects" : project.courseLink}
              target={preview ? "_self" : "_blank"}
              rel={preview ? undefined : "noopener noreferrer"}
              className="group flex justify-center w-full"
            >
              <div className="w-full max-w-[720px]">
                {/* FRAME */}
                <div className="rounded-xl overflow-hidden shadow-md border border-[#e8e6f0] bg-white">
                  {/* TOP BAR */}
                  <div className="flex items-center gap-2 px-3 py-2 bg-[#f3eff8] border-b border-[#e8e6f0]">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#ff6b6b]" />
                    <div className="w-2.5 h-2.5 rounded-full bg-[#f7c948]" />
                    <div className="w-2.5 h-2.5 rounded-full bg-[#4cd964]" />
                  </div>

                  {/* IMAGE */}
                  <div className="aspect-video bg-white">
                    <img
                      src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/ID-project-cover.png"
                      alt={project.title}
                      className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-[1.02]"
                    />
                  </div>
                </div>
              </div>
            </a>

            {/* RIGHT: TEXT */}
            <div className="flex flex-col justify-center max-w-[520px] mx-auto lg:mx-0">
              {preview ? (
                <>
                  <h3
                    className="text-3xl md:text-4xl mb-6 font-[outfit] leading-tight text-[#3d3d3d]"
                    style={{ fontWeight: 800 }}
                  >
                    {project.title}
                  </h3>

                  <a
                    href="/projects"
                    className="inline-flex items-center gap-2 text-[#6D5593] font-[outfit] text-lg transition-all duration-200 hover:gap-3 group"
                    style={{ fontWeight: 700 }}
                  >
                    View Details
                    <svg
                      className="w-5 h-5 transition-transform duration-200 group-hover:translate-x-1"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M17 8l4 4m0 0l-4 4m4-4H3"
                      />
                    </svg>
                  </a>
                </>
              ) : (
                <>
                  <p
                    className="text-sm uppercase tracking-[0.2em] text-[#6d5593] mb-3 font-[outfit]"
                    style={{ fontWeight: 700 }}
                  >
                    Featured Project
                  </p>

                  <h3
                    className="text-3xl md:text-4xl mb-4 font-[outfit] leading-tight text-[#3d3d3d]"
                    style={{ fontWeight: 800 }}
                  >
                    {project.title}
                  </h3>

                  {/* DESCRIPTION WITH READ MORE */}
                  <div className="mb-6">
                    <div
                      className={`relative overflow-hidden transition-all duration-500 ease-in-out ${
                        isExpanded ? "max-h-[500px]" : "max-h-[140px]"
                      }`}
                    >
                      <p className="text-[#40464f] text-base md:text-lg leading-7 font-[outfit] pr-1">
                        {project.description}
                      </p>

                      {!isExpanded && (
                        <div className="pointer-events-none absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-white via-white/95 to-transparent" />
                      )}
                    </div>

                    <button
  onClick={() => setIsExpanded(!isExpanded)}
  className="mt-3 flex items-center justify-center gap-1 text-[#6D5593] font-[outfit] text-sm group transition-all duration-200 mx-auto"
  style={{ fontWeight: 700 }}
  type="button"
>
  <span className="group-hover:underline">
    {isExpanded ? "Show less" : "Read more"}
  </span>

  <svg
    className={`w-4 h-4 transition-transform duration-300 ${
      isExpanded ? "rotate-180" : "rotate-0 group-hover:translate-y-[1px]"
    }`}
    fill="none"
    stroke="currentColor"
    viewBox="0 0 24 24"
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M19 9l-7 7-7-7"
    />
  </svg>
</button>
                  </div>

                  <div className="space-y-5">
                    <div>
                      <h4
                        className="text-[#546DA6] text-md mb-2 font-[outfit]"
                        style={{ fontWeight: 800 }}
                      >
                        Tools Used
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {project.tools.map((tool) => (
                          <span
                            key={tool}
                            className="px-3 py-1.5 rounded-full bg-[#f3eff8] text-[#4b4860] text-xs font-[outfit]"
                            style={{ fontWeight: 600 }}
                          >
                            {tool}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4
                        className="text-[#546DA6] text-md mb-2 font-[outfit]"
                        style={{ fontWeight: 800 }}
                      >
                        Interactions
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {project.interactions.map((item) => (
                          <span
                            key={item}
                            className="px-3 py-1.5 rounded-full bg-[#eef4ff] text-[#42526b] text-xs font-[outfit]"
                            style={{ fontWeight: 600 }}
                          >
                            {item}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-6">
                    <a
                      href={project.courseLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center px-5 py-2.5 rounded-full bg-[#6d5593] text-white font-[outfit] text-sm tracking-wide transition-transform duration-200 hover:scale-[1.02]"
                      style={{ fontWeight: 700 }}
                    >
                      Open Course
                    </a>
                  </div>
                </>
              )}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}