import { portfolioData } from "../data/portfolio-data";
import { Mail, Linkedin, Github, Phone } from "lucide-react";
import { Link } from "react-router";
import { useEffect, useRef, useState } from "react";

export function Footer() {
  const currentYear = new Date().getFullYear();
  const [isHappy, setIsHappy] = useState(false);
  const [showScrollBubble, setShowScrollBubble] = useState(false);
  const [showThanksBubble, setShowThanksBubble] = useState(false);
  const birdRef = useRef<HTMLDivElement | null>(null);
  const hasShownScrollBubble = useRef(false);
  const thanksTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const scrollBubbleTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const happyTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const node = birdRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasShownScrollBubble.current) {
          hasShownScrollBubble.current = true;
          setShowScrollBubble(true);

          if (scrollBubbleTimeoutRef.current) {
            clearTimeout(scrollBubbleTimeoutRef.current);
          }

          scrollBubbleTimeoutRef.current = setTimeout(() => {
            setShowScrollBubble(false);
          }, 5000);
        }
      },
      {
        threshold: 0.45,
      }
    );

    observer.observe(node);

    return () => {
      observer.disconnect();
      if (scrollBubbleTimeoutRef.current) clearTimeout(scrollBubbleTimeoutRef.current);
      if (thanksTimeoutRef.current) clearTimeout(thanksTimeoutRef.current);
      if (happyTimeoutRef.current) clearTimeout(happyTimeoutRef.current);
    };
  }, []);

  const handleBirdClick = () => {
    setShowScrollBubble(false);
    setShowThanksBubble(false);
    setIsHappy(true);

    if (happyTimeoutRef.current) clearTimeout(happyTimeoutRef.current);
    if (thanksTimeoutRef.current) clearTimeout(thanksTimeoutRef.current);

    happyTimeoutRef.current = setTimeout(() => {
      setIsHappy(false);
      setShowThanksBubble(true);

      thanksTimeoutRef.current = setTimeout(() => {
        setShowThanksBubble(false);
      }, 5000);
    }, 1500); // matches the heart/bird animation timing
  };

  return (
    <footer className="bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30 border-t border-gray-200">
      <div className="max-w-[1400px] mx-auto px-4 md:px-8 lg:px-12 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand Section */}
          <div>
            <div ref={birdRef} className="relative w-12 h-12 mb-2 mx-auto">
              <img
                src={
                  isHappy
                    ? "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/cb-woo.png"
                    : "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/cb-hi.png"
                }
                alt="Bird favicon"
                className={`w-12 h-12 cursor-pointer ${isHappy ? "animate-bounce" : ""}`}
                onClick={handleBirdClick}
              />

              {(showScrollBubble || showThanksBubble) && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-20 pointer-events-none">
                  <div className="relative bg-white text-[#6d5593] font-[outfit] text-xs sm:text-sm px-3 py-2 rounded-xl shadow-md border border-[#e9e1f5] whitespace-nowrap">
                    {showThanksBubble ? "Thanks! I needed that!" : "I could sure use a pet..."}
                    <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-l-[7px] border-l-transparent border-r-[7px] border-r-transparent border-t-[8px] border-t-white" />
                  </div>
                </div>
              )}

              {isHappy && (
                <>
                  {[...Array(6)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute text-2xl pointer-events-none"
                      style={{
                        left: "50%",
                        top: "50%",
                        animation: `flutter-${i} 1.5s ease-out forwards`,
                        animationDelay: `${i * 0.05}s`,
                      }}
                    >
                      ❤️
                    </div>
                  ))}
                </>
              )}
            </div>

            <h3
              className="font-[outfit] tracking-wider uppercase text-[#6d5593] mb-4 mx-auto text-center"
              style={{ fontWeight: 900 }}
            >
              {portfolioData.name}
            </h3>

            <p className="text-gray-600 font-[outfit] text-sm leading-relaxed mb-4 text-center">
              Instructional & Learning Experience Designer specializing in creating engaging, learner-centered educational solutions.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4
              className="font-[outfit] tracking-wider uppercase text-[#6d5593] mb-4 text-center"
              style={{ fontWeight: 700 }}
            >
              Quick Links
            </h4>
            <ul className="grid grid-cols-2 gap-x-0 gap-y-2 w-fit mx-auto">
              <li>
                <Link to="/" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/skills" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Skills
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  About
                </Link>
              </li>
              <li>
                <Link to="/art-customizer" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Art Customizer
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Contact
                </Link>
              </li>
              <li>
                <Link to="/projects" className="text-gray-600 hover:text-[#715c94] transition-colors font-[outfit] text-sm">
                  Projects
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4
              className="font-[outfit] tracking-wider uppercase text-[#6d5593] mb-4 text-center"
              style={{ fontWeight: 700 }}
            >
              Get In Touch
            </h4>
            <ul className="space-y-3">
              <li>
                <a
                  href="mailto:leilalxd@gmail.com"
                  className="text-gray-600 hover:text-[#7876A1] transition-colors font-[outfit] text-sm flex items-center gap-2 justify-center"
                >
                  <Mail className="w-4 h-4" />
                  leilalxd@gmail.com
                </a>
              </li>
              <li></li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-200">
          <p className="text-center text-sm text-gray-600 font-[outfit]">
            © {currentYear} {portfolioData.name}. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
