import { motion } from "motion/react";
import { useEffect, useRef, useState } from "react";

const fadeUp = (delay = 0) => ({
  initial: { opacity: 0, y: 20 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true },
  transition: { duration: 0.8, delay },
});

const floatingImageVariants = {
  animate1: {
    y: [0, -12, 0, 8, 0],
    transition: {
      duration: 5.5,
      repeat: Infinity,
      ease: "easeInOut",
    },
  },
  animate2: {
    y: [0, 10, 0, -14, 0],
    transition: {
      duration: 6.5,
      repeat: Infinity,
      ease: "easeInOut",
      delay: 0.8,
    },
  },
  animate3: {
    y: [0, -8, 0, 12, 0],
    transition: {
      duration: 5.8,
      repeat: Infinity,
      ease: "easeInOut",
      delay: 1.6,
    },
  },
};

export function About() {
  const [activeMobileCard, setActiveMobileCard] = useState<string | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const cardsWrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);

      // clear open mobile card when switching to desktop
      if (!mobile) {
        setActiveMobileCard(null);
      }
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    const handlePointerDown = (event: MouseEvent | TouchEvent) => {
      if (!isMobile || !cardsWrapperRef.current) return;

      const target = event.target as Node;
      if (!cardsWrapperRef.current.contains(target)) {
        setActiveMobileCard(null);
      }
    };

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("touchstart", handlePointerDown);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("touchstart", handlePointerDown);
    };
  }, [isMobile]);

  const toggleMobileCard = (cardId: string) => {
    if (!isMobile) return;
    setActiveMobileCard((prev) => (prev === cardId ? null : cardId));
  };

  return (
    <section id="about" className="relative overflow-hidden px-0 pt-0 pb-20">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50/60 via-purple-50/60 to-pink-50/60" />
      <div className="absolute top-20 right-10 h-72 w-72 rounded-full bg-yellow-200/20 blur-3xl" />
      <div className="absolute bottom-20 left-10 h-96 w-96 rounded-full bg-blue-200/20 blur-3xl" />

      <div className="relative z-10 mx-auto max-w-[1200px] px-6 pt-24">
        <h2
          className="mb-12 text-center font-[outfit] text-4xl tracking-wider text-[#546DA6] uppercase md:text-5xl"
          style={{ fontWeight: 900 }}
        >
          About Me
        </h2>

        <motion.div
          className="mx-auto max-w-6xl"
          {...fadeUp(0.1)}
        >
          <div className="grid items-start gap-10 md:grid-cols-[minmax(280px,380px)_1fr] md:gap-12 lg:grid-cols-[minmax(320px,420px)_1fr]">
            <div className="flex justify-center md:justify-start">
              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/l-profile1.png"
                alt="Profile"
                className="w-full max-w-[320px] rounded-2xl object-contain md:max-w-[380px] lg:max-w-[420px]"
              />
            </div>

            <div className="font-[outfit] text-[1.05rem] leading-8 text-[#40464f] md:pt-2">
              <p className="mb-5">
                Hi, I'm Leila - an aspiring Instructional Designer focused on creating
                engaging, interactive, and effective learning experiences. My background
                combines communication, technology, and design, three areas that shape
                how I approach learning solutions.
              </p>

              <p className="mb-5">
                I earned my Bachelor’s degree in Communication with a focus in Media
                Production from George Mason University, where I developed skills in
                digital media, visual communication, and content creation. My experience
                as a substitute teacher gave me firsthand insight into how people learn,
                engage with information, and respond to different teaching approaches.
                Later, working in a data center troubleshooting and maintaining servers
                strengthened my technical problem-solving skills.
              </p>

              <p className="mb-5">
                Alongside these experiences, I’ve always been drawn to art, web
                development, and design. Discovering instructional design allowed me to
                combine these interests into a field centered on improving how people
                learn.
              </p>

              <p className="mb-0">
                This website reflects the start of my journey. Here, I showcase my work,
                design process, and my first LXD project as I continue developing skills
                in instructional strategy, digital learning design, and learner-centered
                problem solving.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Floating images */}
        <motion.div
          ref={cardsWrapperRef}
          className="mx-auto mt-16 flex flex-wrap items-end justify-center gap-16"
          {...fadeUp(0.2)}
        >
          {/* Graduation */}
          <motion.div
            className="group relative flex flex-col items-center"
            variants={floatingImageVariants}
            animate="animate1"
          >
            {/* Desktop hover text */}
            <div className="pointer-events-none absolute bottom-full left-1/2 mb-0 hidden w-[440px] -translate-x-1/2 translate-y-4 rounded-2xl bg-white p-8 text-lg leading-relaxed tracking-[0.01em] text-[#40464f] opacity-0 shadow-xl transition-all duration-500 md:block group-hover:translate-y-0 group-hover:opacity-100">
              I earned my bachelor’s degree in Communication with a focus in
              Media Production at GMU. This where my interest in design and digital media began
              to take shape.
            </div>

            {/* Mobile click text */}
            <div
              className={`absolute bottom-full left-1/2 mb-2 w-[88vw] max-w-[440px] -translate-x-1/2 rounded-2xl bg-white p-6 text-base leading-relaxed tracking-[0.01em] text-[#40464f] shadow-xl transition-all duration-500 md:hidden ${
                activeMobileCard === "graduation"
                  ? "pointer-events-auto translate-y-0 opacity-100"
                  : "pointer-events-none translate-y-4 opacity-0"
              }`}
            >
              I earned my bachelor’s degree in Communication with a focus in
              Media Production at GMU. This where my interest in design and digital media began
              to take shape.
            </div>

            <div
              onClick={() => toggleMobileCard("graduation")}
              className="relative flex items-center justify-center md:pointer-events-none"
            >
              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bg-college.png"
                alt=""
                aria-hidden="true"
                className={`pointer-events-none absolute z-0 h-[180px] w-auto object-contain transition-all duration-500 md:h-[220px] ${
                  activeMobileCard === "graduation"
                    ? "translate-x-0 translate-y-2 scale-100 opacity-100 md:opacity-0"
                    : "-translate-x-3 translate-y-6 scale-75 opacity-0"
                } md:group-hover:translate-x-0 md:group-hover:translate-y-2 md:group-hover:scale-160 md:group-hover:opacity-100`}
              />

              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/M-Grad.png"
                alt="Graduation"
                className={`relative z-10 h-[360px] w-auto object-contain transition-all duration-500 sm:h-[420px] md:h-[500px] ${
                  activeMobileCard === "graduation" ? "scale-[0.85] md:scale-100" : ""
                } md:group-hover:scale-[0.85]`}
              />
            </div>
          </motion.div>

          {/* Substitute Teaching */}
          <motion.div
            className="group relative flex flex-col items-center"
            variants={floatingImageVariants}
            animate="animate2"
          >
            {/* Desktop hover text */}
            <div className="pointer-events-none absolute bottom-full left-1/2 mb-0 hidden w-[440px] -translate-x-1/2 translate-y-4 rounded-2xl bg-white p-8 text-lg leading-relaxed tracking-[0.01em] text-[#40464f] opacity-0 shadow-xl transition-all duration-500 md:block group-hover:translate-y-0 group-hover:opacity-100">
          Substitute teaching gave me hands-on experience in diverse classrooms, helping me better understand how different learners engage with and process information.
            </div>

            {/* Mobile click text */}
            <div
              className={`absolute bottom-full left-1/2 mb-2 w-[88vw] max-w-[440px] -translate-x-1/2 rounded-2xl bg-white p-6 text-base leading-relaxed tracking-[0.01em] text-[#40464f] shadow-xl transition-all duration-500 md:hidden ${
                activeMobileCard === "teaching"
                  ? "pointer-events-auto translate-y-0 opacity-100"
                  : "pointer-events-none translate-y-4 opacity-0"
              }`}
            >
 Substitute teaching gave me hands-on experience in diverse classrooms, helping me better understand how different learners engage with and process information.
            </div>

            <div
              onClick={() => toggleMobileCard("teaching")}
              className="relative flex items-center justify-center md:pointer-events-none"
            >
              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bg-classroom.png"
                alt=""
                aria-hidden="true"
                className={`pointer-events-none absolute z-0 h-[180px] w-auto object-contain transition-all duration-500 md:h-[220px] ${
                  activeMobileCard === "teaching"
                    ? "translate-x-0 translate-y-2 scale-100 opacity-100 md:opacity-0"
                    : "translate-x-3 translate-y-6 scale-75 opacity-0"
                } md:group-hover:translate-x-0 md:group-hover:translate-y-2 md:group-hover:scale-150 md:group-hover:opacity-100`}
              />

              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/M-Teach.png"
                alt="Substitute teaching"
                className={`relative z-10 h-[360px] w-auto object-contain transition-all duration-500 sm:h-[420px] md:h-[500px] ${
                  activeMobileCard === "teaching" ? "scale-[0.85] md:scale-100" : ""
                } md:group-hover:scale-[0.85]`}
              />
            </div>
          </motion.div>

          {/* Technology */}
          <motion.div
            className="group relative flex flex-col items-center"
            variants={floatingImageVariants}
            animate="animate3"
          >
            {/* Desktop hover text */}
            <div className="pointer-events-none absolute bottom-full left-1/2 mb-0 hidden w-[440px] -translate-x-1/2 translate-y-4 rounded-2xl bg-white p-8 text-lg leading-relaxed tracking-[0.01em] text-[#40464f] opacity-0 shadow-xl transition-all duration-500 md:block group-hover:translate-y-0 group-hover:opacity-100">
              My experience working in a data center introduced me to a wide range
              of technical systems. Troubleshooting servers strengthened my
              analytical thinking and sparked an interest in coding and technology.
            </div>

            {/* Mobile click text */}
            <div
              className={`absolute bottom-full left-1/2 mb-2 w-[88vw] max-w-[440px] -translate-x-1/2 rounded-2xl bg-white p-6 text-base leading-relaxed tracking-[0.01em] text-[#40464f] shadow-xl transition-all duration-500 md:hidden ${
                activeMobileCard === "technology"
                  ? "pointer-events-auto translate-y-0 opacity-100"
                  : "pointer-events-none translate-y-4 opacity-0"
              }`}
            >
              My experience working in a data center introduced me to a wide range
              of technical systems. Troubleshooting servers strengthened my
              analytical thinking and sparked an interest in coding and technology.
            </div>

            <div
              onClick={() => toggleMobileCard("technology")}
              className="relative flex items-center justify-center md:pointer-events-none"
            >
              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/bg-servers.png"
                alt=""
                aria-hidden="true"
                className={`pointer-events-none absolute z-0 h-[180px] w-auto object-contain transition-all duration-500 md:h-[220px] ${
                  activeMobileCard === "technology"
                    ? "translate-x-0 translate-y-2 scale-100 opacity-100 md:opacity-0"
                    : "-translate-x-2 translate-y-6 scale-75 opacity-0"
                } md:group-hover:translate-x-0 md:group-hover:translate-y-2 md:group-hover:scale-150 md:group-hover:opacity-100`}
              />

              <img
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/M-Tech.png"
                alt="Technology"
                className={`relative z-10 h-[360px] w-auto object-contain transition-all duration-500 sm:h-[420px] md:h-[500px] ${
                  activeMobileCard === "technology" ? "scale-[0.85] md:scale-100" : ""
                } md:group-hover:scale-[0.85]`}
              />
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}