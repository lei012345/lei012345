import { useState, useRef, useEffect } from 'react';
import { Copy, Check } from 'lucide-react';

interface ColorPickerProps {
  label: string;
  color: string;
  onChange: (color: string) => void;
  presetColors?: string[];
}

// Helper functions for color conversion
function hexToHsv(hex: string): { h: number; s: number; v: number } {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let h = 0;
  if (delta !== 0) {
    if (max === r) h = ((g - b) / delta) % 6;
    else if (max === g) h = (b - r) / delta + 2;
    else h = (r - g) / delta + 4;
    h = Math.round(h * 60);
    if (h < 0) h += 360;
  }

  const s = max === 0 ? 0 : delta / max;
  const v = max;

  return { h, s, v };
}

function hsvToHex(h: number, s: number, v: number): string {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;

  let r = 0, g = 0, b = 0;
  if (h >= 0 && h < 60) { r = c; g = x; b = 0; }
  else if (h >= 60 && h < 120) { r = x; g = c; b = 0; }
  else if (h >= 120 && h < 180) { r = 0; g = c; b = x; }
  else if (h >= 180 && h < 240) { r = 0; g = x; b = c; }
  else if (h >= 240 && h < 300) { r = x; g = 0; b = c; }
  else if (h >= 300 && h < 360) { r = c; g = 0; b = x; }

  const toHex = (n: number) => {
    const val = Math.round((n + m) * 255);
    return val.toString(16).padStart(2, '0');
  };

  return `#${toHex(r)}${toHex(g)}${toHex(b)}`;
}

export function ColorPicker({ label, color, onChange, presetColors }: ColorPickerProps) {
  const [showPicker, setShowPicker] = useState(false);
  const [hexInput, setHexInput] = useState(color);
  const [copied, setCopied] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);
  const svRef = useRef<HTMLDivElement>(null);
  const hueRef = useRef<HTMLDivElement>(null);

  const hsv = hexToHsv(color);
  const [localH, setLocalH] = useState(hsv.h);
  const [localS, setLocalS] = useState(hsv.s);
  const [localV, setLocalV] = useState(hsv.v);

  useEffect(() => {
    setHexInput(color);
    const hsv = hexToHsv(color);
    setLocalH(hsv.h);
    setLocalS(hsv.s);
    setLocalV(hsv.v);
  }, [color]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setShowPicker(false);
      }
    }

    if (showPicker) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPicker]);

  const handleHexInputChange = (value: string) => {
    setHexInput(value);
    
    // Validate hex color
    if (/^#[0-9A-F]{6}$/i.test(value)) {
      onChange(value);
    }
  };

  const handleHexInputBlur = () => {
    // Reset to current color if invalid
    if (!/^#[0-9A-F]{6}$/i.test(hexInput)) {
      setHexInput(color);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(color);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  const updateColorFromHsv = (h: number, s: number, v: number) => {
    setLocalH(h);
    setLocalS(s);
    setLocalV(v);
    const newHex = hsvToHex(h, s, v);
    onChange(newHex);
    setHexInput(newHex.toUpperCase());
  };

  const handleSvMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!svRef.current) return;
    
    const handleMove = (moveEvent: MouseEvent) => {
      if (!svRef.current) return;
      const rect = svRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(moveEvent.clientX - rect.left, rect.width));
      const y = Math.max(0, Math.min(moveEvent.clientY - rect.top, rect.height));
      const s = x / rect.width;
      const v = 1 - y / rect.height;
      updateColorFromHsv(localH, s, v);
    };

    const handleUp = () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
    };

    handleMove(e.nativeEvent);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleUp);
  };

  const handleHueMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!hueRef.current) return;
    
    const handleMove = (moveEvent: MouseEvent) => {
      if (!hueRef.current) return;
      const rect = hueRef.current.getBoundingClientRect();
      const x = Math.max(0, Math.min(moveEvent.clientX - rect.left, rect.width));
      const h = (x / rect.width) * 360;
      updateColorFromHsv(h, localS, localV);
    };

    const handleUp = () => {
      document.removeEventListener('mousemove', handleMove);
      document.removeEventListener('mouseup', handleUp);
    };

    handleMove(e.nativeEvent);
    document.addEventListener('mousemove', handleMove);
    document.addEventListener('mouseup', handleUp);
  };

  return (
    <div className="relative">
      <div className="flex items-center justify-between gap-4 mb-4">
        <h2 className="text-xl font-bold text-gray-800">{label}</h2>
      </div>

      <div className="flex items-center gap-3">
        {/* Color Preview Button */}
        <button
          type="button"
          onClick={() => setShowPicker(!showPicker)}
          className="w-14 h-14 border border-gray-300 rounded-lg hover:scale-105 transition-transform cursor-pointer"
          style={{backgroundColor: color }}
          aria-label={`Pick ${label} color`}
        />

        {/* Hex Input */}
        <div className="flex-1 flex items-center gap-2 bg-gray-100 rounded-lg px-4 py-3">
          <input
            type="text"
            value={hexInput}
            onChange={(e) => handleHexInputChange(e.target.value.toUpperCase())}
            onBlur={handleHexInputBlur}
            className="flex-1 bg-transparent outline-none font-mono text-sm text-gray-800 uppercase"
            placeholder="#000000"
            maxLength={7}
          />
          
          {/* Copy Button */}
          <button
            type="button"
            onClick={handleCopy}
            className="p-2 hover:bg-gray-200 rounded transition-colors"
            aria-label="Copy hex code"
          >
            {copied ? (
              <Check className="w-4 h-4 text-green-600" />
            ) : (
              <Copy className="w-4 h-4 text-gray-600" />
            )}
          </button>
        </div>
      </div>

      {/* Color Picker Popover */}
      {showPicker && (
        <div ref={pickerRef} className="absolute z-10 mt-2 bg-white rounded-lg shadow-lg p-4 border border-gray-200">
          {/* SV Picker */}
          <div
            ref={svRef}
            onMouseDown={handleSvMouseDown}
            className="relative w-64 h-40 rounded cursor-crosshair mb-3"
            style={{
              background: `linear-gradient(to bottom, transparent, black), linear-gradient(to right, white, hsl(${localH}, 100%, 50%))`,
            }}
          >
            <div
              className="absolute w-4 h-4 border-2 border-white rounded-full shadow-md pointer-events-none"
              style={{
                left: `calc(${localS * 100}% - 8px)`,
                top: `calc(${(1 - localV) * 100}% - 8px)`,
              }}
            />
          </div>

          {/* Hue Slider */}
          <div
            ref={hueRef}
            onMouseDown={handleHueMouseDown}
            className="relative w-64 h-3 rounded cursor-pointer mb-3"
            style={{
              background: 'linear-gradient(to right, #ff0000, #ffff00, #00ff00, #00ffff, #0000ff, #ff00ff, #ff0000)',
            }}
          >
            <div
              className="absolute w-4 h-4 border-2 border-white rounded-full shadow-md pointer-events-none"
              style={{
                left: `calc(${(localH / 360) * 100}% - 8px)`,
                top: '-2px',
              }}
            />
          </div>

          {/* Preset Colors */}
          <div className="grid grid-cols-8 gap-2">
            {(presetColors || ['#FF6B6B', '#4ECDC4', '#45B7D1', '#FFA07A', '#98D8C8', '#F7DC6F', '#BB8FCE', '#85C1E2',
              '#FF69B4', '#FFD93D', '#6BCF7F', '#A29BFE', '#FD79A8', '#FDCB6E', '#74B9FF', '#DDA15E']).map((presetColor) => (
              <button
                key={presetColor}
                type="button"
                onClick={() => {
                  onChange(presetColor);
                  setHexInput(presetColor.toUpperCase());
                }}
                className="w-6 h-6 rounded border border-gray-300 hover:scale-110 transition-transform"
                style={{ backgroundColor: presetColor }}
                aria-label={`Select ${presetColor}`}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}