// 🎨 ============================================
// ✨ YOUR PORTFOLIO CONTENT - EDIT HERE! ✨
// 🎨 ============================================
//
// 📝 HOW TO USE THIS FILE:
// This is the ONLY file you need to edit to update your entire website!
// Simply change the text between the quotes "" to update your content.
// 
// 💡 TIPS:
// - Text between quotes ("") is what shows on your website
// - Don't delete the commas (,) at the end of lines
// - To add more items to a list, copy an existing item and edit it
// - Save the file and refresh your browser to see changes
//
// 🚀 SECTIONS IN THIS FILE:
// 1. Personal Information (name, tagline, bio)
// 2. Social Links (email, GitHub, LinkedIn, etc.)
// 3. Projects (your portfolio work)
// 4. Skills (your expertise)
// 5. About Section (introduction and key points)
//
// ============================================

export const portfolioData = {
  // ============================================
  // 👤 SECTION 1: PERSONAL INFORMATION
  // ============================================
  name: "Leila Alswayan",
  tagline: "Instructional and Learning Experience Designer",
  bio: "",
  
  // 📄 RESUME URL - Link to your resume/CV (Google Drive, Dropbox, or direct PDF link)
  resumeUrl: "https://drive.google.com/file/d/YOUR_RESUME_ID/view",
  
  // ============================================
  // 🔗 SECTION 2: SOCIAL LINKS
  // ============================================
  social: {
    email: "leilalxd@gmail.com",
    github: "",
    linkedin: "",
    twitter: "",
    portfolio: ""
  },

  // ============================================
  // 💼 SECTION 3: PROJECTS
  // ============================================
  // Each project appears as a card on your portfolio.
  // To edit a project: change the text between quotes
  // To add a project: copy an entire project block and edit it
  // 
  // Project fields explained:
  // - id: Keep these numbers unique (1, 2, 3, etc.)
  // - title: Project name (shows on card and detail page)
  // - description: Short summary (shows on card)
  // - tags: Technologies used (shows as small badges)
  // - color: Gradient colors for the card (use existing patterns)
  // - cardImage: Image URL for the project card (paste your image URL here!)
  // - conceptPhotos: Images that cycle on card hover (from the Concept Photos section)
  // - detailedDescription: Full description (shows on detail page)
  // - features: List of key features (each item is a bullet point)
  // - technologies: Full tech stack (shows on detail page)
  // - images: Add image URLs here (shows on detail page)
  // - liveUrl: Link to live project
  // - githubUrl: Link to GitHub repository
  // ============================================
  projects: [
    // {
    //   id: 1,
    //   title: "Veterans Care",
    //   description: "A cheerful app to track your daily moods with beautiful visualizations and insights.",
    //   tags: ["React", "TypeScript", "Chart.js"],
    //   color: "from-blue-400 to-cyan-500",
    //   link: "#",
    //   logo: "https://leiladesigns.com/_assets/v11/4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04.png",
    //   
    //   // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
    //   cardImage: "https://lh3.googleusercontent.com/d/1x8_mT2Qvs-PQdh2UHiI3us4K6jr1k6EU",

    //   // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
    //   conceptPhotos: [
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-groceries.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-helping.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/vc-groceries-box.png",
    //   ],
    //   
    //   // 📄 DETAILED PROJECT CONTENT (appears on individual project pages)
    //   detailedDescription: "Mood Tracker helps you understand your emotional patterns through daily check-ins and beautiful data visualizations. Built with React and TypeScript, it features an intuitive interface and insightful analytics.",
    //   
    //   // ✨ KEY FEATURES (appears as bullet points)
    //   features: [
    //     "Clean, modern design with intuitive and straightforward navigation",
    //     "Contact number prominently displayed in the navigation for quick and easy access",
    //     "About page clearly communicating the organization's mission and core values",
    //     "Services page providing comprehensive insight into all available services",
    //     "Contact page offering multiple contact methods, including emergency support",
    //     "Donate page featuring a convenient and user-friendly donation form",
    //   ],
    //   
    //   // 🛠️ TECHNOLOGIES USED
    //   technologies: ["React", "TypeScript", "Chart.js", "Local Storage", "Tailwind CSS"],
    //   
    //   // 🖼️ PROJECT IMAGES (add your screenshot URLs here)
    //   images: [
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/dd5.png",
    //     "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/Screenshot%20(152).png"
    //   ],
    //   
    //   // 🔗 PROJECT LINKS
    //   liveUrl: "https://veteranscare.figma.site",
    //   githubUrl: "https://github.com/yourusername/mood-tracker"
    // },
    {
      id: 7,
      title: "Kindred Paws",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/36fa19961c80c3544217481b4c6561bc5f35e9d8.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-1.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kindred-pin.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-hat.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [
        "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM"
      ],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project"
    },
    {
      id: 8,
      title: "Fairfax Family Auto",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/244751b83e74424c6540c4510e6ee8609b269532.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/fa-sh.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/ff-2.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/ff-repair.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project"
    },
    {
      id: 9,
      title: "ID-Project-1",
      description: "A new exciting project ready for your content.",
      tags: ["React", "TypeScript", "Tailwind"],
      color: "from-pink-400 to-rose-500",
      link: "#",
      logo: "https://leiladesigns.com/_assets/v11/36fa19961c80c3544217481b4c6561bc5f35e9d8.png",
      
      // 🖼️ PROJECT CARD IMAGE (paste your image URL here!)
      cardImage: "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",

      // 🖼️ CONCEPT PHOTOS — cycle through on card hover (add or remove URLs as needed)
      conceptPhotos: [
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-1.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-adopt.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kindred-pin.png",
        "https://raw.githubusercontent.com/lei012345/images/refs/heads/main/kp-hat.png",
      ],
      
      detailedDescription: "This is a new project placeholder. Edit this content to describe your project in detail.",
      features: [
        "Feature one - edit this in portfolio-data.ts",
        "Feature two - add your own features",
        "Feature three - customize everything",
        "Feature four - make it yours",
        "Feature five - add more as needed"
      ],
      technologies: ["React", "TypeScript", "Tailwind CSS"],
      images: [
        "https://lh3.googleusercontent.com/d/1RV0QFYJy5C_MnOwDZ3kBbyWF_xnTcIxM"
      ],
      liveUrl: "https://your-project-url.com",
      githubUrl: "https://github.com/yourusername/new-project"
    }
  ],

  // ============================================
  // 🛠️ SECTION 4: SKILLS
  // ============================================
  // Change skill names and categories
  // To add a skill: add it to the appropriate category array
  // To add a category: copy an entire category block and edit it
  // ============================================
  skillCategories: [
    {
      category: "Design Tools",
      icon: "🎨",
      skills: ["Figma", "Procreate", "Adobe Photoshop", "Adobe Illustrator", "Adobe InDesign", "Canva"]
    },
    {
      category: "Web Development",
      icon: "💻",
      skills: ["HTML", "CSS", "JavaScript", "React", "TypeScript", "Tailwind CSS"]
    },
    {
      category: "Video & Motion",
      icon: "🎬",
      skills: ["Adobe Premiere Pro", "Adobe After Effects", "DaVinci Resolve", "CapCut", "ToonSquid"]
    },
    {
      category: "Other Tools",
      icon: "🛠️",
      skills: ["Git/GitHub", "Framer", "Webflow", "WordPress", "Microsoft 365", "Google Workspace"]
    }
  ],

  // ============================================
  // 🎯 SECTION 5: ABOUT SECTION
  // ============================================
  // Change your introduction and key points
  // ============================================
  about: {
    intro: "Hey there! 👋 I'm a developer who believes that code should be as delightful as the experiences it creates.",
    points: [
      "🎨 5+ years designing and building web applications",
      "💡 Passionate about accessibility and inclusive design",
      "🚀 Always learning and exploring new technologies",
      "🌟 Coffee enthusiast and weekend adventurer"
    ]
  }
};