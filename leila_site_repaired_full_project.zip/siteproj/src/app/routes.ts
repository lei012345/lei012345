import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { GamePage } from "./pages/GamePage";
import { ProcessPage } from "./pages/ProcessPage";
import { ProjectsPage } from "./pages/ProjectsPage";
import { SkillsPage } from "./pages/SkillsPage";
import { PasswordGate } from "./pages/PasswordGate";
import { HiddenStoryboardEmbed } from "./pages/HiddenStoryboardEmbed";
import ColorCustomizerDemo from "./pages/ColorCustomizerDemo";
import ArtCustomizer from "./pages/ArtCustomizer";
import BirdAnimationDemo from "./pages/BirdAnimationDemo";
import { StorylinePage } from "./pages/StorylinePage";
import { NotFound } from "./pages/NotFound";
import TestSvg from "./pages/TestSvg";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/password",
    Component: PasswordGate,
  },
  {
    path: "/about",
    Component: AboutPage,
  },
  {
    path: "/contact",
    Component: ContactPage,
  },
  {
    path: "/game",
    Component: GamePage,
  },
  {
    path: "/process",
    Component: ProcessPage,
  },
  {
    path: "/projects",
    Component: ProjectsPage,
  },
  {
    path: "/skills",
    Component: SkillsPage,
  },
  {
    path: "/color-customizer",
    Component: ColorCustomizerDemo,
  },
  {
    path: "/art-customizer",
    Component: ArtCustomizer,
  },
  {
    path: "/bird-animation",
    Component: BirdAnimationDemo,
  },
  {
    path: "/sb-embed-4f8a9c",
    Component: HiddenStoryboardEmbed,
  },
  {
    path: "/storyline",
    Component: StorylinePage,
  },
  {
    path: "/test-svg",
    Component: TestSvg,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);