import { ProtectedRoute } from "../components/ProtectedRoute";
import { GamePage } from "./GamePage";

export function ProtectedGame() {
  return (
    <ProtectedRoute>
      <GamePage />
    </ProtectedRoute>
  );
}
