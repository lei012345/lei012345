import { Navigation } from "../components/Navigation";
import { Skills } from "../components/Skills";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";

export function SkillsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        <Skills />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}