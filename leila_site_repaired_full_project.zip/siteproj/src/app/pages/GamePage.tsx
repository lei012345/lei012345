import { Navigation } from "../components/Navigation";
import { LearningExperienceGame } from "../components/LearningExperienceGame";
import { StandaloneBonusGame } from "../components/ui/StandaloneBonusGame";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";
import { motion } from "motion/react";
import pointerHand from "figma:asset/971f514c24b6bc492cd618ec01a3f2084d09cbfa.png";

export function GamePage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        {/* Interactive Game Section */}
        <section className="py-16 px-4 md:px-8 lg:px-12">
          <div className="max-w-[1400px] mx-auto text-center mb-8">
            {/* E-learning Image */}
            <motion.div 
              className="flex justify-center mb-6 relative"
              animate={{ y: [0, -10, 0] }}
              transition={{ 
                duration: 2.5, 
                repeat: Infinity, 
                ease: "easeInOut" 
              }}
            >
              {/* Floating background images */}
            
              <motion.img 
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/5989084.png"
                alt=""
                className="absolute top-[3%] left-[45%] w-20 md:w-30 opacity-30 pointer-events-none"
                animate={{ y: [0, -10, 0], rotate: [0, 3, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              />
              
              <img 
                src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/e-learning3.png"
                alt="E-learning"
                className="h-72 md:h-96 object-contain relative z-10"
              />
            </motion.div>
            
            <h2 className="text-4xl md:text-5xl font-[outfit] tracking-wider uppercase mb-4 inline-flex items-center justify-center gap-3 text-[#7876a1]" style={{ fontWeight: 900 }}>
              Try It Yourself
              
            </h2>
            <p className="text-[#40464f] font-[outfit] tracking-wider text-[24px]">
              Get a glimpse into my e-learning design style by completing these short interactive activities.
            </p>
          </div>
          <div className="space-y-32 max-w-[1600px] mx-auto">
            <LearningExperienceGame />
            <StandaloneBonusGame />
          </div>
        </section>
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}