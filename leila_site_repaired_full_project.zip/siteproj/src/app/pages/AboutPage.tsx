import { Navigation } from "../components/Navigation";
import { About } from "../components/About";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";

export function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        <About />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
