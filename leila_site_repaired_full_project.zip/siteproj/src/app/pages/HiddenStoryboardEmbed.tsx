import { useEffect, useRef } from 'react';

export function HiddenStoryboardEmbed() {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (!iframeRef.current) return;

    const iframeDoc = iframeRef.current.contentDocument;
    if (!iframeDoc) return;

    // Write the HTML content directly into the iframe
    iframeDoc.open();
    iframeDoc.write(`
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>Emma Scenario</title>
          <style>
            body, html {
              margin: 0;
              padding: 0;
              width: 100%;
              height: 100%;
              overflow: hidden;
            }
          </style>
          <link rel="stylesheet" href="/sb-assets/index.css">
        </head>
        <body>
          <div id="root"></div>
          <script type="module" src="/sb-assets/index.js"></script>
        </body>
      </html>
    `);
    iframeDoc.close();
  }, []);

  return (
    <iframe 
      ref={iframeRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        border: 'none',
        margin: 0,
        padding: 0
      }}
      title="Storyboard Embed"
    />
  );
}

export default HiddenStoryboardEmbed;