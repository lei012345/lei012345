import { Navigation } from "../components/Navigation";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";

export default function BirdAnimationDemo() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <ScrollToTop />
      <Navigation />
      <main className="mx-auto max-w-5xl px-6 py-20">
        <h1 className="text-4xl font-semibold tracking-tight">Bird Animation Demo</h1>
        <p className="mt-4 max-w-2xl text-lg text-gray-600">
          This page is temporarily being rebuilt.
        </p>
      </main>
      <Footer />
    </div>
  );
}
