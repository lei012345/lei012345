import { Outlet, useLocation } from "react-router";
import { AnimatePresence } from "motion/react";
import { useEffect } from "react";
import { ProjectLoadingAnimation } from "../components/ProjectLoadingAnimation";
import { LoadingProvider, useLoading } from "../context/LoadingContext";

function RootLayoutContent() {
  const location = useLocation();
  const { isLoading, hideLoading } = useLoading();

  // Hide loader when location changes (page has loaded)
  useEffect(() => {
    if (isLoading) {
      hideLoading();
    }
  }, [location.pathname]);

  return (
    <>
      <AnimatePresence mode="wait" initial={false}>
        {isLoading && <ProjectLoadingAnimation key="loader" />}
      </AnimatePresence>
      
      <AnimatePresence mode="wait" initial={false}>
        <Outlet key={location.pathname} />
      </AnimatePresence>
    </>
  );
}

export function RootLayout() {
  return (
    <LoadingProvider>
      <RootLayoutContent />
    </LoadingProvider>
  );
}