import { Navigation } from "../components/Navigation";
import { AboutAnimated } from "../components/AboutAnimated";
import { Projects } from "../components/Projects";
import { DesignProcess } from "../components/DesignProcess";
import { StandaloneBonusGame } from "../components/ui/StandaloneBonusGame";
import { Contact } from "../components/Contact";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";
import { FlyingBird } from "../components/FlyingBird";
import { motion } from "motion/react";
import pointerHand from "figma:asset/971f514c24b6bc492cd618ec01a3f2084d09cbfa.png";
import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { useEffect } from "react";

export function Home() {
  useEffect(() => {
    // Load animated icons script
    const script = document.createElement('script');
    script.src = 'https://animatedicons.co/scripts/embed-animated-icons.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-white relative">
      <Navigation />
      
      {/* Flying Bird Animation */}
      <FlyingBird
        startX={-10}
        endX={70}
        yPosition={30}
        flyDuration={5}
        size={100}
        loop={true}
      />
      
      {/* Add padding top to account for fixed navigation */}
      <main className="pt-0">
        <AboutAnimated />
        
        {/* Design Process Section */}
        <section id="process" className="py-16 px-4 md:px-8 lg:px-12 bg-gradient-to-br from-purple-50/30 via-pink-50/30 to-blue-50/30">
          <div className="max-w-[1400px] mx-auto">
            <div className="mb-12 text-center">
              <h2 className="text-4xl md:text-5xl mb-4 font-[outfit] tracking-wider uppercase text-[#546DA6]" style={{ fontWeight: 900 }}>
                My Design Process
              </h2>
              <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
                A systematic approach to creating meaningful design solutions
              </p>
            </div>
            <DesignProcess />
          </div>
        </section>
        
        {/* Interactive Game Section */}
        <section id="game" className="py-16 px-4 md:px-8 lg:px-12">
          <div className="max-w-[1400px] mx-auto">
            {/* Mobile: Title at top */}
            <div className="lg:hidden text-center mb-8 space-y-6">
              <h2 className="text-4xl md:text-5xl text-[#546DA6] font-[outfit] tracking-wider uppercase relative inline-block" style={{ fontWeight: 900 }}>
                
                Try It Yourself
              </h2>
              <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
               Get a glimpse into my interactive instruction style by completing this challenge!
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              {/* Left Column - Communication Challenge Game */}
              <div>
                <StandaloneBonusGame variant="preview" />
              </div>
              
              {/* Right Column - Title and Button (Desktop only) */}
              <div className="hidden lg:block space-y-6">
                <h2 className="text-4xl md:text-5xl font-[outfit] tracking-wider uppercase relative inline-block text-[#546DA6]" style={{ fontWeight: 900 }}>
                  
                  Try It Yourself
                </h2>
                <p className="text-[#40464f] font-[outfit] tracking-wider text-lg">
                 Get a glimpse into my interactive instruction style by completing this challenge!
                </p>
                
                {/* More Challenges Link - Desktop */}
                <Link to="/projects" className="flex justify-center">
                  <motion.div
                    whileHover={{ x: 5 }}
                    className="font-[outfit] tracking-wider text-[#6b5b95] cursor-pointer inline-flex items-center gap-3 text-[32px]"
                    style={{ fontWeight: 200 }}
                  >
                    VIEW PROJECTS
                    <ArrowRight className="w-10 h-10 md:w-12 md:h-14" />
                  </motion.div>
                </Link>
              </div>
            </div>

            {/* Mobile: MORE link at bottom */}
            <div className="lg:hidden mt-8">
              <Link to="/projects" className="flex justify-center">
                <motion.div
                  whileHover={{ x: 5 }}
                  className="font-[outfit] tracking-wider text-[#6b5b95] cursor-pointer inline-flex items-center gap-3 text-[32px]"
                  style={{ fontWeight: 200 }}
                >
                  VIEW PROJECTS
                  <ArrowRight className="w-10 h-10 md:w-12 md:h-14" />
                </motion.div>
              </Link>
            </div>
          </div>
        </section>
        
        <Projects preview />
        
        <Contact />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}