import { ProtectedRoute } from "../components/ProtectedRoute";
import { AboutPage } from "./AboutPage";

export function ProtectedAbout() {
  return (
    <ProtectedRoute>
      <AboutPage />
    </ProtectedRoute>
  );
}
