import image_36fa19961c80c3544217481b4c6561bc5f35e9d8 from 'figma:asset/36fa19961c80c3544217481b4c6561bc5f35e9d8.png'
import image_4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04 from 'figma:asset/4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04.png'
import image_dc4e18ba35d0ced21cd143a575da00bab9af844e from 'figma:asset/dc4e18ba35d0ced21cd143a575da00bab9af844e.png'
import image_0cc03541e8cef4f3915a5cedf29f6512201349e7 from 'figma:asset/0cc03541e8cef4f3915a5cedf29f6512201349e7.png'
import { useParams, Link } from "react-router";
import { motion } from "motion/react";
import { portfolioData } from "../data/portfolio-data";
import { ArrowLeft, ExternalLink, Github, Sparkles } from "lucide-react";
import { useEffect } from "react";

export function ProjectDetail() {
  const { id } = useParams();
  const project = portfolioData.projects.find((p) => p.id === Number(id));

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!project) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <div className="text-center">
          <h1 className="text-4xl mb-4" style={{ fontWeight: 700 }}>
            Project Not Found
          </h1>
          <Link
            to="/"
            className="text-primary hover:underline inline-flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f0f9ff]">
      {/* Back Button */}
      <motion.div
        className="fixed top-6 left-6 z-50"
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link
          to="/"
          className="flex items-center gap-2 px-4 py-2 bg-white border border-border/50 rounded-full shadow-lg hover:shadow-xl transition-all"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-sm" style={{ fontWeight: 500 }}>
            Back
          </span>
        </Link>
      </motion.div>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-6 relative overflow-hidden">
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
            {/* Left Column - Project Info */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="space-y-8"
            >
              {/* Main Info Container */}
              <div>
                {/* Project icon */}
                <div className={`w-full max-w-2xl rounded-2xl overflow-hidden mb-6 relative`}>
                  <img 
                    src={image_4ac4b59c4eceaffde6b661d9dcd52a01d6e12a04} 
                    alt={project.title}
                    className="w-full h-auto"
                  />
                </div>

                <p className="text-xl text-muted-foreground mb-8 max-w-3xl">
                  Kindred Paws is a conceptual pet adoption website designed with a simple, straightforward user experience. Visitors can easily browse adoptable pets, view their bio and unique traits, favorite the ones they're interested in, and submit an adoption application. This project highlights minimal, yet fun, elements and designs that prioritize clarity, usability, and purposeful interaction.
                </p>

                {/* Action buttons */}
                <div className="flex flex-wrap gap-4">
                  <motion.a
                    href={project.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`px-6 py-3 bg-gradient-to-r ${project.color} text-white rounded-full inline-flex items-center gap-2 hover:shadow-lg transition-shadow`}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    View Live Site <ExternalLink className="w-4 h-4" />
                  </motion.a>
                  <motion.a
                    href={project.githubUrl}
                    target="https://kindredpaws.figma.site"
                    rel="noopener noreferrer"
                    className="px-6 py-3 bg-white border-2 border-foreground/10 rounded-full inline-flex items-center gap-2 hover:border-foreground/30 transition-colors"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Github className="w-4 h-4" />
                    GitHub
                  </motion.a>
                </div>
              </div>

              {/* Features Container */}
              <div className="bg-white rounded-2xl p-8 md:p-10 shadow-sm">
                <h2 className="text-3xl mb-8" style={{ fontWeight: 700 }}>
                  Features
                </h2>
                <div className="space-y-4">
                  {project.features.map((feature, index) => (
                    <motion.div
                      key={index}
                      className="flex items-start gap-4 p-5 bg-gray-50 rounded-xl shadow-sm border border-border/50 hover:shadow-md transition-shadow"
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                    >
                      <Sparkles className="w-5 h-5 text-pink-400 flex-shrink-0 mt-0.5" />
                      <p className="text-foreground/80">{feature}</p>
                    </motion.div>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Right Column - Mobile Preview */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="flex justify-center lg:justify-end lg:sticky lg:top-32"
            >
              <div className="relative">
                {/* Phone Frame */}
                <div className="relative bg-black rounded-[2.5rem] p-2.5 shadow-2xl">
                  {/* Notch */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-40 h-7 bg-black rounded-b-3xl z-10"></div>
                  
                  {/* Screen */}
                  <div className="bg-white rounded-[2rem] overflow-hidden w-[440px] h-[800px] relative">
                    <iframe
                      src="https://kindredpaws.figma.site"
                      className="w-full h-full border-0"
                      title="Kindred Paws Mobile Preview"
                      sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                    />
                  </div>
                </div>

                {/* Phone Buttons */}
                <div className="absolute right-0 top-20 w-1 h-10 bg-black rounded-l-lg"></div>
                <div className="absolute right-0 top-32 w-1 h-14 bg-black rounded-l-lg"></div>
                <div className="absolute right-0 top-48 w-1 h-14 bg-black rounded-l-lg"></div>
                <div className="absolute left-0 top-28 w-1 h-7 bg-black rounded-r-lg"></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Back to Projects */}
      <section className="py-12 px-6">
        <div className="max-w-5xl mx-auto text-center">
          <Link
            to="/#projects"
            className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-blue-400 to-cyan-400 text-white rounded-full hover:shadow-lg transition-shadow"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to All Projects
          </Link>
        </div>
      </section>
    </div>
  );
}