import { ProtectedRoute } from "../components/ProtectedRoute";
import { SkillsPage } from "./SkillsPage";

export function ProtectedSkills() {
  return (
    <ProtectedRoute>
      <SkillsPage />
    </ProtectedRoute>
  );
}
