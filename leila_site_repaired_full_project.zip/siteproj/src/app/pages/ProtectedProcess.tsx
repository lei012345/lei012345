import { ProtectedRoute } from "../components/ProtectedRoute";
import { ProcessPage } from "./ProcessPage";

export function ProtectedProcess() {
  return (
    <ProtectedRoute>
      <ProcessPage />
    </ProtectedRoute>
  );
}
