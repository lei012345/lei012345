import { Navigation } from "../components/Navigation";
import { Projects } from "../components/Projects";
import { Footer } from "../components/Footer";
import { ScrollToTop } from "../components/ScrollToTop";

export function ProjectsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main className="pt-20">
        <Projects />
      </main>
      <Footer />
      <ScrollToTop />
    </div>
  );
}
