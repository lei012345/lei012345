import { ProtectedRoute } from "../components/ProtectedRoute";
import { ProjectsPage } from "./ProjectsPage";

export function ProtectedProjects() {
  return (
    <ProtectedRoute>
      <ProjectsPage />
    </ProtectedRoute>
  );
}
