import { ProtectedRoute } from "../components/ProtectedRoute";
import { ContactPage } from "./ContactPage";

export function ProtectedContact() {
  return (
    <ProtectedRoute>
      <ContactPage />
    </ProtectedRoute>
  );
}
