import bird2 from '../../imports/bird2.svg?raw';
import womanLaptop from '../../imports/woman-laptop.svg?raw';
import helpingHands from '../../imports/helpinghand-3.svg?raw';

export default function TestSvg() {
  return (
    <div className="min-h-screen bg-white p-8">
      <h1 className="text-3xl font-bold mb-8">SVG Test Page</h1>
      
      <div className="grid grid-cols-3 gap-8">
        <div>
          <h2 className="font-bold mb-4">Bird (inline SVG)</h2>
          <div dangerouslySetInnerHTML={{ __html: bird2 }} className="w-full border" />
        </div>
        
        <div>
          <h2 className="font-bold mb-4">Woman Laptop (inline SVG)</h2>
          <div dangerouslySetInnerHTML={{ __html: womanLaptop }} className="w-full border" />
        </div>
        
        <div>
          <h2 className="font-bold mb-4">Helping Hands (inline SVG)</h2>
          <div dangerouslySetInnerHTML={{ __html: helpingHands }} className="w-full border" />
        </div>
      </div>
    </div>
  );
}