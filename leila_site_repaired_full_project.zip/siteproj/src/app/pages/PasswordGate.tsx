import { useState } from 'react';
import { motion } from 'motion/react';
import { Lock, Eye, EyeOff } from 'lucide-react';
import { useNavigate } from 'react-router';

export function PasswordGate() {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  // Set your password here
  const CORRECT_PASSWORD = '0';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password === CORRECT_PASSWORD) {
      // Store authentication in sessionStorage
      sessionStorage.setItem('isAuthenticated', 'true');
      navigate('/home');
    } else {
      setError('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-100 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl p-8 md:p-12 max-w-md w-full"
      >
        {/* Lock Icon */}
        <motion.div
          className="flex justify-center mb-6"
          animate={{ 
            rotate: [0, -5, 5, -5, 0],
          }}
          transition={{ 
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <div className="bg-gradient-to-br from-pink-400 to-blue-400 p-4 rounded-full">
            <Lock className="w-12 h-12 text-white" />
          </div>
        </motion.div>

        {/* Title */}
        <h1 className="text-3xl md:text-4xl text-center mb-2 font-[outfit]" style={{ fontWeight: 800 }}>
          Password Protected
        </h1>
        <p className="text-center text-gray-600 mb-8 font-[outfit]">
          Please enter the password to continue
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError('');
              }}
              placeholder="Enter password"
              className="w-full px-4 py-3 pr-12 rounded-xl border-2 border-gray-200 focus:border-pink-400 focus:outline-none transition-colors font-[outfit]"
              autoFocus
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          {error && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-red-500 text-sm text-center font-[outfit]"
            >
              {error}
            </motion.p>
          )}

          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 text-white py-3 rounded-xl font-[outfit] transition-all shadow-lg hover:shadow-xl"
            style={{ fontWeight: 600 }}
          >
            Enter
          </motion.button>
        </form>

        <p className="text-center text-gray-500 text-sm mt-6 font-[outfit]">
          🔐 This portfolio is currently password protected
        </p>
      </motion.div>
    </div>
  );
}
