import { ProtectedRoute } from "../components/ProtectedRoute";
import { Home } from "./Home";

export function ProtectedHome() {
  return (
    <ProtectedRoute>
      <Home />
    </ProtectedRoute>
  );
}
