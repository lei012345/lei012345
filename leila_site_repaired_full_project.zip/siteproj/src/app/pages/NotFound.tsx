import { Link } from 'react-router';
import { motion } from 'motion/react';
import { Home, ArrowLeft } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

export function NotFound() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fef3f8] via-[#f5f9fc] to-[#fff9e6] flex items-center justify-center px-4">
      <div className="max-w-2xl w-full text-center">
        {/* 404 Bird Image */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8 flex justify-center"
        >
          <ImageWithFallback
            src="https://raw.githubusercontent.com/lei012345/images/refs/heads/main/404-birdy.png"
            alt="404 Bird"
            className="w-sm sm-w-md h-auto"
          />
        </motion.div>

        {/* Message */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-[outfit] text-[#7876A1] mb-4 tracking-wider uppercase" style={{ fontWeight: 800 }}>
            Oops! Page Not Found
          </h2>
          <p className="text-lg md:text-xl text-[#40464f] font-[outfit] tracking-wide" style={{ fontWeight: 400 }}>
            The page you're looking for seems to have wandered off. Let's get you back on track!
          </p>
        </motion.div>

        {/* Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Link to="/">
            
          </Link>

          <Link to="javascript:history.back()">
            <motion.button
              className="px-8 py-4 bg-white text-[#7876A1] rounded-full font-[outfit] tracking-wider uppercase flex items-center gap-2 border-2 border-[#7876A1] shadow-md"
              style={{ fontWeight: 700 }}
              whileHover={{ scale: 1.05, backgroundColor: '#f5f9fc' }}
              whileTap={{ scale: 0.95 }}
              onClick={(e) => {
                e.preventDefault();
                window.history.back();
              }}
            >
              <ArrowLeft className="w-5 h-5" />
              Go Back
            </motion.button>
          </Link>
        </motion.div>

        {/* Decorative elements */}
        
      </div>
    </div>
  );
}