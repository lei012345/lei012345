export function StorylinePage() {
  // Replace this URL with your hosted Storyline project URL
  const storylineUrl = "YOUR_HOSTED_STORYLINE_URL_HERE";
  
  return (
    <div className="w-full h-screen bg-[#282828]">
      <iframe
        src={storylineUrl}
        title="Navigating Difficult Conversations At Work"
        className="w-full h-full border-0"
        allow="autoplay; fullscreen"
      />
    </div>
  );
}